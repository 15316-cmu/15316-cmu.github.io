(** Information flow analysis for C0-IFC subset. *)

(** [check_secure p] returns [true] when the program passes the
    termination-sensitive information-flow type check. *)
val check_secure : Ast.program -> bool
