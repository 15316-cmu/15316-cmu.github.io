(** Information flow analysis for C0-IFC subset. *)

let check_secure (_p : Ast.program) : bool =
  failwith "TODO: implement check_secure"
;;
