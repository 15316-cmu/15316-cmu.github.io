(** Parsing C0-IFC subset (single `main` function). *)

let initialize_lexbuf (filename : string) : Lexing.lexbuf -> unit =
  let open Lexing in
  let pos = { pos_fname = filename; pos_lnum = 1; pos_bol = 0; pos_cnum = 0 } in
  fun lexbuf ->
    lexbuf.lex_start_p <- pos;
    lexbuf.lex_curr_p <- pos
;;

let validate_and_build
  (rm : string * string * Ast.exp list * Ast.stmt list)
  : Ast.program
  =
  let input_name, secret_name, requires, stmts = rm in
  if not (String.equal input_name "input") then raise Error_msg.Error;
  if not (String.equal secret_name "secret") then raise Error_msg.Error;
  { Ast.stmts; requires; args = (input_name, secret_name) }
;;

let parse_raw
  (lexbuf : Lexing.lexbuf)
  : string * string * Ast.exp list * Ast.stmt list
  =
  try C0_parser.main C0_lexer.initial lexbuf with
  | Error_msg.Error -> raise Error_msg.Error
  | _ ->
    let src_span =
      Mark.of_positions Lexing.(lexbuf.lex_start_p) Lexing.(lexbuf.lex_curr_p)
    in
    Error_msg.error C0_lexer.errors (Some src_span) ~msg:"Parse error.";
    raise Error_msg.Error
;;

let parse ~(filename : string) : Ast.program =
  try
    Error_msg.reset C0_lexer.errors;
    let rm =
      let chan = open_in filename in
      Fun.protect
        ~finally:(fun () -> close_in_noerr chan)
        (fun () ->
          let lexbuf = Lexing.from_channel chan in
          initialize_lexbuf filename lexbuf;
          parse_raw lexbuf)
    in
    if Error_msg.has_any_errors C0_lexer.errors then raise Error_msg.Error;
    validate_and_build rm
  with
  | Sys_error _ -> raise Error_msg.Error
;;

let parse_string (input : string) : Ast.program =
  Error_msg.reset C0_lexer.errors;
  let lexbuf = Lexing.from_string input in
  let rm = parse_raw lexbuf in
  if Error_msg.has_any_errors C0_lexer.errors then raise Error_msg.Error;
  validate_and_build rm
;;
