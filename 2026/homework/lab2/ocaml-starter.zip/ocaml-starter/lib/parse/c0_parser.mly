%{
let as_stmt (stmts : Ast.stmt list) : Ast.stmt =
  match stmts with
  | [] -> Ast.Block []
  | [ s ] -> s
  | ss -> Ast.Block ss
;;

type rhs =
  | RExp of Ast.exp
  | RAlloc of Ast.exp
%}

%token INT BOOL TRUE FALSE IF ELSE WHILE RETURN ASSERT ERROR ALLOC_ARRAY MAIN
%token REQUIRES_ANN LOOP_INVARIANT_ANN LABEL_ANN
%token LENGTH
%token PLUS MINUS TIMES DIV MOD NOT ANDAND OROR EQEQ NEQ LT LE GT GE ASSIGN
%token LPAREN RPAREN LBRACE RBRACE LBRACK RBRACK SEMI COMMA
%token <string> IDENT
%token <Zarith.t> INT_LIT
%token <string> STRING
%token EOF

%start <string * string * Ast.exp list * Ast.stmt list> main

%%

main:
  | INT MAIN LPAREN INT IDENT COMMA INT IDENT RPAREN contracts block_body EOF
      { ($5, $8, $10, $11) }
;

typ:
  | INT { Ast.IntType }
  | BOOL { Ast.BoolType }
  | INT LBRACK RBRACK { Ast.ArrayType Ast.IntType }
;

contracts:
  | contracts_rev { List.rev $1 }
;

contracts_rev:
  | { [] }
  | contracts_rev REQUIRES_ANN exp SEMI { $3 :: $1 }
;

block_body:
  | LBRACE stmts RBRACE { $2 }
;

stmts:
  | stmts_rev { List.rev $1 }
;

stmts_rev:
  | { [] }
  | stmts_rev stmt1 { List.rev_append $2 $1 }
;

stmt1:
  | block_stmt { $1 }
  | decl_stmt { $1 }
  | label_decl_stmt { $1 }
  | if_stmt { $1 }
  | while_stmt { $1 }
  | assert_stmt { $1 }
  | error_stmt { $1 }
  | return_stmt { $1 }
  | assign_or_alloc_stmt { $1 }
;

block_stmt:
  | LBRACE stmts RBRACE { [ Ast.Block $2 ] }
;

label_ann:
  | LABEL_ANN IDENT SEMI
      { match $2 with
        | "H" -> Ast.H
        | "L" -> Ast.L
        | _ -> raise Error_msg.Error
      }
;

decl_stmt:
  | typ IDENT SEMI { [ Ast.Decl ($1, $2, None, None) ] }
  | typ IDENT ASSIGN rhs SEMI
      {
        match $4 with
        | RExp e -> [ Ast.Decl ($1, $2, Some e, None) ]
        | RAlloc count -> [ Ast.Decl ($1, $2, None, None); Ast.AllocArray ($2, Ast.IntType, count, None) ]
      }
;

label_decl_stmt:
  | label_ann typ IDENT SEMI { [ Ast.Decl ($2, $3, None, Some $1) ] }
  | label_ann typ IDENT ASSIGN rhs SEMI
      {
        match $5 with
        | RExp e -> [ Ast.Decl ($2, $3, Some e, Some $1) ]
        | RAlloc count -> [ Ast.Decl ($2, $3, None, Some $1); Ast.AllocArray ($3, Ast.IntType, count, Some $1) ]
      }
;

assign_or_alloc_stmt:
  | lvalue ASSIGN rhs SEMI
      {
        match $1, $3 with
        | Ast.Var x, RAlloc count -> [ Ast.AllocArray (x, Ast.IntType, count, None) ]
        | Ast.Var x, RExp e -> [ Ast.Assign (x, e) ]
        | Ast.ArrayAccess (a, i), RExp e -> [ Ast.ArrWrite (a, i, e) ]
        | Ast.ArrayAccess _, RAlloc _ -> raise Error_msg.Error
        | _ -> raise Error_msg.Error
      }
;

rhs:
  | ALLOC_ARRAY LPAREN INT COMMA exp RPAREN { RAlloc $5 }
  | exp { RExp $1 }
;

lvalue:
  | IDENT { Ast.Var $1 }
  | lvalue LBRACK exp RBRACK { Ast.ArrayAccess ($1, $3) }
;

if_stmt:
  | IF LPAREN exp RPAREN stmt1
      { [ Ast.If ($3, as_stmt $5, None) ] }
  | IF LPAREN exp RPAREN stmt1 ELSE stmt1
      { [ Ast.If ($3, as_stmt $5, Some (as_stmt $7)) ] }
;

while_stmt:
  | WHILE LPAREN exp RPAREN invs stmt1
      { [ Ast.While ($3, $5, as_stmt $6) ] }
;

invs:
  | { [] }
  | invs LOOP_INVARIANT_ANN exp SEMI { $1 @ [ $3 ] }
;

assert_stmt:
  | ASSERT LPAREN exp RPAREN SEMI { [ Ast.Assert $3 ] }
;

error_stmt:
  | ERROR LPAREN STRING RPAREN SEMI { [ Ast.Error $3 ] }
;

return_stmt:
  | RETURN exp SEMI { [ Ast.Return $2 ] }
;

exp:
  | or_expr { $1 }
;

or_expr:
  | and_expr { $1 }
  | or_expr OROR and_expr { Ast.BinOp ("||", $1, $3) }
;

and_expr:
  | eq_expr { $1 }
  | and_expr ANDAND eq_expr { Ast.BinOp ("&&", $1, $3) }
;

eq_expr:
  | rel_expr { $1 }
  | eq_expr EQEQ rel_expr { Ast.BinOp ("==", $1, $3) }
  | eq_expr NEQ rel_expr { Ast.BinOp ("!=", $1, $3) }
;

rel_expr:
  | add_expr { $1 }
  | rel_expr LT add_expr { Ast.BinOp ("<", $1, $3) }
  | rel_expr LE add_expr { Ast.BinOp ("<=", $1, $3) }
  | rel_expr GT add_expr { Ast.BinOp (">", $1, $3) }
  | rel_expr GE add_expr { Ast.BinOp (">=", $1, $3) }
;

add_expr:
  | mul_expr { $1 }
  | add_expr PLUS mul_expr { Ast.BinOp ("+", $1, $3) }
  | add_expr MINUS mul_expr { Ast.BinOp ("-", $1, $3) }
;

mul_expr:
  | unary { $1 }
  | mul_expr TIMES unary { Ast.BinOp ("*", $1, $3) }
  | mul_expr DIV unary { Ast.BinOp ("/", $1, $3) }
  | mul_expr MOD unary { Ast.BinOp ("%", $1, $3) }
;

unary:
  | NOT unary { Ast.UnOp ("!", $2) }
  | MINUS unary { Ast.UnOp ("-", $2) }
  | LENGTH unary { Ast.Length $2 }
  | postfix { $1 }
;

postfix:
  | primary { $1 }
  | postfix LBRACK exp RBRACK { Ast.ArrayAccess ($1, $3) }
;

primary:
  | INT_LIT { Ast.IntConst $1 }
  | TRUE { Ast.BoolConst true }
  | FALSE { Ast.BoolConst false }
  | IDENT { Ast.Var $1 }
  | LPAREN exp RPAREN { $2 }
;
