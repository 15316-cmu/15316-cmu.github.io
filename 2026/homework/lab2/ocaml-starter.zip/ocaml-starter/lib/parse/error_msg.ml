(* Minimal error-reporting helper. *)

open Printf

type t = { mutable error_count : int }

let create () : t = { error_count = 0 }
let has_any_errors (t : t) : bool = t.error_count > 0
let reset (t : t) : unit = t.error_count <- 0

let print_msg (variety : string) (span : Mark.src_span option) ~(msg : string) =
  (match span with
   | None -> ()
   | Some s -> output_string stderr (Mark.show s));
  eprintf ":%s:%s\n" variety msg
;;

let error (t : t) (span : Mark.src_span option) ~(msg : string) : unit =
  t.error_count <- t.error_count + 1;
  print_msg "error" span ~msg
;;

let warn (_t : t) (span : Mark.src_span option) ~(msg : string) : unit =
  print_msg "warning" span ~msg
;;

exception Error
