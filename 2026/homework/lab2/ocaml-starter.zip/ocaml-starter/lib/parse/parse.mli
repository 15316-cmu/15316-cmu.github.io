(** Parsing C0-IFC subset (single `main` function). *)

val parse : filename:string -> Ast.program
val parse_string : string -> Ast.program
