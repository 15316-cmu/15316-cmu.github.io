{
open Printf
open C0_parser

exception Lex_error of string

let errors : Error_msg.t = Error_msg.create ()

let is_reserved_ident (s : string) : bool =
  String.length s > 0 && Char.equal s.[0] '_'
;;

let newline lexbuf =
  let open Lexing in
  let pos = lexbuf.lex_curr_p in
  lexbuf.lex_curr_p <- { pos with pos_lnum = pos.pos_lnum + 1; pos_bol = pos.pos_cnum }
;;

let keyword_or_ident (id : string) : token =
  match id with
  | "int" -> INT
  | "bool" -> BOOL
  | "true" -> TRUE
  | "false" -> FALSE
  | "if" -> IF
  | "else" -> ELSE
  | "while" -> WHILE
  | "return" -> RETURN
  | "assert" -> ASSERT
  | "error" -> ERROR
  | "alloc_array" -> ALLOC_ARRAY
  | "main" -> MAIN
  | _ -> IDENT id
;;
}

let digit = ['0'-'9']
let alpha = ['A'-'Z''a'-'z']
let ident = alpha (alpha | digit | '_' )*
let ws = [' ' '\t' '\r']

rule initial = parse
  | ws+ { initial lexbuf }
  | '\n' { newline lexbuf; initial lexbuf }

  (* Block comments *)
  | "/*" { block_comment lexbuf; initial lexbuf }

  (* Annotation "comments" (kept as tokens) *)
  | "//@requires" { REQUIRES_ANN }
  | "//@loop_invariant" { LOOP_INVARIANT_ANN }
  | "//@label" { LABEL_ANN }

  (* Normal line comments *)
  | "//" '\n' { newline lexbuf; initial lexbuf }
  | "//" eof { EOF }
  | "//" [^'@' '\n'] [^'\n']* { initial lexbuf }

  (* Special logic tokens *)
  | "\\length" { LENGTH }

  (* Reject pointers / NULL *)
  | "NULL" {
      let open Lexing in
      let span = Mark.of_positions lexbuf.lex_start_p lexbuf.lex_curr_p in
      Error_msg.error errors (Some span) ~msg:"NULL is not supported (no pointers in this subset)";
      raise Error_msg.Error
    }

  (* Operators / punctuation *)
  | "&&" { ANDAND }
  | "||" { OROR }
  | "==" { EQEQ }
  | "!=" { NEQ }
  | "<=" { LE }
  | ">=" { GE }
  | "<" { LT }
  | ">" { GT }
  | "+" { PLUS }
  | "-" { MINUS }
  | "*" { TIMES }
  | "/" { DIV }
  | "%" { MOD }
  | "!" { NOT }
  | "=" { ASSIGN }
  | "(" { LPAREN }
  | ")" { RPAREN }
  | "{" { LBRACE }
  | "}" { RBRACE }
  | "[" { LBRACK }
  | "]" { RBRACK }
  | ";" { SEMI }
  | "," { COMMA }

  (* String literal (simple, no escapes) *)
  | '"' ([^'"']*) '"' {
      let s = Lexing.lexeme lexbuf in
      STRING (String.sub s 1 (String.length s - 2))
    }

  (* Integers *)
  | digit+ {
      let s = Lexing.lexeme lexbuf in
      INT_LIT (Zarith.of_string s)
    }

  (* Identifiers / keywords *)
  | ident as id {
      if is_reserved_ident id then (
        let open Lexing in
        let span = Mark.of_positions lexbuf.lex_start_p lexbuf.lex_curr_p in
        Error_msg.error errors (Some span) ~msg:(sprintf "reserved identifier: %s" id);
        raise Error_msg.Error)
      else keyword_or_ident id
    }

  | eof { EOF }

  | _ {
      let open Lexing in
      let span = Mark.of_positions lexbuf.lex_start_p lexbuf.lex_curr_p in
      Error_msg.error errors (Some span) ~msg:"unexpected character";
      raise Error_msg.Error
    }

and block_comment = parse
  | "*/" { () }
  | '\n' { newline lexbuf; block_comment lexbuf }
  | eof {
      let open Lexing in
      let span = Mark.of_positions lexbuf.lex_start_p lexbuf.lex_curr_p in
      Error_msg.error errors (Some span) ~msg:"unterminated block comment";
      raise Error_msg.Error
    }
  | _ { block_comment lexbuf }
