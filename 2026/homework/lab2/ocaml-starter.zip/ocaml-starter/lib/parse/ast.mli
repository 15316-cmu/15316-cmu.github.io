(** C0-IFC subset AST for Lab 2. *)

type label =
  | L
  | H

type typ =
  | IntType
  | BoolType
  | ArrayType of typ

type exp =
  | IntConst of Zarith.t
  | BoolConst of bool
  | Var of string
  | BinOp of string * exp * exp
  | UnOp of string * exp
  | Length of exp
  | ArrayAccess of exp * exp

type stmt =
  | Decl of typ * string * exp option * label option
  | Assign of string * exp
  | AllocArray of string * typ * exp * label option
  | ArrRead of string * exp * exp
  | ArrWrite of exp * exp * exp
  | Block of stmt list
  | If of exp * stmt * stmt option
  | While of exp * exp list * stmt
  | Assert of exp
  | Error of string
  | Return of exp

type program =
  { stmts : stmt list
  ; requires : exp list
  ; args : string * string
  }

val string_of_typ : typ -> string
val string_of_label : label -> string
