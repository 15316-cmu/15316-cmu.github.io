(** Top-level CLI for the Lab 2 analyzer ([c0_serve]). *)

type analyze_exit_status =
  | Analyze_secure   (* exit 0 *)
  | Analyze_error    (* exit 1 *)
  | Analyze_insecure (* exit 2 *)

let analyze_exit_code = function
  | Analyze_secure -> 0
  | Analyze_error -> 1
  | Analyze_insecure -> 2
;;

type cmd_line_args = { filename : string }

let print_and_exit (s : string) (code : analyze_exit_status) =
  (try print_endline s with
   | _ -> ());
  Stdlib.exit (analyze_exit_code code)
;;

let parse_cmd_line_args () : cmd_line_args =
  let argv =
    match Array.to_list Sys.argv with
    | _exe :: rest -> rest
    | [] -> []
  in
  match argv with
  | [ filename ] -> { filename }
  | _ -> print_and_exit "error" Analyze_error
;;

let main () =
  try
    let cmd = parse_cmd_line_args () in
    let ast = Parse.parse ~filename:cmd.filename in
    if Infoflow.check_secure ast
    then print_and_exit "secure" Analyze_secure
    else print_and_exit "insecure" Analyze_insecure
  with
  | Error_msg.Error -> print_and_exit "error" Analyze_error
  | Invalid_argument e ->
    prerr_endline e;
    print_and_exit "error" Analyze_error
  | Sys_error _ -> print_and_exit "error" Analyze_error
;;
