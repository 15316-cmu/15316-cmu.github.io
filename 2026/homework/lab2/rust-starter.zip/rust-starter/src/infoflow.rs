use crate::ast::Program;

/// Termination-sensitive information flow type checker.
/// Returns true if the program is secure.
pub fn check_secure(_prog: &Program) -> bool {
    // TODO: implement
    panic!("TODO: implement check_secure");
}
