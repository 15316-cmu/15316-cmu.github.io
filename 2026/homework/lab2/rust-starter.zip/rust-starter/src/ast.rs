use std::collections::HashSet;

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Type {
    Int,
    Bool,
    IntArray,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Exp {
    IntConst(i64),
    BoolConst(bool),
    Var(String),
    BinOp(String, Box<Exp>, Box<Exp>),
    UnOp(String, Box<Exp>),
    Length(Box<Exp>),
    ArrayAccess(Box<Exp>, Box<Exp>),
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Stmt {
    /// Decl(type, name, initializer, label)
    /// label is Some("H") or Some("L") from //@label annotations; None means default (L).
    Decl(Type, String, Option<Exp>, Option<String>),
    Assign(String, Exp),
    /// AllocArray(dest, elem_type, count, label)
    AllocArray(String, Type, Exp, Option<String>),
    ArrRead(String, Exp, Exp),
    ArrWrite(Exp, Exp, Exp),
    Block(Vec<Stmt>),
    If(Exp, Box<Stmt>, Option<Box<Stmt>>),
    While(Exp, Vec<Exp>, Box<Stmt>),
    Assert(Exp),
    Error(String),
    Return(Exp),
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Program {
    pub stmts: Vec<Stmt>,
    pub requires: Vec<Exp>,
    /// The two parameter names: (input_name, secret_name)
    pub args: (String, String),
}

fn union_all(mut sets: Vec<HashSet<String>>) -> HashSet<String> {
    let mut out = HashSet::new();
    for s in sets.drain(..) {
        out.extend(s);
    }
    out
}

pub fn vars_exp(e: &Exp) -> HashSet<String> {
    match e {
        Exp::IntConst(_) | Exp::BoolConst(_) => HashSet::new(),
        Exp::Var(x) => HashSet::from([x.clone()]),
        Exp::UnOp(_, a) | Exp::Length(a) => vars_exp(a),
        Exp::BinOp(_, l, r) => {
            let mut s = vars_exp(l);
            s.extend(vars_exp(r));
            s
        }
        Exp::ArrayAccess(a, i) => {
            let mut s = vars_exp(a);
            s.extend(vars_exp(i));
            s
        }
    }
}

pub fn stringify(e: &Exp) -> String {
    match e {
        Exp::IntConst(n) => n.to_string(),
        Exp::BoolConst(true) => "true".to_string(),
        Exp::BoolConst(false) => "false".to_string(),
        Exp::Var(x) => x.clone(),
        Exp::Length(a) => format!("\\length({})", stringify(a)),
        Exp::ArrayAccess(a, i) => format!("{}[{}]", stringify(a), stringify(i)),
        Exp::UnOp(op, a) => format!("({}{})", op, stringify(a)),
        Exp::BinOp(op, l, r) => format!("({} {} {})", stringify(l), op, stringify(r)),
    }
}

pub fn stringify_stmt(s: &Stmt) -> String {
    match s {
        Stmt::Decl(t, name, None, lbl) => {
            let l = lbl.as_deref().unwrap_or("L");
            format!("{:?} {} [{}]", t, name, l)
        }
        Stmt::Decl(t, name, Some(init), lbl) => {
            let l = lbl.as_deref().unwrap_or("L");
            format!("{:?} {} = {} [{}]", t, name, stringify(init), l)
        }
        Stmt::Assign(dest, src) => format!("{} = {}", dest, stringify(src)),
        Stmt::AllocArray(dest, _, count, lbl) => {
            let l = lbl.as_deref().unwrap_or("L");
            format!("{} = alloc_array(int, {}) [{}]", dest, stringify(count), l)
        }
        Stmt::ArrRead(dest, arr, idx) => {
            format!("{} = {}[{}]", dest, stringify(arr), stringify(idx))
        }
        Stmt::ArrWrite(a, i, v) => format!(
            "{}[{}] = {}",
            stringify(a),
            stringify(i),
            stringify(v)
        ),
        Stmt::Block(_) => "Block {...}".to_string(),
        Stmt::If(cond, _, _) => format!("if ({}) ...", stringify(cond)),
        Stmt::While(cond, _, _) => format!("while ({}) ...", stringify(cond)),
        Stmt::Assert(cond) => format!("assert({})", stringify(cond)),
        Stmt::Error(msg) => format!("error({})", msg),
        Stmt::Return(v) => format!("return {}", stringify(v)),
    }
}
