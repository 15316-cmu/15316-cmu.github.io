use crate::ast::{Exp, Program, Stmt, Type};
use crate::c0::ProgramParser;
use std::collections::HashMap;

fn check_ident_ok(name: &str) -> Result<(), String> {
    if name.starts_with('_') {
        Err(format!("reserved identifier: {name}"))
    } else {
        Ok(())
    }
}

fn check_exp_idents(e: &Exp) -> Result<(), String> {
    match e {
        Exp::Var(x) => check_ident_ok(x),
        Exp::BinOp(_, l, r) => {
            check_exp_idents(l)?;
            check_exp_idents(r)
        }
        Exp::UnOp(_, a) | Exp::Length(a) => check_exp_idents(a),
        Exp::ArrayAccess(a, i) => {
            check_exp_idents(a)?;
            check_exp_idents(i)
        }
        _ => Ok(()),
    }
}

fn check_stmt_idents(s: &Stmt) -> Result<(), String> {
    match s {
        Stmt::Decl(_, x, init, _) => {
            check_ident_ok(x)?;
            if let Some(e) = init {
                check_exp_idents(e)?;
            }
            Ok(())
        }
        Stmt::Assign(x, e) => {
            check_ident_ok(x)?;
            check_exp_idents(e)
        }
        Stmt::AllocArray(x, _, n, _) => {
            check_ident_ok(x)?;
            check_exp_idents(n)
        }
        Stmt::ArrRead(x, a, i) => {
            check_ident_ok(x)?;
            check_exp_idents(a)?;
            check_exp_idents(i)
        }
        Stmt::ArrWrite(a, i, v) => {
            check_exp_idents(a)?;
            check_exp_idents(i)?;
            check_exp_idents(v)
        }
        Stmt::Assert(c) => check_exp_idents(c),
        Stmt::If(c, t, f) => {
            check_exp_idents(c)?;
            check_stmt_idents(t)?;
            if let Some(ff) = f {
                check_stmt_idents(ff)?;
            }
            Ok(())
        }
        Stmt::While(c, invs, body) => {
            check_exp_idents(c)?;
            for inv in invs {
                check_exp_idents(inv)?;
            }
            check_stmt_idents(body)
        }
        Stmt::Block(ss) => {
            for st in ss {
                check_stmt_idents(st)?;
            }
            Ok(())
        }
        Stmt::Return(v) => check_exp_idents(v),
        _ => Ok(()),
    }
}

fn strip_comments_and_rewrite_annotations(src: &str) -> String {
    let mut out = String::with_capacity(src.len());
    let mut chars = src.chars().peekable();
    let mut in_block_comment = false;
    let mut in_string = false;

    while let Some(c) = chars.next() {
        if in_block_comment {
            if c == '*' && chars.peek() == Some(&'/') {
                chars.next();
                in_block_comment = false;
                continue;
            }
            if c == '\n' {
                out.push('\n');
            }
            continue;
        }

        if !in_string {
            if c == '/' && chars.peek() == Some(&'*') {
                chars.next();
                in_block_comment = true;
                continue;
            }

            if c == '/' && chars.peek() == Some(&'/') {
                chars.next();
                if chars.peek() == Some(&'@') {
                    chars.next(); // consume '@'
                    let mut line = String::new();
                    while let Some(&ch) = chars.peek() {
                        chars.next();
                        if ch == '\n' {
                            break;
                        }
                        line.push(ch);
                    }
                    let trimmed = line.trim_start();
                    if trimmed.starts_with("assert") {
                        let rest = trimmed.strip_prefix("assert").unwrap();
                        let rest = rest.trim_start();
                        if let Some(pos) = rest.rfind(';') {
                            let expr = rest[..pos].trim();
                            out.push_str("assert(");
                            out.push_str(expr);
                            out.push_str(");");
                            out.push('\n');
                        } else {
                            out.push_str("assert(");
                            out.push_str(rest);
                            out.push_str(");");
                            out.push('\n');
                        }
                    } else {
                        // Pass through other annotations (requires, label, loop_invariant)
                        out.push_str(trimmed);
                        out.push('\n');
                    }
                } else {
                    // Normal line comment; skip to end of line
                    while let Some(&ch) = chars.peek() {
                        chars.next();
                        if ch == '\n' {
                            out.push('\n');
                            break;
                        }
                    }
                }
                continue;
            }
        }

        if c == '"' {
            in_string = !in_string;
        }
        out.push(c);
    }

    out
}

fn stmt_contains_return(s: &Stmt) -> bool {
    match s {
        Stmt::Return(_) => true,
        Stmt::Block(ss) => ss.iter().any(stmt_contains_return),
        Stmt::If(_, t, None) => stmt_contains_return(t),
        Stmt::If(_, t, Some(f)) => stmt_contains_return(t) || stmt_contains_return(f),
        Stmt::While(_, _, body) => stmt_contains_return(body),
        _ => false,
    }
}

fn typecheck_and_validate_program(prog: &Program) -> Result<(), String> {
    fn lookup(env: &[HashMap<String, Type>], name: &str) -> Result<Type, String> {
        for scope in env.iter().rev() {
            if let Some(t) = scope.get(name) {
                return Ok(t.clone());
            }
        }
        Err(format!("use of undeclared variable `{name}`"))
    }

    fn exp_type(env: &mut Vec<HashMap<String, Type>>, e: &Exp) -> Result<Type, String> {
        match e {
            Exp::IntConst(_) => Ok(Type::Int),
            Exp::BoolConst(_) => Ok(Type::Bool),
            Exp::Var(x) => lookup(env, x),
            Exp::Length(a) => {
                let t = exp_type(env, a)?;
                if t != Type::IntArray {
                    return Err("\\length expects an `int[]` expression".to_string());
                }
                Ok(Type::Int)
            }
            Exp::ArrayAccess(a, i) => {
                let ta = exp_type(env, a)?;
                let ti = exp_type(env, i)?;
                if ta != Type::IntArray {
                    return Err("array indexing expects an `int[]` base expression".to_string());
                }
                if ti != Type::Int {
                    return Err("array index must have type `int`".to_string());
                }
                Ok(Type::Int)
            }
            Exp::UnOp(op, a) if op == "!" => {
                let ta = exp_type(env, a)?;
                if ta != Type::Bool {
                    return Err("`!` expects a `bool` operand".to_string());
                }
                Ok(Type::Bool)
            }
            Exp::UnOp(op, a) if op == "-" => {
                let ta = exp_type(env, a)?;
                if ta != Type::Int {
                    return Err("unary `-` expects an `int` operand".to_string());
                }
                Ok(Type::Int)
            }
            Exp::UnOp(op, _) => Err(format!("unknown unary operator `{op}`")),
            Exp::BinOp(op, l, r) => {
                let tl = exp_type(env, l)?;
                let tr = exp_type(env, r)?;
                let arith = ["+", "-", "*", "/", "%"];
                let cmp_ops = ["<", "<=", ">", ">="];
                let logic = ["&&", "||"];
                let eq = ["==", "!="];

                if arith.contains(&op.as_str()) {
                    if tl != Type::Int || tr != Type::Int {
                        return Err(format!("`{op}` expects `int` operands"));
                    }
                    Ok(Type::Int)
                } else if cmp_ops.contains(&op.as_str()) {
                    if tl != Type::Int || tr != Type::Int {
                        return Err(format!("`{op}` expects `int` operands"));
                    }
                    Ok(Type::Bool)
                } else if logic.contains(&op.as_str()) {
                    if tl != Type::Bool || tr != Type::Bool {
                        return Err(format!("`{op}` expects `bool` operands"));
                    }
                    Ok(Type::Bool)
                } else if eq.contains(&op.as_str()) {
                    if tl != tr {
                        return Err(format!("`{op}` expects operands of the same type"));
                    }
                    Ok(Type::Bool)
                } else {
                    Err(format!("unknown binary operator `{op}`"))
                }
            }
        }
    }

    fn check_stmt(env: &mut Vec<HashMap<String, Type>>, s: &Stmt) -> Result<(), String> {
        match s {
            Stmt::Decl(ty, name, init, _lbl) => {
                if *ty == Type::IntArray && init.is_some() {
                    return Err(
                        "`int[]` variables cannot be initialized by assignment; use `alloc_array`"
                            .to_string(),
                    );
                }
                if let Some(e) = init {
                    let te = exp_type(env, e)?;
                    if te != *ty {
                        return Err(format!("type mismatch in initializer for `{name}`"));
                    }
                }
                env.last_mut().unwrap().insert(name.clone(), ty.clone());
                Ok(())
            }
            Stmt::Assign(dest, src) => {
                let td = lookup(env, dest)?;
                if td == Type::IntArray {
                    return Err(
                        "assignment between `int[]` variables is not allowed (use `alloc_array` or indexed assignment)"
                            .to_string(),
                    );
                }
                let ts = exp_type(env, src)?;
                if ts != td {
                    return Err(format!("type mismatch in assignment to `{dest}`"));
                }
                Ok(())
            }
            Stmt::AllocArray(dest, ty, count, _lbl) => {
                let td = lookup(env, dest)?;
                if td != Type::IntArray {
                    return Err("`alloc_array` destination must have type `int[]`".to_string());
                }
                if *ty != Type::Int {
                    return Err("only `alloc_array(int, n)` is supported".to_string());
                }
                let tc = exp_type(env, count)?;
                if tc != Type::Int {
                    return Err("`alloc_array` count must have type `int`".to_string());
                }
                Ok(())
            }
            Stmt::ArrRead(dest, arr, idx) => {
                let td = lookup(env, dest)?;
                if td != Type::Int {
                    return Err("array read destination must have type `int`".to_string());
                }
                let ta = exp_type(env, arr)?;
                if ta != Type::IntArray {
                    return Err("array read expects an `int[]` base expression".to_string());
                }
                if exp_type(env, idx)? != Type::Int {
                    return Err("array index must have type `int`".to_string());
                }
                Ok(())
            }
            Stmt::ArrWrite(arr, idx, v) => {
                match arr {
                    Exp::Var(a_name) => {
                        let ta = lookup(env, a_name)?;
                        if ta != Type::IntArray {
                            return Err(
                                "array assignment expects an `int[]` base variable".to_string()
                            );
                        }
                    }
                    _ => {
                        return Err(
                            "array assignment must have the form `A[i] = e` where `A` is a variable"
                                .to_string(),
                        );
                    }
                }
                if exp_type(env, idx)? != Type::Int {
                    return Err("array index must have type `int`".to_string());
                }
                if exp_type(env, v)? != Type::Int {
                    return Err("array element value must have type `int`".to_string());
                }
                Ok(())
            }
            Stmt::Block(ss) => {
                env.push(HashMap::new());
                for st in ss {
                    check_stmt(env, st)?;
                }
                env.pop();
                Ok(())
            }
            Stmt::If(cond, t, None) => {
                if exp_type(env, cond)? != Type::Bool {
                    return Err("`if` condition must have type `bool`".to_string());
                }
                env.push(HashMap::new());
                check_stmt(env, t)?;
                env.pop();
                Ok(())
            }
            Stmt::If(cond, t, Some(f)) => {
                if exp_type(env, cond)? != Type::Bool {
                    return Err("`if` condition must have type `bool`".to_string());
                }
                env.push(HashMap::new());
                check_stmt(env, t)?;
                env.pop();
                env.push(HashMap::new());
                check_stmt(env, f)?;
                env.pop();
                Ok(())
            }
            Stmt::While(cond, invs, body) => {
                if exp_type(env, cond)? != Type::Bool {
                    return Err("`while` condition must have type `bool`".to_string());
                }
                for inv in invs {
                    if exp_type(env, inv)? != Type::Bool {
                        return Err("loop invariants must have type `bool`".to_string());
                    }
                }
                env.push(HashMap::new());
                check_stmt(env, body)?;
                env.pop();
                Ok(())
            }
            Stmt::Assert(cond) => {
                if exp_type(env, cond)? != Type::Bool {
                    return Err("`assert` condition must have type `bool`".to_string());
                }
                Ok(())
            }
            Stmt::Return(v) => {
                if exp_type(env, v)? != Type::Int {
                    return Err("main must return an `int` expression".to_string());
                }
                Ok(())
            }
            Stmt::Error(_) => Ok(()),
        }
    }

    let mut env: Vec<HashMap<String, Type>> = vec![HashMap::new()];
    let (input, secret) = &prog.args;
    env[0].insert(input.clone(), Type::Int);
    env[0].insert(secret.clone(), Type::Int);

    for e in &prog.requires {
        if exp_type(&mut env, e)? != Type::Bool {
            return Err("requires clauses must be boolean formulas".to_string());
        }
    }
    for s in &prog.stmts {
        check_stmt(&mut env, s)?;
    }
    Ok(())
}

pub fn parse_program(input: &str) -> Result<Program, String> {
    let stripped = strip_comments_and_rewrite_annotations(input);
    let prog = ProgramParser::new()
        .parse(&stripped)
        .map_err(|e| format!("{e:?}"))?;

    // Check that user identifiers won't collide with internal names.
    let (input_name, secret_name) = &prog.args;
    check_ident_ok(input_name)?;
    check_ident_ok(secret_name)?;

    for e in &prog.requires {
        check_exp_idents(e)?;
    }
    for s in &prog.stmts {
        check_stmt_idents(s)?;
    }

    // Validate: must end with a return statement
    if prog.stmts.is_empty() || !matches!(prog.stmts.last(), Some(Stmt::Return(_))) {
        return Err("main must end with a return statement".to_string());
    }
    for st in &prog.stmts[..prog.stmts.len() - 1] {
        if stmt_contains_return(st) {
            return Err("main must contain exactly one return statement at top level".to_string());
        }
    }

    typecheck_and_validate_program(&prog)?;
    Ok(prog)
}
