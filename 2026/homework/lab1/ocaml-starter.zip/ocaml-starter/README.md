# Lab 1 (C0-Arrays) — OCaml Starter

This starter code provides:
- A parser for the Lab 1 C0-Arrays subset (`lib/parse/*`, `lib/parse/parse.ml`)
  - Rejects array-aliasing programs (e.g. `A = B;` for `int[] A, B`)
  - Normalizes expressions by hoisting potentially-unsafe subexpressions (division/modulo and array reads)
- A Z3 interface for validity checking (`lib/utils/solver.ml`)

You implement the analyzer (WLP/VC generation) in `lib/wlp/wlp.ml`.

## Build

```bash
make
```

This produces `c0_vc`.

## Run

```bash
./c0_vc example.c0
```

Exit codes: `0` valid, `2` unsafe, `1` error.
