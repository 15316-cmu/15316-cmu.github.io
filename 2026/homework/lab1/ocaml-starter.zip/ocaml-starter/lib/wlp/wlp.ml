(** Weakest-liberal-precondition safety checker (students implement). *)

let check_safety (_p : Ast.program) : bool =
  invalid_arg "Wlp.check_safety is not implemented in the starter code"
;;
