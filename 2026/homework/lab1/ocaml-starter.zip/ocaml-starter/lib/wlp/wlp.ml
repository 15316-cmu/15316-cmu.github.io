(** Weakest-liberal-precondition safety checker (students implement). *)

let check_safety (_p : Ast.program) ~verbose:_ ~print_vc:_ ~small_cex:_ ~small_cex_max:_ : bool =
  invalid_arg "Wlp.check_safety is not implemented in the starter code"
;;

