(* Minimal source-location support (for error messages). *)

open Printf

type src_loc =
  { line : int
  ; col : int
  }

type src_span =
  { start_loc : src_loc
  ; end_loc : src_loc
  ; file : string
  }

let of_position (pos : Lexing.position) : src_loc =
  Lexing.{ line = pos.pos_lnum; col = pos.pos_cnum - pos.pos_bol + 1 }
;;

let of_positions (pos_start : Lexing.position) (pos_end : Lexing.position) : src_span =
  { start_loc = of_position pos_start; end_loc = of_position pos_end; file = pos_start.pos_fname }
;;

let show (span : src_span) : string =
  let show_loc (l : src_loc) =
    if l.col = 0 then string_of_int l.line else sprintf "%d.%d" l.line l.col
  in
  sprintf "%s:%s-%s" span.file (show_loc span.start_loc) (show_loc span.end_loc)
;;

