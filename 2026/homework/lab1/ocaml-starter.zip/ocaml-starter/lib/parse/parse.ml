(** Parsing C0-Arrays subset (single `main` function). *)

open Printf

let concat_map f xs = List.concat (List.map f xs)

let list_last xs =
  match List.rev xs with
  | [] -> None
  | x :: _ -> Some x
;;

let list_drop_last xs =
  match List.rev xs with
  | [] -> None
  | _last :: rev_prefix -> Some (List.rev rev_prefix)
;;

let initialize_lexbuf (filename : string) : Lexing.lexbuf -> unit =
  let open Lexing in
  let pos = { pos_fname = filename; pos_lnum = 1; pos_bol = 0; pos_cnum = 0 } in
  fun lexbuf ->
    lexbuf.lex_start_p <- pos;
    lexbuf.lex_curr_p <- pos
;;

let rec stmt_contains_return (s : Ast.stmt) : bool =
  match s with
  | Ast.Return _ -> true
  | Ast.Block ss -> List.exists stmt_contains_return ss
  | Ast.If (_, t, None) -> stmt_contains_return t
  | Ast.If (_, t, Some f) -> stmt_contains_return t || stmt_contains_return f
  | Ast.While (_, _, body) -> stmt_contains_return body
  | _ -> false
;;

let rec exp_contains_result (e : Ast.exp) : bool =
  match e with
  | Ast.ResultVar -> true
  | Ast.BinOp (_, l, r) -> exp_contains_result l || exp_contains_result r
  | Ast.UnOp (_, a) -> exp_contains_result a
  | Ast.Length a -> exp_contains_result a
  | Ast.ArrayAccess (a, i) -> exp_contains_result a || exp_contains_result i
  | Ast.ForAll (_, body) -> exp_contains_result body
  | _ -> false
;;

let rec stmt_contains_result (s : Ast.stmt) : bool =
  match s with
  | Ast.Decl (_, _, None) -> false
  | Ast.Decl (_, _, Some init) -> exp_contains_result init
  | Ast.Assign (_, src) -> exp_contains_result src
  | Ast.AllocArray (_, _, count) -> exp_contains_result count
  | Ast.ArrRead (_, a, i) -> exp_contains_result a || exp_contains_result i
  | Ast.ArrWrite (a, i, v) -> exp_contains_result a || exp_contains_result i || exp_contains_result v
  | Ast.Assert c -> exp_contains_result c
  | Ast.If (c, t, None) -> exp_contains_result c || stmt_contains_result t
  | Ast.If (c, t, Some f) ->
    exp_contains_result c || stmt_contains_result t || stmt_contains_result f
  | Ast.While (c, invs, body) ->
    exp_contains_result c
    || List.exists exp_contains_result invs
    || stmt_contains_result body
  | Ast.Block ss -> List.exists stmt_contains_result ss
  | Ast.Return None -> false
  | Ast.Return (Some v) -> exp_contains_result v
  | Ast.Error _ -> false
;;

let is_int_type = function
  | Ast.IntType -> true
  | _ -> false
;;

let is_int_array_type = function
  | Ast.ArrayType Ast.IntType -> true
  | _ -> false
;;

let is_len_result = function
  | Ast.Length Ast.ResultVar -> true
  | _ -> false
;;

let rec is_result_only_in_len_result (e : Ast.exp) : bool =
  match e with
  | Ast.ResultVar -> false
  | Ast.Length a ->
    (match a with
     | Ast.ResultVar -> true
     | _ -> is_result_only_in_len_result a)
  | Ast.BinOp (_, l, r) -> is_result_only_in_len_result l && is_result_only_in_len_result r
  | Ast.UnOp (_, a) -> is_result_only_in_len_result a
  | Ast.ArrayAccess (a, i) -> is_result_only_in_len_result a && is_result_only_in_len_result i
  | Ast.ForAll (_, body) -> is_result_only_in_len_result body
  | _ -> true
;;

let is_len_result_eq (e : Ast.exp) : bool =
  match e with
  | Ast.BinOp ("==", l, r) ->
    (is_len_result l && is_result_only_in_len_result r)
    || (is_len_result r && is_result_only_in_len_result l)
  | _ -> false
;;

(* Automatic Safe Expression Transformation (normalization) *)

module Temp_factory = struct
  type t = { mutable counter : int }

  let create () = { counter = 0 }

  let fresh t =
    t.counter <- t.counter + 1;
    sprintf "_t%d" t.counter
  ;;
end

let hoist_exp (e : Ast.exp) (tf : Temp_factory.t) : Ast.exp * Ast.stmt list =
  let rec go (e : Ast.exp) : Ast.exp * Ast.stmt list =
    match e with
    | Ast.IntConst _ | Ast.BoolConst _ | Ast.NullConst | Ast.Var _ | Ast.ResultVar -> e, []
    | Ast.BinOp (op, l, r) ->
      let sl, al = go l in
      let sr, ar = go r in
      let setup = al @ ar in
      if op = "/" || op = "%"
      then (
        let tmp = Temp_factory.fresh tf in
        ( Ast.Var tmp
        , setup
          @ [ Ast.Decl (Ast.IntType, tmp, None); Ast.Assign (tmp, Ast.BinOp (op, sl, sr)) ] ))
      else Ast.BinOp (op, sl, sr), setup
    | Ast.UnOp (op, arg) ->
      let sa, aa = go arg in
      Ast.UnOp (op, sa), aa
    | Ast.Length arg ->
      let sa, aa = go arg in
      Ast.Length sa, aa
    | Ast.ArrayAccess (arr, idx) ->
      let sarr, aarr = go arr in
      let sidx, aidx = go idx in
      let setup = aarr @ aidx in
      let tmp = Temp_factory.fresh tf in
      ( Ast.Var tmp
      , setup
        @ [ Ast.Decl (Ast.IntType, tmp, None); Ast.ArrRead (tmp, sarr, sidx) ] )
    | _ -> e, []
  in
  go e
;;

let as_stmt (stmts : Ast.stmt list) : Ast.stmt =
  match stmts with
  | [] -> Ast.Block []
  | [ s ] -> s
  | ss -> Ast.Block ss
;;

let rec normalize_stmt_list (s : Ast.stmt) (tf : Temp_factory.t) : Ast.stmt list =
  match s with
  | Ast.Decl (typ, name, None) -> [ Ast.Decl (typ, name, None) ]
  | Ast.Decl (typ, name, Some init) ->
    let si, ai = hoist_exp init tf in
    ai @ [ Ast.Decl (typ, name, Some si) ]
  | Ast.Assign (dest, src) ->
    let ss, aa = hoist_exp src tf in
    aa @ [ Ast.Assign (dest, ss) ]
  | Ast.ArrWrite (arr, idx, v) ->
    let sa, aa = hoist_exp arr tf in
    let si, ai = hoist_exp idx tf in
    let sv, av = hoist_exp v tf in
    aa @ ai @ av @ [ Ast.ArrWrite (sa, si, sv) ]
  | Ast.If (cond, t, None) ->
    let sc, ac = hoist_exp cond tf in
    let tb = as_stmt (normalize_stmt_list t tf) in
    ac @ [ Ast.If (sc, tb, None) ]
  | Ast.If (cond, t, Some f) ->
    let sc, ac = hoist_exp cond tf in
    let tb = as_stmt (normalize_stmt_list t tf) in
    let fb = as_stmt (normalize_stmt_list f tf) in
    ac @ [ Ast.If (sc, tb, Some fb) ]
  | Ast.While (cond, invs, body) ->
    let sc, ac = hoist_exp cond tf in
    let recompute =
      List.filter
        (function
          | Ast.Decl _ -> false
          | _ -> true)
        ac
    in
    let body_stmt = as_stmt (normalize_stmt_list body tf) in
    let new_body =
      match body_stmt with
      | Ast.Block ss -> Ast.Block (ss @ recompute)
      | other -> Ast.Block (other :: recompute)
    in
    ac @ [ Ast.While (sc, invs, new_body) ]
  | Ast.Block ss ->
    let new_stmts = concat_map (fun st -> normalize_stmt_list st tf) ss in
    [ Ast.Block new_stmts ]
  | Ast.Assert cond ->
    let sc, ac = hoist_exp cond tf in
    ac @ [ Ast.Assert sc ]
  | Ast.Return None -> [ s ]
  | Ast.Return (Some v) ->
    let sv, av = hoist_exp v tf in
    av @ [ Ast.Return (Some sv) ]
  | Ast.AllocArray (dest, typ, count) ->
    let sc, ac = hoist_exp count tf in
    ac @ [ Ast.AllocArray (dest, typ, sc) ]
  | Ast.ArrRead (dest, arr, idx) ->
    let sa, aa = hoist_exp arr tf in
    let si, ai = hoist_exp idx tf in
    aa @ ai @ [ Ast.ArrRead (dest, sa, si) ]
  | Ast.Error _ -> [ s ]
;;

let normalize_program (p : Ast.program) : Ast.program =
  let tf = Temp_factory.create () in
  let new_stmts = concat_map (fun st -> normalize_stmt_list st tf) p.stmts in
  { p with stmts = new_stmts }
;;

(* Basic typechecking + syntactic restrictions.

   In particular, enforce "no array aliasing":
   - `int[]` variables cannot be assigned (except via alloc_array / indexed writes),
   - `int[]` variables cannot be initialized by assignment. *)

module StringMap = Map.Make (String)

let typecheck_and_validate_program (p : Ast.program) : unit =
  let fail ~(msg : string) : unit =
    Error_msg.error C0_lexer.errors None ~msg;
    raise Error_msg.Error
  in
  let fail_ty ~(msg : string) : Ast.typ =
    fail ~msg;
    Ast.IntType
  in
  let is_int = function
    | Ast.IntType -> true
    | _ -> false
  in
  let is_bool = function
    | Ast.BoolType -> true
    | _ -> false
  in
  let is_int_array = function
    | Ast.ArrayType Ast.IntType -> true
    | _ -> false
  in
  let rec lookup (env : Ast.typ StringMap.t list) (name : string) : Ast.typ =
    match env with
    | [] -> fail_ty ~msg:(sprintf "use of undeclared variable `%s`" name)
    | scope :: rest ->
      (match StringMap.find_opt name scope with
       | Some t -> t
       | None -> lookup rest name)
  in

  let rec exp_type (env : Ast.typ StringMap.t list) (e : Ast.exp) : Ast.typ =
    match e with
    | Ast.IntConst _ -> Ast.IntType
    | Ast.BoolConst _ -> Ast.BoolType
    | Ast.NullConst -> Ast.IntType
    | Ast.Var x -> lookup env x
    | Ast.ResultVar -> Ast.ArrayType Ast.IntType
    | Ast.Length a ->
      let t = exp_type env a in
      (if not (is_int_array t) then fail ~msg:"\\length expects an `int[]` expression");
      Ast.IntType
    | Ast.ArrayAccess (a, i) ->
      let ta = exp_type env a in
      let ti = exp_type env i in
      (if not (is_int_array ta)
       then fail ~msg:"array indexing expects an `int[]` base expression");
      (if not (is_int ti) then fail ~msg:"array index must have type `int`");
      Ast.IntType
    | Ast.UnOp ("!", a) ->
      let ta = exp_type env a in
      (if not (is_bool ta) then fail ~msg:"`!` expects a `bool` operand");
      Ast.BoolType
    | Ast.UnOp ("-", a) ->
      let ta = exp_type env a in
      (if not (is_int ta) then fail ~msg:"unary `-` expects an `int` operand");
      Ast.IntType
    | Ast.UnOp (op, _) -> fail_ty ~msg:(sprintf "unknown unary operator `%s`" op)
    | Ast.BinOp (op, l, r) ->
      let tl = exp_type env l in
      let tr = exp_type env r in
      let arith = [ "+"; "-"; "*"; "/"; "%" ] in
      let cmp_ops = [ "<"; "<="; ">"; ">=" ] in
      let logic = [ "&&"; "||"; "=>" ] in
      let eq = [ "=="; "!=" ] in
      if List.mem op arith
      then (
        (if not (is_int tl && is_int tr)
         then fail ~msg:(sprintf "`%s` expects `int` operands" op));
        Ast.IntType)
      else if List.mem op cmp_ops
      then (
        (if not (is_int tl && is_int tr)
         then fail ~msg:(sprintf "`%s` expects `int` operands" op));
        Ast.BoolType)
      else if List.mem op logic
      then (
        (if not (is_bool tl && is_bool tr)
         then fail ~msg:(sprintf "`%s` expects `bool` operands" op));
        Ast.BoolType)
      else if List.mem op eq
      then (
        (if tl <> tr then fail ~msg:(sprintf "`%s` expects operands of the same type" op));
        Ast.BoolType)
      else fail_ty ~msg:(sprintf "unknown binary operator `%s`" op)
    | Ast.ForAll (vars, body) ->
      let scope =
        match env with
        | [] -> StringMap.empty
        | top :: _ -> top
      in
      let bound_scope =
        List.fold_left (fun acc v -> StringMap.add v Ast.IntType acc) scope vars
      in
      let env' =
        match env with
        | [] -> [ bound_scope ]
        | _top :: rest -> bound_scope :: rest
      in
      let tb = exp_type env' body in
      (if not (is_bool tb) then fail ~msg:"\\forall body must be a boolean formula");
      Ast.BoolType
    | Ast.ArrMake _ | Ast.ArrSet _ ->
      fail_ty ~msg:"internal array-value nodes should not appear in source programs"
  in

  let rec check_stmt (env : Ast.typ StringMap.t list) (s : Ast.stmt) : Ast.typ StringMap.t list
    =
    match s with
    | Ast.Decl (ty, name, init) ->
      if is_int_array ty && Option.is_some init
      then fail ~msg:"`int[]` variables cannot be initialized by assignment; use `alloc_array`";
      (match init with
       | None -> ()
       | Some e ->
         let te = exp_type env e in
         if te <> ty then fail ~msg:(sprintf "type mismatch in initializer for `%s`" name));
      let scope =
        match env with
        | [] -> StringMap.empty
        | top :: _ -> top
      in
      let scope' = StringMap.add name ty scope in
      (match env with
       | [] -> [ scope' ]
       | _top :: rest -> scope' :: rest)
    | Ast.Assign (dest, src) ->
      let td = lookup env dest in
      if is_int_array td
      then
        fail ~msg:"assignment between `int[]` variables is not allowed (use `alloc_array` or indexed assignment)";
      let ts = exp_type env src in
      if ts <> td then fail ~msg:(sprintf "type mismatch in assignment to `%s`" dest);
      env
    | Ast.AllocArray (dest, ty, count) ->
      let td = lookup env dest in
      if not (is_int_array td) then fail ~msg:"`alloc_array` destination must have type `int[]`";
      (match ty with
       | Ast.IntType -> ()
       | _ -> fail ~msg:"only `alloc_array(int, n)` is supported");
      if not (is_int (exp_type env count)) then fail ~msg:"`alloc_array` count must have type `int`";
      env
    | Ast.ArrRead (dest, arr, idx) ->
      let td = lookup env dest in
      if not (is_int td) then fail ~msg:"array read destination must have type `int`";
      let ta = exp_type env arr in
      if not (is_int_array ta) then fail ~msg:"array read expects an `int[]` base expression";
      if not (is_int (exp_type env idx)) then fail ~msg:"array index must have type `int`";
      env
    | Ast.ArrWrite (arr, idx, v) ->
      (match arr with
       | Ast.Var a_name ->
         let ta = lookup env a_name in
         if not (is_int_array ta) then fail ~msg:"array assignment expects an `int[]` base variable"
       | _ -> fail ~msg:"array assignment must have the form `A[i] = e` where `A` is a variable");
      if not (is_int (exp_type env idx)) then fail ~msg:"array index must have type `int`";
      if not (is_int (exp_type env v)) then fail ~msg:"array element value must have type `int`";
      env
    | Ast.Block ss ->
      let env' = StringMap.empty :: env in
      let _env_end = List.fold_left check_stmt env' ss in
      env
    | Ast.If (cond, t, None) ->
      if not (is_bool (exp_type env cond)) then fail ~msg:"`if` condition must have type `bool`";
      ignore (check_stmt (StringMap.empty :: env) t);
      env
    | Ast.If (cond, t, Some f) ->
      if not (is_bool (exp_type env cond)) then fail ~msg:"`if` condition must have type `bool`";
      ignore (check_stmt (StringMap.empty :: env) t);
      ignore (check_stmt (StringMap.empty :: env) f);
      env
    | Ast.While (cond, invs, body) ->
      if not (is_bool (exp_type env cond)) then fail ~msg:"`while` condition must have type `bool`";
      List.iter
        (fun inv -> if not (is_bool (exp_type env inv)) then fail ~msg:"loop invariants must have type `bool`")
        invs;
      ignore (check_stmt (StringMap.empty :: env) body);
      env
    | Ast.Assert cond ->
      if not (is_bool (exp_type env cond)) then fail ~msg:"`assert` condition must have type `bool`";
      env
    | Ast.Return None ->
      fail ~msg:"main must return an `int[]` expression";
      env
    | Ast.Return (Some v) ->
      if not (is_int_array (exp_type env v)) then fail ~msg:"main must return an `int[]` expression";
      env
    | Ast.Error _ -> env
  in

  (* Function-scope env, seeded with args. *)
  let init_scope =
    match p.args with
    | Some [ argc_name; in_name ] ->
      StringMap.empty
      |> StringMap.add argc_name Ast.IntType
      |> StringMap.add in_name (Ast.ArrayType Ast.IntType)
    | _ -> StringMap.empty
  in
  let env0 = [ init_scope ] in

  List.iter
    (fun e -> if not (is_bool (exp_type env0 e)) then fail ~msg:"requires clauses must be boolean formulas")
    p.requires;
  List.iter
    (fun e -> if not (is_bool (exp_type env0 e)) then fail ~msg:"ensures clauses must be boolean formulas")
    p.ensures;

  ignore (List.fold_left check_stmt env0 p.stmts)
;;

let validate_and_build
  (rm :
    Ast.typ
    * Ast.typ
    * string
    * Ast.typ
    * string
    * Ast.exp list
    * Ast.exp list
    * Ast.stmt list)
  : Ast.program
  =
  let ret_type, argc_type, argc_name, in_type, in_name, requires, ensures, stmts = rm in
  if not (is_int_array_type ret_type) then raise Error_msg.Error;
  if not (is_int_type argc_type && String.equal argc_name "argc") then raise Error_msg.Error;
  if not (is_int_array_type in_type && String.equal in_name "in") then raise Error_msg.Error;

  (match ensures with
   | [] -> raise Error_msg.Error
   | _ -> ());
  if not (List.exists is_len_result_eq ensures) then raise Error_msg.Error;

  (match list_last stmts with
   | Some (Ast.Return _) -> ()
   | _ -> raise Error_msg.Error);
  (match list_drop_last stmts with
   | None -> ()
   | Some prefix -> if List.exists stmt_contains_return prefix then raise Error_msg.Error);

  if List.exists stmt_contains_result stmts then raise Error_msg.Error;

  { Ast.stmts; requires; ensures; args = Some [ argc_name; in_name ] }
  |> normalize_program
  |> fun p ->
  typecheck_and_validate_program p;
  p
;;

let parse_raw
  (lexbuf : Lexing.lexbuf)
  : Ast.typ * Ast.typ * string * Ast.typ * string * Ast.exp list * Ast.exp list * Ast.stmt list
  =
  try C0_parser.main C0_lexer.initial lexbuf with
  | Error_msg.Error -> raise Error_msg.Error
  | _ ->
    let src_span =
      Mark.of_positions Lexing.(lexbuf.lex_start_p) Lexing.(lexbuf.lex_curr_p)
    in
    Error_msg.error C0_lexer.errors (Some src_span) ~msg:"Parse error.";
    raise Error_msg.Error
;;

let parse ~(filename : string) : Ast.program =
  try
    Error_msg.reset C0_lexer.errors;
    let rm =
      let chan = open_in filename in
      Fun.protect
        ~finally:(fun () -> close_in_noerr chan)
        (fun () ->
          let lexbuf = Lexing.from_channel chan in
          initialize_lexbuf filename lexbuf;
          parse_raw lexbuf)
    in
    if Error_msg.has_any_errors C0_lexer.errors then raise Error_msg.Error;
    validate_and_build rm
  with
  | Sys_error _ -> raise Error_msg.Error
;;

let parse_string (input : string) : Ast.program =
  Error_msg.reset C0_lexer.errors;
  let lexbuf = Lexing.from_string input in
  let rm = parse_raw lexbuf in
  if Error_msg.has_any_errors C0_lexer.errors then raise Error_msg.Error;
  validate_and_build rm
;;
