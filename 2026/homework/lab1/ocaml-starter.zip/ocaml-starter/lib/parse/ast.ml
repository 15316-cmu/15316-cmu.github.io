(** C0-Arrays subset AST for Lab 1. *)

type typ =
  | IntType
  | BoolType
  | ArrayType of typ

type exp =
  | IntConst of Zarith.t
  | BoolConst of bool
  | NullConst
  | Var of string
  | BinOp of string * exp * exp
  | UnOp of string * exp
  | Length of exp
  | ArrayAccess of exp * exp
  | ForAll of string list * exp
  | ResultVar
  | ArrMake of exp
  | ArrSet of exp * exp * exp

type stmt =
  | Decl of typ * string * exp option
  | Assign of string * exp
  | AllocArray of string * typ * exp
  | ArrRead of string * exp * exp
  | ArrWrite of exp * exp * exp
  | Block of stmt list
  | If of exp * stmt * stmt option
  | While of exp * exp list * stmt
  | Assert of exp
  | Error of string
  | Return of exp option

type program =
  { stmts : stmt list
  ; requires : exp list
  ; ensures : exp list
  ; args : string list option
  }

let rec string_of_typ = function
  | IntType -> "int"
  | BoolType -> "bool"
  | ArrayType t -> Printf.sprintf "%s[]" (string_of_typ t)
;;
