(** Top-level CLI for the Lab 1 analyzer (`c0_vc`). *)

type analyze_exit_status =
  | Analyze_valid
  | Analyze_error
  | Analyze_unsafe

let analyze_exit_code = function
  | Analyze_valid -> 0
  | Analyze_error -> 1
  | Analyze_unsafe -> 2
;;

type cmd_line_args =
  { filename : string }

let print_and_exit (s : string) (code : analyze_exit_status) =
  (try print_endline s with
   | _ -> ());
  Stdlib.exit (analyze_exit_code code)
;;

let parse_cmd_line_args () : cmd_line_args =
  let argv =
    match Array.to_list Sys.argv with
    | _exe :: rest -> rest
    | [] -> []
  in
  match argv with
  | [ filename ] -> { filename }
  | _ -> print_and_exit "error" Analyze_error
;;

let main () =
  try
    let cmd = parse_cmd_line_args () in
    let ast = Parse.parse ~filename:cmd.filename in
    if Wlp.check_safety ast
    then print_and_exit "valid" Analyze_valid
    else print_and_exit "unsafe" Analyze_unsafe
  with
  | Error_msg.Error -> print_and_exit "error" Analyze_error
  | Invalid_argument e ->
    prerr_endline e;
    print_and_exit "error" Analyze_error
  | Sys_error _ -> print_and_exit "error" Analyze_error
;;
