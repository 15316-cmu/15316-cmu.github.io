(** Top-level CLI for the Lab 1 analyzer (`c0_vc`). *)

type analyze_exit_status =
  | Analyze_valid
  | Analyze_error
  | Analyze_unsafe

let analyze_exit_code = function
  | Analyze_valid -> 0
  | Analyze_error -> 1
  | Analyze_unsafe -> 2
;;

type cmd_line_args =
  { filename : string
  ; verbose : bool
  ; print_vc : bool
  ; small_cex : bool
  ; small_cex_max : int
  }

let print_and_exit (s : string) (code : analyze_exit_status) =
  (try print_endline s with
   | _ -> ());
  Stdlib.exit (analyze_exit_code code)
;;

let parse_cmd_line_args () : cmd_line_args =
  let argv =
    match Array.to_list Sys.argv with
    | _exe :: rest -> rest
    | [] -> []
  in
  let rec loop args acc positional =
    match args with
    | [] -> acc, List.rev positional
    | ("--verbose" | "-v") :: rest -> loop rest { acc with verbose = true } positional
    | "--print-vc" :: rest -> loop rest { acc with print_vc = true } positional
    | "--small-cex" :: rest -> loop rest { acc with small_cex = true } positional
    | "--small-cex-max" :: n :: rest ->
      let max_n =
        try int_of_string n with
        | _ -> print_and_exit "expected integer after --small-cex-max" Analyze_error
      in
      loop rest { acc with small_cex = true; small_cex_max = max_n } positional
    | "--small-cex-max" :: [] -> print_and_exit "expected integer after --small-cex-max" Analyze_error
    | x :: rest ->
      if String.length x > 0 && Char.equal x.[0] '-' then print_and_exit "unknown flag" Analyze_error;
      loop rest acc (x :: positional)
  in
  let defaults = { filename = ""; verbose = false; print_vc = false; small_cex = false; small_cex_max = 32 } in
  let acc, positional = loop argv defaults [] in
  match positional with
  | [ filename ] -> { acc with filename }
  | _ -> print_and_exit "expected 1 argument" Analyze_error
;;

let main () =
  try
    let cmd = parse_cmd_line_args () in
    let ast = Parse.parse ~filename:cmd.filename in
    if Wlp.check_safety ast ~verbose:cmd.verbose ~print_vc:cmd.print_vc ~small_cex:cmd.small_cex ~small_cex_max:cmd.small_cex_max
    then print_and_exit "valid" Analyze_valid
    else print_and_exit "unsafe" Analyze_unsafe
  with
  | Error_msg.Error -> print_and_exit "error" Analyze_error
  | Invalid_argument e ->
    prerr_endline e;
    print_and_exit "error" Analyze_error
  | Sys_error _ -> print_and_exit "error" Analyze_error
;;
