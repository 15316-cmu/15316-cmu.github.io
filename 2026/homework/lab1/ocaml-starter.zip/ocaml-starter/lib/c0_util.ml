(** Utilities for manipulating C0 ASTs (substitution, renaming, printing). *)

open Printf

module StringSet = Set.Make (String)

let set_union_list (sets : StringSet.t list) : StringSet.t =
  List.fold_left StringSet.union StringSet.empty sets
;;

let rec vars_exp (e : Ast.exp) : StringSet.t =
  match e with
  | Ast.Var x -> StringSet.singleton x
  | Ast.IntConst _ | Ast.BoolConst _ | Ast.NullConst | Ast.ResultVar -> StringSet.empty
  | Ast.BinOp (_, l, r) -> StringSet.union (vars_exp l) (vars_exp r)
  | Ast.UnOp (_, a) -> vars_exp a
  | Ast.Length a -> vars_exp a
  | Ast.ArrayAccess (a, i) -> StringSet.union (vars_exp a) (vars_exp i)
  | Ast.ArrMake (len, init) -> StringSet.union (vars_exp len) (vars_exp init)
  | Ast.ArrSet (a, i, v) -> set_union_list [ vars_exp a; vars_exp i; vars_exp v ]
  | Ast.ForAll (bound, body) ->
    List.fold_left (fun acc v -> StringSet.remove v acc) (vars_exp body) bound
;;

let get_fresh_name (base : string) (avoid : StringSet.t) : string =
  if not (StringSet.mem base avoid)
  then base
  else (
    let rec loop i =
      let candidate = sprintf "%s_%d" base i in
      if StringSet.mem candidate avoid then loop (i + 1) else candidate
    in
    loop 0)
;;

let rec subst_exp (e : Ast.exp) ~(x : string) ~(replacement : Ast.exp) : Ast.exp =
  match e with
  | Ast.Var y -> if String.equal x y then replacement else e
  | Ast.IntConst _ | Ast.BoolConst _ | Ast.NullConst -> e
  | Ast.BinOp (op, l, r) -> Ast.BinOp (op, subst_exp l ~x ~replacement, subst_exp r ~x ~replacement)
  | Ast.UnOp (op, a) -> Ast.UnOp (op, subst_exp a ~x ~replacement)
  | Ast.Length a -> Ast.Length (subst_exp a ~x ~replacement)
  | Ast.ArrayAccess (a, i) -> Ast.ArrayAccess (subst_exp a ~x ~replacement, subst_exp i ~x ~replacement)
  | Ast.ResultVar -> e
  | Ast.ArrMake (len, init) -> Ast.ArrMake (subst_exp len ~x ~replacement, subst_exp init ~x ~replacement)
  | Ast.ArrSet (a, i, v) ->
    Ast.ArrSet (subst_exp a ~x ~replacement, subst_exp i ~x ~replacement, subst_exp v ~x ~replacement)
  | Ast.ForAll (bound, body) ->
    if List.exists (fun v -> String.equal v x) bound
    then e
    else (
      let replacement_vars = vars_exp replacement in
      let bound_set =
        List.fold_left (fun acc v -> StringSet.add v acc) StringSet.empty bound
      in
      if StringSet.is_empty (StringSet.inter replacement_vars bound_set)
      then Ast.ForAll (bound, subst_exp body ~x ~replacement)
      else (
        let avoid = set_union_list [ replacement_vars; vars_exp body; bound_set ] in
        let renamed_bound, renamed_body =
          List.fold_left
            (fun (acc_vars, acc_body) bv ->
              if StringSet.mem bv replacement_vars
              then (
                let new_bv = get_fresh_name bv avoid in
                let new_body = subst_exp acc_body ~x:bv ~replacement:(Ast.Var new_bv) in
                acc_vars @ [ new_bv ], new_body)
              else acc_vars @ [ bv ], acc_body)
            ([], body)
            bound
        in
        Ast.ForAll (renamed_bound, subst_exp renamed_body ~x ~replacement)))
;;

let rec subst_result (e : Ast.exp) ~(replacement : Ast.exp) : Ast.exp =
  match e with
  | Ast.ResultVar -> replacement
  | Ast.IntConst _ | Ast.BoolConst _ | Ast.NullConst | Ast.Var _ -> e
  | Ast.BinOp (op, l, r) -> Ast.BinOp (op, subst_result l ~replacement, subst_result r ~replacement)
  | Ast.UnOp (op, a) -> Ast.UnOp (op, subst_result a ~replacement)
  | Ast.Length a -> Ast.Length (subst_result a ~replacement)
  | Ast.ArrayAccess (a, i) -> Ast.ArrayAccess (subst_result a ~replacement, subst_result i ~replacement)
  | Ast.ArrMake (len, init) ->
    Ast.ArrMake (subst_result len ~replacement, subst_result init ~replacement)
  | Ast.ArrSet (a, i, v) ->
    Ast.ArrSet (subst_result a ~replacement, subst_result i ~replacement, subst_result v ~replacement)
  | Ast.ForAll (vars, body) -> Ast.ForAll (vars, subst_result body ~replacement)
;;

let rec get_defs (s : Ast.stmt) : StringSet.t =
  match s with
  | Ast.Decl (_, name, _) -> StringSet.singleton name
  | Ast.Assign (dest, _) -> StringSet.singleton dest
  | Ast.AllocArray (dest, _, _) -> StringSet.singleton dest
  | Ast.ArrRead (dest, _, _) -> StringSet.singleton dest
  | Ast.ArrWrite (arr, _, _) ->
    (match arr with
     | Ast.Var x -> StringSet.singleton x
     | _ -> StringSet.empty)
  | Ast.Block ss -> set_union_list (List.map get_defs ss)
  | Ast.If (_, t, None) -> get_defs t
  | Ast.If (_, t, Some f) -> StringSet.union (get_defs t) (get_defs f)
  | Ast.While (_, _, body) -> get_defs body
  | Ast.Assert _ | Ast.Error _ | Ast.Return _ -> StringSet.empty
;;

module Renamer = struct
  module Tbl = Hashtbl.Make (String)

  type t =
    { mutable scopes : string Tbl.t list
    ; mutable counter : int
    }

  let create () = { scopes = [ Tbl.create 16 ]; counter = 0 }

  let fresh t (base : string) : string =
    t.counter <- t.counter + 1;
    sprintf "%s_%d" base t.counter
  ;;

  let current t (name : string) : string =
    let rec go = function
      | [] -> name
      | scope :: rest ->
        (match Tbl.find_opt scope name with
         | Some v -> v
         | None -> go rest)
    in
    go t.scopes
  ;;

  let enter_scope t = t.scopes <- Tbl.create 16 :: t.scopes
  let exit_scope t = t.scopes <- List.tl t.scopes

  let declare t (name : string) : string =
    let new_name = fresh t name in
    (match t.scopes with
     | scope :: _ -> Tbl.replace scope name new_name
     | [] -> ());
    new_name
  ;;

  let rec rename_exp t (e : Ast.exp) : Ast.exp =
    match e with
    | Ast.Var x -> Ast.Var (current t x)
    | Ast.BinOp (op, l, r) -> Ast.BinOp (op, rename_exp t l, rename_exp t r)
    | Ast.UnOp (op, a) -> Ast.UnOp (op, rename_exp t a)
    | Ast.Length a -> Ast.Length (rename_exp t a)
    | Ast.ArrayAccess (a, i) -> Ast.ArrayAccess (rename_exp t a, rename_exp t i)
    | Ast.ArrMake (len, init) -> Ast.ArrMake (rename_exp t len, rename_exp t init)
    | Ast.ArrSet (a, i, v) -> Ast.ArrSet (rename_exp t a, rename_exp t i, rename_exp t v)
    | Ast.ForAll (vars, body) -> Ast.ForAll (vars, rename_exp t body)
    | _ -> e
  ;;

  let rec rename_stmt t (s : Ast.stmt) : Ast.stmt =
    match s with
    | Ast.Decl (ty, name, init) ->
      let r_init = Option.map (rename_exp t) init in
      let new_name = declare t name in
      Ast.Decl (ty, new_name, r_init)
    | Ast.Assign (dest, src) -> Ast.Assign (current t dest, rename_exp t src)
    | Ast.AllocArray (dest, ty, count) -> Ast.AllocArray (current t dest, ty, rename_exp t count)
    | Ast.ArrRead (dest, arr, idx) -> Ast.ArrRead (current t dest, rename_exp t arr, rename_exp t idx)
    | Ast.ArrWrite (arr, idx, v) -> Ast.ArrWrite (rename_exp t arr, rename_exp t idx, rename_exp t v)
    | Ast.Block ss ->
      enter_scope t;
      let out = Ast.Block (List.map (rename_stmt t) ss) in
      exit_scope t;
      out
    | Ast.If (cond, tb, None) ->
      let r_cond = rename_exp t cond in
      enter_scope t;
      let r_tb = rename_stmt t tb in
      exit_scope t;
      Ast.If (r_cond, r_tb, None)
    | Ast.If (cond, tb, Some fb) ->
      let r_cond = rename_exp t cond in
      enter_scope t;
      let r_tb = rename_stmt t tb in
      exit_scope t;
      enter_scope t;
      let r_fb = rename_stmt t fb in
      exit_scope t;
      Ast.If (r_cond, r_tb, Some r_fb)
    | Ast.While (cond, invs, body) ->
      let r_cond = rename_exp t cond in
      let r_invs = List.map (rename_exp t) invs in
      enter_scope t;
      let r_body = rename_stmt t body in
      exit_scope t;
      Ast.While (r_cond, r_invs, r_body)
    | Ast.Assert c -> Ast.Assert (rename_exp t c)
    | Ast.Return None -> s
    | Ast.Return (Some v) -> Ast.Return (Some (rename_exp t v))
    | _ -> s
  ;;
end

let rename_program (p : Ast.program) : Ast.program =
  let r = Renamer.create () in
  Renamer.enter_scope r;
  let new_args =
    match p.args with
    | None -> None
    | Some args -> Some (List.map (Renamer.declare r) args)
  in
  let new_requires = List.map (Renamer.rename_exp r) p.requires in
  let new_stmts = List.map (Renamer.rename_stmt r) p.stmts in
  let new_ensures = List.map (Renamer.rename_exp r) p.ensures in
  Renamer.exit_scope r;
  { Ast.stmts = new_stmts; requires = new_requires; ensures = new_ensures; args = new_args }
;;

let rec simplify (e : Ast.exp) : Ast.exp =
  let simp = simplify in
  match e with
  | Ast.BinOp ("&&", l, r) ->
    let l = simp l in
    let r = simp r in
    (match l, r with
     | Ast.BoolConst true, x | x, Ast.BoolConst true -> x
     | Ast.BoolConst false, _ | _, Ast.BoolConst false -> Ast.BoolConst false
     | _ -> Ast.BinOp ("&&", l, r))
  | Ast.BinOp ("||", l, r) ->
    let l = simp l in
    let r = simp r in
    (match l, r with
     | Ast.BoolConst false, x | x, Ast.BoolConst false -> x
     | Ast.BoolConst true, _ | _, Ast.BoolConst true -> Ast.BoolConst true
     | _ -> Ast.BinOp ("||", l, r))
  | Ast.BinOp ("=>", l, r) ->
    let l = simp l in
    let r = simp r in
    (match l, r with
     | Ast.BoolConst true, x -> x
     | Ast.BoolConst false, _ -> Ast.BoolConst true
     | _, Ast.BoolConst true -> Ast.BoolConst true
     | _ -> Ast.BinOp ("=>", l, r))
  | Ast.UnOp ("!", a) ->
    let a = simp a in
    (match a with
     | Ast.BoolConst b -> Ast.BoolConst (not b)
     | _ -> Ast.UnOp ("!", a))
  | Ast.BinOp (op, l, r) -> Ast.BinOp (op, simp l, simp r)
  | Ast.UnOp (op, a) -> Ast.UnOp (op, simp a)
  | Ast.Length a -> Ast.Length (simp a)
  | Ast.ArrayAccess (a, i) -> Ast.ArrayAccess (simp a, simp i)
  | Ast.ArrMake (len, init) -> Ast.ArrMake (simp len, simp init)
  | Ast.ArrSet (a, i, v) -> Ast.ArrSet (simp a, simp i, simp v)
  | Ast.ForAll (vars, body) -> Ast.ForAll (vars, simp body)
  | _ -> e
;;

let rec stringify ?(pretty = false) (e : Ast.exp) : string =
  let s = stringify ~pretty in
  match e with
  | Ast.IntConst n -> Zarith.to_string n
  | Ast.BoolConst true -> "true"
  | Ast.BoolConst false -> "false"
  | Ast.NullConst -> "NULL"
  | Ast.Var x -> x
  | Ast.ResultVar -> "\\result"
  | Ast.Length a -> sprintf "\\length(%s)" (s a)
  | Ast.ArrayAccess (a, i) -> sprintf "%s[%s]" (s a) (s i)
  | Ast.ArrMake (len, init) -> sprintf "ArrMake(%s, %s)" (s len) (s init)
  | Ast.ArrSet (a, i, v) -> sprintf "ArrSet(%s, %s, %s)" (s a) (s i) (s v)
  | Ast.UnOp (op, a) -> sprintf "(%s%s)" op (s a)
  | Ast.BinOp (op, l, r) -> sprintf "(%s %s %s)" (s l) op (s r)
  | Ast.ForAll (vars, body) ->
    if pretty
    then sprintf "forall %s ::\n  %s" (String.concat ", " vars) (s body)
    else sprintf "forall %s :: %s" (String.concat "," vars) (s body)
;;

let stringify_stmt (s : Ast.stmt) : string =
  match s with
  | Ast.Decl (ty, name, None) -> sprintf "%s %s" (Ast.string_of_typ ty) name
  | Ast.Decl (ty, name, Some init) ->
    sprintf "%s %s = %s" (Ast.string_of_typ ty) name (stringify init)
  | Ast.Assign (dest, src) -> sprintf "%s = %s" dest (stringify src)
  | Ast.AllocArray (dest, ty, count) ->
    sprintf "%s = alloc_array(%s, %s)" dest (Ast.string_of_typ ty) (stringify count)
  | Ast.ArrRead (dest, arr, idx) -> sprintf "%s = %s[%s]" dest (stringify arr) (stringify idx)
  | Ast.ArrWrite (arr, idx, v) -> sprintf "%s[%s] = %s" (stringify arr) (stringify idx) (stringify v)
  | Ast.Block _ -> "Block {...}"
  | Ast.If (cond, _, _) -> sprintf "if (%s) ..." (stringify cond)
  | Ast.While (cond, _, _) -> sprintf "while (%s) ..." (stringify cond)
  | Ast.Assert cond -> sprintf "assert(%s)" (stringify cond)
  | Ast.Error msg -> sprintf "error(%s)" msg
  | Ast.Return None -> "return"
  | Ast.Return (Some v) -> sprintf "return %s" (stringify v)
;;
