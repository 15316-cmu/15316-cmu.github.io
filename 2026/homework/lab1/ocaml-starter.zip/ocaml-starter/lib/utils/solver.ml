(** Z3 theorem prover wrapper for the Lab 1 C0-Arrays encoding. *)

open Printf

type solve_result =
  | Valid
  | Countermodel of Z3.Model.model
  | Unknown of string

let bit_width = 64

let mk_ctx () =
  let cfg = [ "model", "true"; "proof", "false" ] in
  Z3.mk_context cfg
;;

let int_sort ctx = Z3.BitVector.mk_sort ctx bit_width

type arr_dt =
  { sort : Z3.Sort.sort
  ; mk : Z3.FuncDecl.func_decl
  ; len : Z3.FuncDecl.func_decl
  ; data : Z3.FuncDecl.func_decl
  }

let mk_arr_dt ctx : arr_dt =
  let s_int = int_sort ctx in
  let s_data = Z3.Z3Array.mk_sort ctx s_int s_int in
  let ctor =
    Z3.Datatype.mk_constructor
      ctx
      (Z3.Symbol.mk_string ctx "mk")
      (Z3.Symbol.mk_string ctx "is_mk")
      [ Z3.Symbol.mk_string ctx "len"; Z3.Symbol.mk_string ctx "data" ]
      [ Some s_int; Some s_data ]
      [ 0; 0 ]
  in
  let sort = Z3.Datatype.mk_sort_s ctx "Arr" [ ctor ] in
  let mk = Z3.Datatype.Constructor.get_constructor_decl ctor in
  let accessors = Z3.Datatype.Constructor.get_accessor_decls ctor in
  let len =
    match accessors with
    | d :: _ -> d
    | [] -> failwith "Arr datatype missing len accessor"
  in
  let data =
    match accessors with
    | _ :: d :: _ -> d
    | _ -> failwith "Arr datatype missing data accessor"
  in
  { sort; mk; len; data }
;;

let var_types : (string, Ast.typ) Hashtbl.t = Hashtbl.create 64

let set_var_types (vars : (string * Ast.typ) list) : unit =
  Hashtbl.reset var_types;
  List.iter (fun (name, ty) -> Hashtbl.replace var_types name ty) vars
;;

let get_z3_var ctx (arr : arr_dt) (name : string) : Z3.Expr.expr =
  match Hashtbl.find_opt var_types name with
  | Some Ast.BoolType -> Z3.Boolean.mk_const_s ctx name
  | Some (Ast.ArrayType Ast.IntType) -> Z3.Expr.mk_const_s ctx name arr.sort
  | _ -> Z3.BitVector.mk_const_s ctx name bit_width
;;

let rec exp_enc ctx (arr : arr_dt) (e : Ast.exp) : Z3.Expr.expr =
  match e with
  | Ast.IntConst n -> Z3.BitVector.mk_numeral ctx (Zarith.to_string n) bit_width
  | Ast.BoolConst b -> Z3.Boolean.mk_val ctx b
  | Ast.NullConst -> Z3.BitVector.mk_numeral ctx "0" bit_width
  | Ast.Var x -> get_z3_var ctx arr x
  | Ast.ResultVar -> failwith "\\result should be eliminated before solving"
  | Ast.UnOp ("!", a) -> Z3.Boolean.mk_not ctx (exp_enc ctx arr a)
  | Ast.UnOp ("-", a) -> Z3.BitVector.mk_neg ctx (exp_enc ctx arr a)
  | Ast.UnOp (op, _) -> failwith (sprintf "unknown unop: %s" op)
  | Ast.BinOp (op, l, r) ->
    let el = exp_enc ctx arr l in
    let er = exp_enc ctx arr r in
    (match op with
     | "==" -> Z3.Boolean.mk_eq ctx el er
     | "!=" -> Z3.Boolean.mk_not ctx (Z3.Boolean.mk_eq ctx el er)
     | _ ->
       if Z3.BitVector.is_bv el && Z3.BitVector.is_bv er
       then (
         match op with
         | "+" -> Z3.BitVector.mk_add ctx el er
         | "-" -> Z3.BitVector.mk_sub ctx el er
         | "*" -> Z3.BitVector.mk_mul ctx el er
         | "/" -> Z3.BitVector.mk_sdiv ctx el er
         | "%" -> Z3.BitVector.mk_srem ctx el er
         | "<" -> Z3.BitVector.mk_slt ctx el er
         | "<=" -> Z3.BitVector.mk_sle ctx el er
         | ">" -> Z3.BitVector.mk_sgt ctx el er
         | ">=" -> Z3.BitVector.mk_sge ctx el er
         | _ -> failwith (sprintf "unknown bv binop: %s" op))
       else if Z3.Boolean.is_bool el && Z3.Boolean.is_bool er
       then (
         match op with
         | "&&" -> Z3.Boolean.mk_and ctx [ el; er ]
         | "||" -> Z3.Boolean.mk_or ctx [ el; er ]
         | "=>" -> Z3.Boolean.mk_implies ctx el er
         | _ -> failwith (sprintf "unknown bool binop: %s" op))
       else failwith (sprintf "sort mismatch for binop: %s" op))
  | Ast.Length a ->
    let za = exp_enc ctx arr a in
    Z3.Expr.mk_app ctx arr.len [ za ]
  | Ast.ArrayAccess (a, i) ->
    let za = exp_enc ctx arr a in
    let zi = exp_enc ctx arr i in
    let zdata = Z3.Expr.mk_app ctx arr.data [ za ] in
    Z3.Z3Array.mk_select ctx zdata zi
  | Ast.ArrMake (len, init) ->
    let zlen = exp_enc ctx arr len in
    let zinit = exp_enc ctx arr init in
    let zdata = Z3.Z3Array.mk_const_array ctx (int_sort ctx) zinit in
    Z3.Expr.mk_app ctx arr.mk [ zlen; zdata ]
  | Ast.ArrSet (a, i, v) ->
    let za = exp_enc ctx arr a in
    let zi = exp_enc ctx arr i in
    let zv = exp_enc ctx arr v in
    let zlen = Z3.Expr.mk_app ctx arr.len [ za ] in
    let zdata = Z3.Expr.mk_app ctx arr.data [ za ] in
    let zdata' = Z3.Z3Array.mk_store ctx zdata zi zv in
    Z3.Expr.mk_app ctx arr.mk [ zlen; zdata' ]
  | Ast.ForAll (vars, body) ->
    let zvars = List.map (fun v -> Z3.BitVector.mk_const_s ctx v bit_width) vars in
    let q =
      Z3.Quantifier.mk_forall_const ctx zvars (exp_enc ctx arr body) None [] [] None None
    in
    Z3.Quantifier.expr_of_quantifier q
;;

let solve (f : Ast.exp) : solve_result =
  let ctx = mk_ctx () in
  let arr = mk_arr_dt ctx in
  let solver = Z3.Solver.mk_simple_solver ctx in
  let zf = exp_enc ctx arr f in
  let vc = Z3.Boolean.mk_not ctx zf |> fun e -> Z3.Expr.simplify e None in
  Z3.Solver.add solver [ vc ];
  match Z3.Solver.check solver [] with
  | Z3.Solver.UNSATISFIABLE -> Valid
  | Z3.Solver.SATISFIABLE ->
    (match Z3.Solver.get_model solver with
     | Some m -> Countermodel m
     | None -> Unknown "SAT but no model")
  | Z3.Solver.UNKNOWN ->
    let r = Z3.Solver.get_reason_unknown solver in
    Unknown r
;;

let check_validity (f : Ast.exp) : bool =
  match solve f with
  | Valid -> true
  | Countermodel _ | Unknown _ -> false
;;
