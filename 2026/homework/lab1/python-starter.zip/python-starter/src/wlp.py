"""WLP-based memory safety checker (students implement)."""

from __future__ import annotations

import c0
import solver


def check_safety(
    prog: c0.Program,
) -> bool:
    raise NotImplementedError("check_safety is not implemented")
