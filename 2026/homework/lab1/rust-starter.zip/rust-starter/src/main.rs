mod ast;
mod parse;
mod solver;
mod wlp;

use lalrpop_util::lalrpop_mod;

lalrpop_mod!(pub c0);

fn print_and_exit(msg: &str, code: i32) -> ! {
    let _ = println!("{msg}");
    std::process::exit(code)
}

fn main() {
    let argv: Vec<String> = std::env::args().skip(1).collect();
    if argv.len() != 1 {
        print_and_exit("error", 1);
    }
    let filename = &argv[0];

    let src = match std::fs::read_to_string(filename) {
        Ok(s) => s,
        Err(_e) => {
            print_and_exit("error", 1)
        }
    };

    let prog = match parse::parse_program(&src) {
        Ok(p) => p,
        Err(_e) => {
            print_and_exit("error", 1)
        }
    };

    let ok = match std::panic::catch_unwind(|| wlp::check_safety(&prog)) {
        Ok(b) => b,
        Err(_) => print_and_exit("error", 1),
    };
    if ok {
        print_and_exit("valid", 0);
    } else {
        print_and_exit("unsafe", 2);
    }
}
