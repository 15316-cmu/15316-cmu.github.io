mod ast;
mod parse;
mod solver;
mod wlp;

use lalrpop_util::lalrpop_mod;

lalrpop_mod!(pub c0);

#[derive(Clone)]
struct CmdLineArgs {
    filename: String,
    verbose: bool,
    print_vc: bool,
    small_cex: bool,
    small_cex_max: usize,
}

fn print_and_exit(msg: &str, code: i32) -> ! {
    let _ = println!("{msg}");
    std::process::exit(code)
}

fn parse_cmd_line_args(argv: &[String]) -> CmdLineArgs {
    let mut verbose = false;
    let mut print_vc = false;
    let mut small_cex = false;
    let mut small_cex_max: usize = 32;
    let mut positional: Vec<String> = Vec::new();

    let mut i = 0;
    while i < argv.len() {
        let a = &argv[i];
        match a.as_str() {
            "--verbose" | "-v" => {
                verbose = true;
                i += 1;
            }
            "--print-vc" => {
                print_vc = true;
                i += 1;
            }
            "--small-cex" => {
                small_cex = true;
                i += 1;
            }
            "--small-cex-max" => {
                if i + 1 >= argv.len() {
                    print_and_exit("expected integer after --small-cex-max", 1);
                }
                small_cex = true;
                small_cex_max = argv[i + 1]
                    .parse::<usize>()
                    .unwrap_or_else(|_| print_and_exit("expected integer after --small-cex-max", 1));
                i += 2;
            }
            _ if a.starts_with('-') => print_and_exit("error", 1),
            _ => {
                positional.push(a.clone());
                i += 1;
            }
        }
    }

    if positional.len() != 1 {
        print_and_exit("error", 1);
    }

    CmdLineArgs {
        filename: positional[0].clone(),
        verbose,
        print_vc,
        small_cex,
        small_cex_max,
    }
}

fn main() {
    let argv: Vec<String> = std::env::args().skip(1).collect();
    let cmd = parse_cmd_line_args(&argv);

    let src = match std::fs::read_to_string(&cmd.filename) {
        Ok(s) => s,
        Err(e) => {
            if cmd.verbose {
                eprintln!("{e}");
            }
            print_and_exit("error", 1)
        }
    };

    let prog = match parse::parse_program(&src) {
        Ok(p) => p,
        Err(e) => {
            if cmd.verbose {
                eprintln!("{e}");
            }
            print_and_exit("error", 1)
        }
    };

    let ok = match std::panic::catch_unwind(|| {
        wlp::check_safety(
            &prog,
            cmd.verbose,
            cmd.print_vc,
            cmd.small_cex,
            cmd.small_cex_max,
        )
    }) {
        Ok(b) => b,
        Err(_) => print_and_exit("error", 1),
    };
    if ok {
        print_and_exit("valid", 0);
    } else {
        print_and_exit("unsafe", 2);
    }
}
