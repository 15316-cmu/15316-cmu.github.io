use crate::ast::{Exp, Program, Stmt, Type};
use crate::c0::ProgramParser;
use std::collections::HashMap;

fn check_ident_ok(name: &str) -> Result<(), String> {
    if name.starts_with('_') {
        Err(format!("reserved identifier: {name}"))
    } else {
        Ok(())
    }
}

fn check_exp_idents(e: &Exp) -> Result<(), String> {
    match e {
        Exp::Var(x) => check_ident_ok(x),
        Exp::BinOp(_, l, r) => {
            check_exp_idents(l)?;
            check_exp_idents(r)
        }
        Exp::UnOp(_, a) | Exp::Length(a) => check_exp_idents(a),
        Exp::ArrayAccess(a, i) => {
            check_exp_idents(a)?;
            check_exp_idents(i)
        }
        Exp::ArrMake(len, init) => {
            check_exp_idents(len)?;
            check_exp_idents(init)
        }
        Exp::ArrSet(a, i, v) => {
            check_exp_idents(a)?;
            check_exp_idents(i)?;
            check_exp_idents(v)
        }
        Exp::ForAll(vars, body) => {
            for v in vars {
                check_ident_ok(v)?;
            }
            check_exp_idents(body)
        }
        _ => Ok(()),
    }
}

fn check_stmt_idents(s: &Stmt) -> Result<(), String> {
    match s {
        Stmt::Decl(_, x, init) => {
            check_ident_ok(x)?;
            if let Some(e) = init {
                check_exp_idents(e)?;
            }
            Ok(())
        }
        Stmt::Assign(x, e) => {
            check_ident_ok(x)?;
            check_exp_idents(e)
        }
        Stmt::AllocArray(x, _, n) => {
            check_ident_ok(x)?;
            check_exp_idents(n)
        }
        Stmt::ArrWrite(a, i, v) => {
            check_exp_idents(a)?;
            check_exp_idents(i)?;
            check_exp_idents(v)
        }
        Stmt::Assert(c) => check_exp_idents(c),
        Stmt::If(c, t, f) => {
            check_exp_idents(c)?;
            check_stmt_idents(t)?;
            if let Some(ff) = f {
                check_stmt_idents(ff)?;
            }
            Ok(())
        }
        Stmt::While(c, invs, body) => {
            check_exp_idents(c)?;
            for inv in invs {
                check_exp_idents(inv)?;
            }
            check_stmt_idents(body)
        }
        Stmt::Block(ss) => {
            for st in ss {
                check_stmt_idents(st)?;
            }
            Ok(())
        }
        Stmt::Return(Some(v)) => check_exp_idents(v),
        _ => Ok(()),
    }
}

fn strip_comments_and_rewrite_annotations(src: &str) -> String {
    let mut out = String::with_capacity(src.len());
    let mut chars = src.chars().peekable();
    let mut in_block_comment = false;
    let mut in_string = false;

    while let Some(c) = chars.next() {
        if in_block_comment {
            if c == '*' && chars.peek() == Some(&'/') {
                chars.next();
                in_block_comment = false;
                continue;
            }
            if c == '\n' {
                out.push('\n');
            }
            continue;
        }

        if !in_string {
            if c == '/' && chars.peek() == Some(&'*') {
                chars.next();
                in_block_comment = true;
                continue;
            }

            if c == '/' && chars.peek() == Some(&'/') {
                chars.next();
                if chars.peek() == Some(&'@') {
                    chars.next(); // consume '@'
                    let mut line = String::new();
                    while let Some(&ch) = chars.peek() {
                        chars.next();
                        if ch == '\n' {
                            break;
                        }
                        line.push(ch);
                    }
                    let trimmed = line.trim_start();
                    if trimmed.starts_with("assert") {
                        let rest = trimmed.strip_prefix("assert").unwrap();
                        // Expect "... ;" at end; rewrite to assert(<...>);
                        let rest = rest.trim_start();
                        if let Some(pos) = rest.rfind(';') {
                            let expr = rest[..pos].trim();
                            out.push_str("assert(");
                            out.push_str(expr);
                            out.push_str(");");
                            out.push('\n');
                        } else {
                            out.push_str("assert(");
                            out.push_str(rest);
                            out.push_str(");");
                            out.push('\n');
                        }
                    } else {
                        out.push_str(trimmed);
                        out.push('\n');
                    }
                } else {
                    // Normal line comment; skip to end of line
                    while let Some(&ch) = chars.peek() {
                        chars.next();
                        if ch == '\n' {
                            out.push('\n');
                            break;
                        }
                    }
                }
                continue;
            }
        }

        if c == '"' {
            in_string = !in_string;
        }
        out.push(c);
    }

    out
}

fn stmt_contains_return(s: &Stmt) -> bool {
    match s {
        Stmt::Return(_) => true,
        Stmt::Block(ss) => ss.iter().any(stmt_contains_return),
        Stmt::If(_, t, None) => stmt_contains_return(t),
        Stmt::If(_, t, Some(f)) => stmt_contains_return(t) || stmt_contains_return(f),
        Stmt::While(_, _, body) => stmt_contains_return(body),
        _ => false,
    }
}

fn exp_contains_result(e: &Exp) -> bool {
    match e {
        Exp::ResultVar => true,
        Exp::BinOp(_, l, r) => exp_contains_result(l) || exp_contains_result(r),
        Exp::UnOp(_, a) | Exp::Length(a) => exp_contains_result(a),
        Exp::ArrayAccess(a, i) => exp_contains_result(a) || exp_contains_result(i),
        Exp::ForAll(_, body) => exp_contains_result(body),
        _ => false,
    }
}

fn stmt_contains_result(s: &Stmt) -> bool {
    match s {
        Stmt::Decl(_, _, Some(init)) => exp_contains_result(init),
        Stmt::Assign(_, src) => exp_contains_result(src),
        Stmt::AllocArray(_, _, count) => exp_contains_result(count),
        Stmt::ArrWrite(a, i, v) => exp_contains_result(a) || exp_contains_result(i) || exp_contains_result(v),
        Stmt::Assert(c) => exp_contains_result(c),
        Stmt::If(c, t, None) => exp_contains_result(c) || stmt_contains_result(t),
        Stmt::If(c, t, Some(f)) => exp_contains_result(c) || stmt_contains_result(t) || stmt_contains_result(f),
        Stmt::While(c, invs, body) => {
            exp_contains_result(c) || invs.iter().any(exp_contains_result) || stmt_contains_result(body)
        }
        Stmt::Block(ss) => ss.iter().any(stmt_contains_result),
        Stmt::Return(Some(v)) => exp_contains_result(v),
        _ => false,
    }
}

fn is_len_result(e: &Exp) -> bool {
    matches!(e, Exp::Length(a) if matches!(**a, Exp::ResultVar))
}

fn is_result_only_in_len_result(e: &Exp) -> bool {
    match e {
        Exp::ResultVar => false,
        Exp::Length(a) => matches!(**a, Exp::ResultVar) || is_result_only_in_len_result(a),
        Exp::BinOp(_, l, r) => is_result_only_in_len_result(l) && is_result_only_in_len_result(r),
        Exp::UnOp(_, a) => is_result_only_in_len_result(a),
        Exp::ArrayAccess(a, i) => is_result_only_in_len_result(a) && is_result_only_in_len_result(i),
        Exp::ArrMake(len, init) => is_result_only_in_len_result(len) && is_result_only_in_len_result(init),
        Exp::ArrSet(a, i, v) =>
            is_result_only_in_len_result(a) && is_result_only_in_len_result(i) && is_result_only_in_len_result(v),
        Exp::ForAll(_, body) => is_result_only_in_len_result(body),
        _ => true,
    }
}

fn is_len_result_eq(e: &Exp) -> bool {
    match e {
        Exp::BinOp(op, l, r) if op == "==" => {
            (is_len_result(l) && is_result_only_in_len_result(r))
                || (is_len_result(r) && is_result_only_in_len_result(l))
        }
        _ => false,
    }
}

fn typecheck_and_validate_program(prog: &Program) -> Result<(), String> {
    fn lookup(env: &[HashMap<String, Type>], name: &str) -> Result<Type, String> {
        for scope in env.iter().rev() {
            if let Some(t) = scope.get(name) {
                return Ok(t.clone());
            }
        }
        Err(format!("use of undeclared variable `{name}`"))
    }

    fn exp_type(env: &mut Vec<HashMap<String, Type>>, e: &Exp) -> Result<Type, String> {
        match e {
            Exp::IntConst(_) => Ok(Type::Int),
            Exp::BoolConst(_) => Ok(Type::Bool),
            Exp::Var(x) => lookup(env, x),
            Exp::ResultVar => Ok(Type::IntArray),
            Exp::Length(a) => {
                let t = exp_type(env, a)?;
                if t != Type::IntArray {
                    return Err("\\length expects an `int[]` expression".to_string());
                }
                Ok(Type::Int)
            }
            Exp::ArrayAccess(a, i) => {
                let ta = exp_type(env, a)?;
                let ti = exp_type(env, i)?;
                if ta != Type::IntArray {
                    return Err("array indexing expects an `int[]` base expression".to_string());
                }
                if ti != Type::Int {
                    return Err("array index must have type `int`".to_string());
                }
                Ok(Type::Int)
            }
            Exp::UnOp(op, a) if op == "!" => {
                let ta = exp_type(env, a)?;
                if ta != Type::Bool {
                    return Err("`!` expects a `bool` operand".to_string());
                }
                Ok(Type::Bool)
            }
            Exp::UnOp(op, a) if op == "-" => {
                let ta = exp_type(env, a)?;
                if ta != Type::Int {
                    return Err("unary `-` expects an `int` operand".to_string());
                }
                Ok(Type::Int)
            }
            Exp::UnOp(op, _) => Err(format!("unknown unary operator `{op}`")),
            Exp::BinOp(op, l, r) => {
                let tl = exp_type(env, l)?;
                let tr = exp_type(env, r)?;
                let arith = ["+", "-", "*", "/", "%"];
                let cmp_ops = ["<", "<=", ">", ">="];
                let logic = ["&&", "||", "=>"];
                let eq = ["==", "!="];

                if arith.contains(&op.as_str()) {
                    if tl != Type::Int || tr != Type::Int {
                        return Err(format!("`{op}` expects `int` operands"));
                    }
                    Ok(Type::Int)
                } else if cmp_ops.contains(&op.as_str()) {
                    if tl != Type::Int || tr != Type::Int {
                        return Err(format!("`{op}` expects `int` operands"));
                    }
                    Ok(Type::Bool)
                } else if logic.contains(&op.as_str()) {
                    if tl != Type::Bool || tr != Type::Bool {
                        return Err(format!("`{op}` expects `bool` operands"));
                    }
                    Ok(Type::Bool)
                } else if eq.contains(&op.as_str()) {
                    if tl != tr {
                        return Err(format!("`{op}` expects operands of the same type"));
                    }
                    Ok(Type::Bool)
                } else {
                    Err(format!("unknown binary operator `{op}`"))
                }
            }
            Exp::ForAll(vars, body) => {
                env.push(HashMap::new());
                for v in vars {
                    env.last_mut().unwrap().insert(v.clone(), Type::Int);
                }
                let tb = exp_type(env, body)?;
                env.pop();
                if tb != Type::Bool {
                    return Err("\\forall body must be a boolean formula".to_string());
                }
                Ok(Type::Bool)
            }
            Exp::ArrMake(_, _) | Exp::ArrSet(_, _, _) => Err(
                "internal array-value nodes should not appear in source programs".to_string(),
            ),
        }
    }

    fn check_stmt(env: &mut Vec<HashMap<String, Type>>, s: &Stmt) -> Result<(), String> {
        match s {
            Stmt::Decl(ty, name, init) => {
                if *ty == Type::IntArray && init.is_some() {
                    return Err(
                        "`int[]` variables cannot be initialized by assignment; use `alloc_array`".to_string(),
                    );
                }
                if let Some(e) = init {
                    let te = exp_type(env, e)?;
                    if te != *ty {
                        return Err(format!("type mismatch in initializer for `{name}`"));
                    }
                }
                env.last_mut().unwrap().insert(name.clone(), ty.clone());
                Ok(())
            }
            Stmt::Assign(dest, src) => {
                let td = lookup(env, dest)?;
                if td == Type::IntArray {
                    return Err("assignment between `int[]` variables is not allowed (use `alloc_array` or indexed assignment)".to_string());
                }
                let ts = exp_type(env, src)?;
                if ts != td {
                    return Err(format!("type mismatch in assignment to `{dest}`"));
                }
                Ok(())
            }
            Stmt::AllocArray(dest, ty, count) => {
                let td = lookup(env, dest)?;
                if td != Type::IntArray {
                    return Err("`alloc_array` destination must have type `int[]`".to_string());
                }
                if *ty != Type::Int {
                    return Err("only `alloc_array(int, n)` is supported".to_string());
                }
                let tc = exp_type(env, count)?;
                if tc != Type::Int {
                    return Err("`alloc_array` count must have type `int`".to_string());
                }
                Ok(())
            }
            Stmt::ArrWrite(arr, idx, v) => {
                match arr {
                    Exp::Var(a_name) => {
                        let ta = lookup(env, a_name)?;
                        if ta != Type::IntArray {
                            return Err("array assignment expects an `int[]` base variable".to_string());
                        }
                    }
                    _ => {
                        return Err(
                            "array assignment must have the form `A[i] = e` where `A` is a variable".to_string(),
                        );
                    }
                }
                if exp_type(env, idx)? != Type::Int {
                    return Err("array index must have type `int`".to_string());
                }
                if exp_type(env, v)? != Type::Int {
                    return Err("array element value must have type `int`".to_string());
                }
                Ok(())
            }
            Stmt::Block(ss) => {
                env.push(HashMap::new());
                for st in ss {
                    check_stmt(env, st)?;
                }
                env.pop();
                Ok(())
            }
            Stmt::If(cond, t, None) => {
                if exp_type(env, cond)? != Type::Bool {
                    return Err("`if` condition must have type `bool`".to_string());
                }
                env.push(HashMap::new());
                check_stmt(env, t)?;
                env.pop();
                Ok(())
            }
            Stmt::If(cond, t, Some(f)) => {
                if exp_type(env, cond)? != Type::Bool {
                    return Err("`if` condition must have type `bool`".to_string());
                }
                env.push(HashMap::new());
                check_stmt(env, t)?;
                env.pop();
                env.push(HashMap::new());
                check_stmt(env, f)?;
                env.pop();
                Ok(())
            }
            Stmt::While(cond, invs, body) => {
                if exp_type(env, cond)? != Type::Bool {
                    return Err("`while` condition must have type `bool`".to_string());
                }
                for inv in invs {
                    if exp_type(env, inv)? != Type::Bool {
                        return Err("loop invariants must have type `bool`".to_string());
                    }
                }
                env.push(HashMap::new());
                check_stmt(env, body)?;
                env.pop();
                Ok(())
            }
            Stmt::Assert(cond) => {
                if exp_type(env, cond)? != Type::Bool {
                    return Err("`assert` condition must have type `bool`".to_string());
                }
                Ok(())
            }
            Stmt::Return(None) => Err("main must return an `int[]` expression".to_string()),
            Stmt::Return(Some(v)) => {
                if exp_type(env, v)? != Type::IntArray {
                    return Err("main must return an `int[]` expression".to_string());
                }
                Ok(())
            }
            Stmt::Error(_) => Ok(()),
        }
    }

    let mut env: Vec<HashMap<String, Type>> = vec![HashMap::new()];
    if let Some((argc, input)) = &prog.args {
        env[0].insert(argc.clone(), Type::Int);
        env[0].insert(input.clone(), Type::IntArray);
    }

    for e in &prog.requires {
        if exp_type(&mut env, e)? != Type::Bool {
            return Err("requires clauses must be boolean formulas".to_string());
        }
    }
    for e in &prog.ensures {
        if exp_type(&mut env, e)? != Type::Bool {
            return Err("ensures clauses must be boolean formulas".to_string());
        }
    }
    for s in &prog.stmts {
        check_stmt(&mut env, s)?;
    }
    Ok(())
}

struct TempFactory {
    counter: usize,
}

impl TempFactory {
    fn new() -> Self {
        Self { counter: 0 }
    }
    fn fresh(&mut self) -> String {
        self.counter += 1;
        format!("_t{}", self.counter)
    }
}

fn hoist_exp(e: &Exp, tf: &mut TempFactory) -> (Exp, Vec<Stmt>) {
    match e {
        Exp::IntConst(_) | Exp::BoolConst(_) | Exp::Var(_) | Exp::ResultVar => (e.clone(), vec![]),
        Exp::BinOp(op, l, r) => {
            let (sl, al) = hoist_exp(l, tf);
            let (sr, ar) = hoist_exp(r, tf);
            let mut setup = Vec::new();
            setup.extend(al);
            setup.extend(ar);
            if op == "/" || op == "%" {
                let tmp = tf.fresh();
                setup.push(Stmt::Decl(Type::Int, tmp.clone(), None));
                setup.push(Stmt::Assign(
                    tmp.clone(),
                    Exp::BinOp(op.clone(), Box::new(sl), Box::new(sr)),
                ));
                (Exp::Var(tmp), setup)
            } else {
                (Exp::BinOp(op.clone(), Box::new(sl), Box::new(sr)), setup)
            }
        }
        Exp::UnOp(op, a) => {
            let (sa, aa) = hoist_exp(a, tf);
            (Exp::UnOp(op.clone(), Box::new(sa)), aa)
        }
        Exp::Length(a) => {
            let (sa, aa) = hoist_exp(a, tf);
            (Exp::Length(Box::new(sa)), aa)
        }
        Exp::ArrayAccess(a, i) => {
            let (sa, aa) = hoist_exp(a, tf);
            let (si, ai) = hoist_exp(i, tf);
            let mut setup = Vec::new();
            setup.extend(aa);
            setup.extend(ai);
            let tmp = tf.fresh();
            setup.push(Stmt::Decl(Type::Int, tmp.clone(), None));
            setup.push(Stmt::Assign(
                tmp.clone(),
                Exp::ArrayAccess(Box::new(sa), Box::new(si)),
            ));
            (Exp::Var(tmp), setup)
        }
        _ => (e.clone(), vec![]),
    }
}

fn as_stmt(ss: Vec<Stmt>) -> Stmt {
    if ss.len() == 1 {
        ss.into_iter().next().unwrap()
    } else {
        Stmt::Block(ss)
    }
}

fn normalize_stmt_list(s: &Stmt, tf: &mut TempFactory) -> Vec<Stmt> {
    match s {
        Stmt::Decl(t, name, None) => vec![Stmt::Decl(t.clone(), name.clone(), None)],
        Stmt::Decl(t, name, Some(init)) => {
            let (si, ai) = hoist_exp(init, tf);
            let mut out = ai;
            out.push(Stmt::Decl(t.clone(), name.clone(), Some(si)));
            out
        }
        Stmt::Assign(dest, src) => {
            let (ss, aa) = hoist_exp(src, tf);
            let mut out = aa;
            out.push(Stmt::Assign(dest.clone(), ss));
            out
        }
        Stmt::AllocArray(dest, ty, count) => {
            let (sc, ac) = hoist_exp(count, tf);
            let mut out = ac;
            out.push(Stmt::AllocArray(dest.clone(), ty.clone(), sc));
            out
        }
        Stmt::ArrWrite(a, i, v) => {
            let (sa, aa) = hoist_exp(a, tf);
            let (si, ai) = hoist_exp(i, tf);
            let (sv, av) = hoist_exp(v, tf);
            let mut out = Vec::new();
            out.extend(aa);
            out.extend(ai);
            out.extend(av);
            out.push(Stmt::ArrWrite(sa, si, sv));
            out
        }
        Stmt::If(cond, t, None) => {
            let (sc, ac) = hoist_exp(cond, tf);
            let tb = as_stmt(normalize_stmt_list(t, tf));
            let mut out = ac;
            out.push(Stmt::If(sc, Box::new(tb), None));
            out
        }
        Stmt::If(cond, t, Some(f)) => {
            let (sc, ac) = hoist_exp(cond, tf);
            let tb = as_stmt(normalize_stmt_list(t, tf));
            let fb = as_stmt(normalize_stmt_list(f, tf));
            let mut out = ac;
            out.push(Stmt::If(sc, Box::new(tb), Some(Box::new(fb))));
            out
        }
        Stmt::While(cond, invs, body) => {
            let (sc, ac) = hoist_exp(cond, tf);
            let recompute: Vec<Stmt> = ac
                .iter()
                .filter(|st| !matches!(st, Stmt::Decl(_, _, _)))
                .cloned()
                .collect();
            let body_stmt = as_stmt(normalize_stmt_list(body, tf));
            let new_body = match body_stmt {
                Stmt::Block(mut ss) => {
                    ss.extend(recompute);
                    Stmt::Block(ss)
                }
                other => {
                    let mut ss = vec![other];
                    ss.extend(recompute);
                    Stmt::Block(ss)
                }
            };
            let mut out = ac;
            out.push(Stmt::While(sc, invs.clone(), Box::new(new_body)));
            out
        }
        Stmt::Block(ss) => vec![Stmt::Block(
            ss.iter()
                .flat_map(|st| normalize_stmt_list(st, tf))
                .collect(),
        )],
        Stmt::Assert(cond) => {
            let (sc, ac) = hoist_exp(cond, tf);
            let mut out = ac;
            out.push(Stmt::Assert(sc));
            out
        }
        Stmt::Return(Some(v)) => {
            let (sv, av) = hoist_exp(v, tf);
            let mut out = av;
            out.push(Stmt::Return(Some(sv)));
            out
        }
        _ => vec![s.clone()],
    }
}

fn normalize_program(p: &Program) -> Program {
    let mut tf = TempFactory::new();
    let mut new_stmts = Vec::new();
    for s in &p.stmts {
        new_stmts.extend(normalize_stmt_list(s, &mut tf));
    }
    Program {
        stmts: new_stmts,
        requires: p.requires.clone(),
        ensures: p.ensures.clone(),
        args: p.args.clone(),
    }
}

pub fn parse_program(input: &str) -> Result<Program, String> {
    let stripped = strip_comments_and_rewrite_annotations(input);
    let mut prog = ProgramParser::new()
        .parse(&stripped)
        .map_err(|e| format!("{e:?}"))?;

    // Check that user identifiers won't collide with internal names.
    if let Some((argc_name, in_name)) = &prog.args {
        check_ident_ok(argc_name)?;
        check_ident_ok(in_name)?;
    }
    for e in &prog.requires {
        check_exp_idents(e)?;
    }
    for e in &prog.ensures {
        check_exp_idents(e)?;
    }
    for s in &prog.stmts {
        check_stmt_idents(s)?;
    }

    // Post-parse validation mirroring python-refsol
    if prog.ensures.is_empty() {
        return Err("main must include at least one ensures of the form `\\length(\\result) == ...`".to_string());
    }
    if !prog.ensures.iter().any(is_len_result_eq) {
        return Err("main must include an ensures that exactly specifies the return length: `\\length(\\result) == ...`"
            .to_string());
    }

    if prog.stmts.is_empty() || !matches!(prog.stmts.last(), Some(Stmt::Return(_))) {
        return Err("main must end with a single top-level return statement".to_string());
    }
    for st in &prog.stmts[..prog.stmts.len() - 1] {
        if stmt_contains_return(st) {
            return Err("main must contain exactly one return statement at top level".to_string());
        }
    }
    if prog.stmts.iter().any(stmt_contains_result) {
        return Err("\\result is only allowed in contracts".to_string());
    }

    // Normalize (safe expression hoisting) and alpha-rename
    prog = normalize_program(&prog);
    typecheck_and_validate_program(&prog)?;
    Ok(prog)
}
