use std::collections::{HashMap, HashSet};

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Type {
    Int,
    Bool,
    IntArray,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Exp {
    IntConst(i64),
    BoolConst(bool),
    Var(String),
    BinOp(String, Box<Exp>, Box<Exp>),
    UnOp(String, Box<Exp>),
    Length(Box<Exp>),
    ArrayAccess(Box<Exp>, Box<Exp>),
    ForAll(Vec<String>, Box<Exp>),
    ResultVar,
    ArrMake(Box<Exp>, Box<Exp>),
    ArrSet(Box<Exp>, Box<Exp>, Box<Exp>),
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Stmt {
    Decl(Type, String, Option<Exp>),
    Assign(String, Exp),
    AllocArray(String, Type, Exp),
    ArrWrite(Exp, Exp, Exp),
    Block(Vec<Stmt>),
    If(Exp, Box<Stmt>, Option<Box<Stmt>>),
    While(Exp, Vec<Exp>, Box<Stmt>),
    Assert(Exp),
    Error(String),
    Return(Option<Exp>),
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Program {
    pub stmts: Vec<Stmt>,
    pub requires: Vec<Exp>,
    pub ensures: Vec<Exp>,
    pub args: Option<(String, String)>,
}

pub fn and_all(es: Vec<Exp>) -> Exp {
    es.into_iter()
        .fold(Exp::BoolConst(true), |acc, e| {
            Exp::BinOp("&&".to_string(), Box::new(acc), Box::new(e))
        })
}

fn union_all(mut sets: Vec<HashSet<String>>) -> HashSet<String> {
    let mut out = HashSet::new();
    for s in sets.drain(..) {
        out.extend(s);
    }
    out
}

pub fn vars_exp(e: &Exp) -> HashSet<String> {
    match e {
        Exp::IntConst(_) | Exp::BoolConst(_) | Exp::ResultVar => HashSet::new(),
        Exp::Var(x) => HashSet::from([x.clone()]),
        Exp::UnOp(_, a) | Exp::Length(a) => vars_exp(a),
        Exp::BinOp(_, l, r) => {
            let mut s = vars_exp(l);
            s.extend(vars_exp(r));
            s
        }
        Exp::ArrayAccess(a, i) => {
            let mut s = vars_exp(a);
            s.extend(vars_exp(i));
            s
        }
        Exp::ArrMake(len, init) => {
            let mut s = vars_exp(len);
            s.extend(vars_exp(init));
            s
        }
        Exp::ArrSet(a, i, v) => union_all(vec![vars_exp(a), vars_exp(i), vars_exp(v)]),
        Exp::ForAll(bound, body) => {
            let mut s = vars_exp(body);
            for v in bound {
                s.remove(v);
            }
            s
        }
    }
}

fn get_fresh_name(base: &str, avoid: &HashSet<String>) -> String {
    if !avoid.contains(base) {
        return base.to_string();
    }
    let mut i = 0;
    loop {
        let candidate = format!("{base}_{i}");
        if !avoid.contains(&candidate) {
            return candidate;
        }
        i += 1;
    }
}

pub fn subst_exp(e: &Exp, x: &str, replacement: &Exp) -> Exp {
    match e {
        Exp::Var(y) => {
            if y == x {
                replacement.clone()
            } else {
                e.clone()
            }
        }
        Exp::IntConst(_) | Exp::BoolConst(_) | Exp::ResultVar => e.clone(),
        Exp::BinOp(op, l, r) => Exp::BinOp(
            op.clone(),
            Box::new(subst_exp(l, x, replacement)),
            Box::new(subst_exp(r, x, replacement)),
        ),
        Exp::UnOp(op, a) => Exp::UnOp(op.clone(), Box::new(subst_exp(a, x, replacement))),
        Exp::Length(a) => Exp::Length(Box::new(subst_exp(a, x, replacement))),
        Exp::ArrayAccess(a, i) => Exp::ArrayAccess(
            Box::new(subst_exp(a, x, replacement)),
            Box::new(subst_exp(i, x, replacement)),
        ),
        Exp::ArrMake(len, init) => Exp::ArrMake(
            Box::new(subst_exp(len, x, replacement)),
            Box::new(subst_exp(init, x, replacement)),
        ),
        Exp::ArrSet(a, i, v) => Exp::ArrSet(
            Box::new(subst_exp(a, x, replacement)),
            Box::new(subst_exp(i, x, replacement)),
            Box::new(subst_exp(v, x, replacement)),
        ),
        Exp::ForAll(bound, body) => {
            if bound.iter().any(|v| v == x) {
                e.clone()
            } else {
                let replacement_vars = vars_exp(replacement);
                let bound_set: HashSet<String> = bound.iter().cloned().collect();
                if bound_set.is_disjoint(&replacement_vars) {
                    Exp::ForAll(bound.clone(), Box::new(subst_exp(body, x, replacement)))
                } else {
                    let mut avoid = vars_exp(body);
                    avoid.extend(replacement_vars.clone());
                    avoid.extend(bound_set.iter().cloned());

                    let mut new_bound = Vec::with_capacity(bound.len());
                    let mut current_body = (*body.clone()).clone();
                    for bv in bound {
                        if replacement_vars.contains(bv) {
                            let new_bv = get_fresh_name(bv, &avoid);
                            avoid.insert(new_bv.clone());
                            new_bound.push(new_bv.clone());
                            current_body = subst_exp(&current_body, bv, &Exp::Var(new_bv));
                        } else {
                            new_bound.push(bv.clone());
                        }
                    }
                    Exp::ForAll(new_bound, Box::new(subst_exp(&current_body, x, replacement)))
                }
            }
        }
    }
}

pub fn subst_result(e: &Exp, replacement: &Exp) -> Exp {
    match e {
        Exp::ResultVar => replacement.clone(),
        Exp::IntConst(_) | Exp::BoolConst(_) | Exp::Var(_) => e.clone(),
        Exp::BinOp(op, l, r) => Exp::BinOp(
            op.clone(),
            Box::new(subst_result(l, replacement)),
            Box::new(subst_result(r, replacement)),
        ),
        Exp::UnOp(op, a) => Exp::UnOp(op.clone(), Box::new(subst_result(a, replacement))),
        Exp::Length(a) => Exp::Length(Box::new(subst_result(a, replacement))),
        Exp::ArrayAccess(a, i) => Exp::ArrayAccess(
            Box::new(subst_result(a, replacement)),
            Box::new(subst_result(i, replacement)),
        ),
        Exp::ArrMake(len, init) => Exp::ArrMake(
            Box::new(subst_result(len, replacement)),
            Box::new(subst_result(init, replacement)),
        ),
        Exp::ArrSet(a, i, v) => Exp::ArrSet(
            Box::new(subst_result(a, replacement)),
            Box::new(subst_result(i, replacement)),
            Box::new(subst_result(v, replacement)),
        ),
        Exp::ForAll(vars, body) => Exp::ForAll(vars.clone(), Box::new(subst_result(body, replacement))),
    }
}

pub fn get_defs(s: &Stmt) -> HashSet<String> {
    match s {
        Stmt::Decl(_, name, _) => HashSet::from([name.clone()]),
        Stmt::Assign(dest, _) => HashSet::from([dest.clone()]),
        Stmt::AllocArray(dest, _, _) => HashSet::from([dest.clone()]),
        Stmt::ArrWrite(arr, _, _) => match arr {
            Exp::Var(x) => HashSet::from([x.clone()]),
            _ => HashSet::new(),
        },
        Stmt::Block(ss) => union_all(ss.iter().map(get_defs).collect()),
        Stmt::If(_, t, None) => get_defs(t),
        Stmt::If(_, t, Some(f)) => {
            let mut out = get_defs(t);
            out.extend(get_defs(f));
            out
        }
        Stmt::While(_, _, body) => get_defs(body),
        _ => HashSet::new(),
    }
}

pub fn simplify(e: &Exp) -> Exp {
    fn simp(e: &Exp) -> Exp {
        match e {
            Exp::BinOp(op, l, r) if op == "&&" => {
                let l = simp(l);
                let r = simp(r);
                match (&l, &r) {
                    (Exp::BoolConst(true), x) | (x, Exp::BoolConst(true)) => x.clone(),
                    (Exp::BoolConst(false), _) | (_, Exp::BoolConst(false)) => Exp::BoolConst(false),
                    _ => Exp::BinOp("&&".to_string(), Box::new(l), Box::new(r)),
                }
            }
            Exp::BinOp(op, l, r) if op == "||" => {
                let l = simp(l);
                let r = simp(r);
                match (&l, &r) {
                    (Exp::BoolConst(false), x) | (x, Exp::BoolConst(false)) => x.clone(),
                    (Exp::BoolConst(true), _) | (_, Exp::BoolConst(true)) => Exp::BoolConst(true),
                    _ => Exp::BinOp("||".to_string(), Box::new(l), Box::new(r)),
                }
            }
            Exp::BinOp(op, l, r) if op == "=>" => {
                let l = simp(l);
                let r = simp(r);
                match (&l, &r) {
                    (Exp::BoolConst(true), x) => x.clone(),
                    (Exp::BoolConst(false), _) => Exp::BoolConst(true),
                    (_, Exp::BoolConst(true)) => Exp::BoolConst(true),
                    _ => Exp::BinOp("=>".to_string(), Box::new(l), Box::new(r)),
                }
            }
            Exp::UnOp(op, a) if op == "!" => {
                let a = simp(a);
                match a {
                    Exp::BoolConst(b) => Exp::BoolConst(!b),
                    _ => Exp::UnOp("!".to_string(), Box::new(a)),
                }
            }
            Exp::BinOp(op, l, r) => Exp::BinOp(op.clone(), Box::new(simp(l)), Box::new(simp(r))),
            Exp::UnOp(op, a) => Exp::UnOp(op.clone(), Box::new(simp(a))),
            Exp::Length(a) => Exp::Length(Box::new(simp(a))),
            Exp::ArrayAccess(a, i) => Exp::ArrayAccess(Box::new(simp(a)), Box::new(simp(i))),
            Exp::ArrMake(len, init) => Exp::ArrMake(Box::new(simp(len)), Box::new(simp(init))),
            Exp::ArrSet(a, i, v) => Exp::ArrSet(Box::new(simp(a)), Box::new(simp(i)), Box::new(simp(v))),
            Exp::ForAll(vars, body) => Exp::ForAll(vars.clone(), Box::new(simp(body))),
            _ => e.clone(),
        }
    }
    simp(e)
}

pub fn stringify(e: &Exp, pretty: bool) -> String {
    fn go(e: &Exp, pretty: bool, indent: usize) -> String {
        let s = |e: &Exp| go(e, pretty, indent);
        match e {
            Exp::IntConst(n) => n.to_string(),
            Exp::BoolConst(true) => "true".to_string(),
            Exp::BoolConst(false) => "false".to_string(),
            Exp::Var(x) => x.clone(),
            Exp::ResultVar => "\\result".to_string(),
            Exp::Length(a) => format!("\\length({})", s(a)),
            Exp::ArrayAccess(a, i) => format!("{}[{}]", s(a), s(i)),
            Exp::ArrMake(len, init) => format!("ArrMake({}, {})", s(len), s(init)),
            Exp::ArrSet(a, i, v) => format!("ArrSet({}, {}, {})", s(a), s(i), s(v)),
            Exp::UnOp(op, a) => format!("({}{})", op, s(a)),
            Exp::BinOp(op, l, r) => format!("({} {} {})", s(l), op, s(r)),
            Exp::ForAll(vars, body) => {
                if pretty {
                    let pad = "  ".repeat(indent + 1);
                    format!(
                        "forall {} ::\n{}{}",
                        vars.join(", "),
                        pad,
                        go(body, pretty, indent + 1)
                    )
                } else {
                    format!("forall {} :: {}", vars.join(","), s(body))
                }
            }
        }
    }
    go(e, pretty, 0)
}

pub fn stringify_stmt(s: &Stmt) -> String {
    match s {
        Stmt::Decl(t, name, None) => format!("{:?} {}", t, name),
        Stmt::Decl(t, name, Some(init)) => format!("{:?} {} = {}", t, name, stringify(init, false)),
        Stmt::Assign(dest, src) => format!("{} = {}", dest, stringify(src, false)),
        Stmt::AllocArray(dest, _, count) => format!("{} = alloc_array(int, {})", dest, stringify(count, false)),
        Stmt::ArrWrite(a, i, v) => format!(
            "{}[{}] = {}",
            stringify(a, false),
            stringify(i, false),
            stringify(v, false)
        ),
        Stmt::Block(_) => "Block {...}".to_string(),
        Stmt::If(cond, _, _) => format!("if ({}) ...", stringify(cond, false)),
        Stmt::While(cond, _, _) => format!("while ({}) ...", stringify(cond, false)),
        Stmt::Assert(cond) => format!("assert({})", stringify(cond, false)),
        Stmt::Error(msg) => format!("error({})", msg),
        Stmt::Return(None) => "return".to_string(),
        Stmt::Return(Some(v)) => format!("return {}", stringify(v, false)),
    }
}

pub struct Renamer {
    scopes: Vec<HashMap<String, String>>,
    counter: usize,
}

impl Renamer {
    pub fn new() -> Self {
        Self {
            scopes: vec![HashMap::new()],
            counter: 0,
        }
    }

    fn fresh(&mut self, base: &str) -> String {
        self.counter += 1;
        format!("{base}_{}", self.counter)
    }

    fn current(&self, name: &str) -> String {
        for scope in self.scopes.iter().rev() {
            if let Some(v) = scope.get(name) {
                return v.clone();
            }
        }
        name.to_string()
    }

    pub fn enter_scope(&mut self) {
        self.scopes.push(HashMap::new());
    }

    pub fn exit_scope(&mut self) {
        self.scopes.pop();
    }

    fn declare(&mut self, name: &str) -> String {
        let new_name = self.fresh(name);
        if let Some(scope) = self.scopes.last_mut() {
            scope.insert(name.to_string(), new_name.clone());
        }
        new_name
    }

    fn rename_exp(&mut self, e: &Exp) -> Exp {
        match e {
            Exp::Var(x) => Exp::Var(self.current(x)),
            Exp::BinOp(op, l, r) => Exp::BinOp(
                op.clone(),
                Box::new(self.rename_exp(l)),
                Box::new(self.rename_exp(r)),
            ),
            Exp::UnOp(op, a) => Exp::UnOp(op.clone(), Box::new(self.rename_exp(a))),
            Exp::Length(a) => Exp::Length(Box::new(self.rename_exp(a))),
            Exp::ArrayAccess(a, i) => {
                Exp::ArrayAccess(Box::new(self.rename_exp(a)), Box::new(self.rename_exp(i)))
            }
            Exp::ArrMake(len, init) => Exp::ArrMake(
                Box::new(self.rename_exp(len)),
                Box::new(self.rename_exp(init)),
            ),
            Exp::ArrSet(a, i, v) => Exp::ArrSet(
                Box::new(self.rename_exp(a)),
                Box::new(self.rename_exp(i)),
                Box::new(self.rename_exp(v)),
            ),
            Exp::ForAll(vars, body) => {
                self.enter_scope();
                let vars2 = vars.iter().map(|v| self.declare(v)).collect();
                let body2 = self.rename_exp(body);
                self.exit_scope();
                Exp::ForAll(vars2, Box::new(body2))
            }
            _ => e.clone(),
        }
    }

    fn rename_stmt(&mut self, s: &Stmt) -> Stmt {
        match s {
            Stmt::Decl(t, name, init) => {
                let new_name = self.declare(name);
                Stmt::Decl(t.clone(), new_name, init.as_ref().map(|e| self.rename_exp(e)))
            }
            Stmt::Assign(dest, src) => Stmt::Assign(self.current(dest), self.rename_exp(src)),
            Stmt::AllocArray(dest, t, count) => Stmt::AllocArray(self.current(dest), t.clone(), self.rename_exp(count)),
            Stmt::ArrWrite(a, i, v) => Stmt::ArrWrite(self.rename_exp(a), self.rename_exp(i), self.rename_exp(v)),
            Stmt::Assert(c) => Stmt::Assert(self.rename_exp(c)),
            Stmt::Block(ss) => {
                self.enter_scope();
                let out = Stmt::Block(ss.iter().map(|st| self.rename_stmt(st)).collect());
                self.exit_scope();
                out
            }
            Stmt::If(cond, t, None) => {
                let r_cond = self.rename_exp(cond);
                self.enter_scope();
                let r_t = self.rename_stmt(t);
                self.exit_scope();
                Stmt::If(r_cond, Box::new(r_t), None)
            }
            Stmt::If(cond, t, Some(f)) => {
                let r_cond = self.rename_exp(cond);
                self.enter_scope();
                let r_t = self.rename_stmt(t);
                self.exit_scope();
                self.enter_scope();
                let r_f = self.rename_stmt(f);
                self.exit_scope();
                Stmt::If(r_cond, Box::new(r_t), Some(Box::new(r_f)))
            }
            Stmt::While(cond, invs, body) => {
                let r_cond = self.rename_exp(cond);
                let r_invs = invs.iter().map(|e| self.rename_exp(e)).collect();
                self.enter_scope();
                let r_body = self.rename_stmt(body);
                self.exit_scope();
                Stmt::While(r_cond, r_invs, Box::new(r_body))
            }
            Stmt::Return(Some(v)) => Stmt::Return(Some(self.rename_exp(v))),
            _ => s.clone(),
        }
    }
}

pub fn rename_program(p: &Program) -> Program {
    let mut r = Renamer::new();
    r.enter_scope();
    let args = match &p.args {
        Some((argc, input)) => Some((r.declare(argc), r.declare(input))),
        None => None,
    };
    let requires = p.requires.iter().map(|e| r.rename_exp(e)).collect();
    let stmts = p.stmts.iter().map(|s| r.rename_stmt(s)).collect();
    let ensures = p.ensures.iter().map(|e| r.rename_exp(e)).collect();
    r.exit_scope();
    Program {
        stmts,
        requires,
        ensures,
        args,
    }
}

