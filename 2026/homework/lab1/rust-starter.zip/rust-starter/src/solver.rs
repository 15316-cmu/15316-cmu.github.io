use crate::ast::{Exp, Type};
use std::collections::HashMap;
use std::sync::{Mutex, OnceLock};
use z3::ast::{forall_const, Array, Ast, Bool, BV, Datatype, Dynamic};
use z3::{Config, Context, DatatypeAccessor, DatatypeBuilder, DatatypeSort, SatResult, Solver, Sort};

const BIT_WIDTH: u32 = 64;

#[derive(Clone)]
enum Enc<'ctx> {
    Bool(Bool<'ctx>),
    Bv(BV<'ctx>),
    Arr(Datatype<'ctx>),
}

fn bv_sort<'ctx>(ctx: &'ctx Context) -> Sort<'ctx> {
    Sort::bitvector(ctx, BIT_WIDTH)
}

fn mk_arr_sort<'ctx>(ctx: &'ctx Context) -> DatatypeSort<'ctx> {
    let s_bv = bv_sort(ctx);
    let s_data = Sort::array(ctx, &s_bv, &s_bv);
    DatatypeBuilder::new(ctx, "Arr")
        .variant(
            "mk",
            vec![
                ("len", DatatypeAccessor::Sort(s_bv)),
                ("data", DatatypeAccessor::Sort(s_data)),
            ],
        )
        .finish()
}

static VAR_TYPES: OnceLock<Mutex<HashMap<String, Type>>> = OnceLock::new();

pub fn set_var_types(vars: &[(String, Type)]) {
    let tbl = VAR_TYPES.get_or_init(|| Mutex::new(HashMap::new()));
    let mut guard = tbl.lock().expect("VAR_TYPES lock poisoned");
    guard.clear();
    for (name, ty) in vars {
        guard.insert(name.clone(), ty.clone());
    }
}

fn get_var_type(name: &str) -> Option<Type> {
    let tbl = VAR_TYPES.get_or_init(|| Mutex::new(HashMap::new()));
    tbl.lock().ok().and_then(|g| g.get(name).cloned())
}

fn get_z3_var<'ctx>(ctx: &'ctx Context, name: &str, arr_sort: &DatatypeSort<'ctx>) -> Enc<'ctx> {
    match get_var_type(name) {
        Some(Type::Bool) => Enc::Bool(Bool::new_const(ctx, name)),
        Some(Type::IntArray) => Enc::Arr(Datatype::new_const(ctx, name, &arr_sort.sort)),
        _ => Enc::Bv(BV::new_const(ctx, name, BIT_WIDTH)),
    }
}

fn as_bool<'ctx>(e: Enc<'ctx>) -> Bool<'ctx> {
    match e {
        Enc::Bool(b) => b,
        _ => panic!("expected Bool"),
    }
}

fn as_bv<'ctx>(e: Enc<'ctx>) -> BV<'ctx> {
    match e {
        Enc::Bv(b) => b,
        _ => panic!("expected BV"),
    }
}

fn as_arr<'ctx>(e: Enc<'ctx>) -> Datatype<'ctx> {
    match e {
        Enc::Arr(a) => a,
        _ => panic!("expected Arr datatype"),
    }
}

fn dyn_as_bv<'ctx>(d: Dynamic<'ctx>) -> BV<'ctx> {
    d.as_bv().expect("expected BV")
}

fn dyn_as_arr<'ctx>(d: Dynamic<'ctx>) -> Datatype<'ctx> {
    d.as_datatype().expect("expected Datatype")
}

fn dyn_as_array<'ctx>(d: Dynamic<'ctx>) -> Array<'ctx> {
    d.as_array().expect("expected Array")
}

fn exp_enc<'ctx>(ctx: &'ctx Context, arr: &DatatypeSort<'ctx>, e: &Exp) -> Enc<'ctx> {
    let mk = &arr.variants[0].constructor;
    let len_acc = &arr.variants[0].accessors[0];
    let data_acc = &arr.variants[0].accessors[1];

    match e {
        Exp::IntConst(n) => Enc::Bv(BV::from_i64(ctx, *n, BIT_WIDTH)),
        Exp::BoolConst(b) => Enc::Bool(Bool::from_bool(ctx, *b)),
        Exp::Var(name) => get_z3_var(ctx, name, arr),

        Exp::UnOp(op, a) if op == "!" => Enc::Bool(as_bool(exp_enc(ctx, arr, a)).not()),
        Exp::UnOp(op, a) if op == "-" => Enc::Bv(as_bv(exp_enc(ctx, arr, a)).bvneg()),
        Exp::UnOp(op, _) => panic!("unknown unop: {op}"),

        Exp::BinOp(op, l, r) if op == "==" || op == "!=" => {
            let el = exp_enc(ctx, arr, l);
            let er = exp_enc(ctx, arr, r);
            let eq = match (el, er) {
                (Enc::Bv(bl), Enc::Bv(br)) => bl._eq(&br),
                (Enc::Bool(bl), Enc::Bool(br)) => bl._eq(&br),
                (Enc::Arr(al), Enc::Arr(ar)) => al._eq(&ar),
                _ => panic!("sort mismatch for binop: {op}"),
            };
            if op == "==" {
                Enc::Bool(eq)
            } else {
                Enc::Bool(eq.not())
            }
        }
        Exp::BinOp(op, l, r) => {
            let el = exp_enc(ctx, arr, l);
            let er = exp_enc(ctx, arr, r);
            match (el, er) {
                (Enc::Bv(bl), Enc::Bv(br)) => match op.as_str() {
                    "+" => Enc::Bv(bl.bvadd(&br)),
                    "-" => Enc::Bv(bl.bvsub(&br)),
                    "*" => Enc::Bv(bl.bvmul(&br)),
                    "/" => Enc::Bv(bl.bvsdiv(&br)),
                    "%" => Enc::Bv(bl.bvsrem(&br)),
                    "<" => Enc::Bool(bl.bvslt(&br)),
                    "<=" => Enc::Bool(bl.bvsle(&br)),
                    ">" => Enc::Bool(bl.bvsgt(&br)),
                    ">=" => Enc::Bool(bl.bvsge(&br)),
                    _ => panic!("unknown bv binop: {op}"),
                },
                (Enc::Bool(bl), Enc::Bool(br)) => match op.as_str() {
                    "&&" => Enc::Bool(Bool::and(ctx, &[&bl, &br])),
                    "||" => Enc::Bool(Bool::or(ctx, &[&bl, &br])),
                    "=>" => Enc::Bool(bl.implies(&br)),
                    _ => panic!("unknown bool binop: {op}"),
                },
                _ => panic!("sort mismatch for binop: {op}"),
            }
        }

        Exp::Length(a) => {
            let za = as_arr(exp_enc(ctx, arr, a));
            Enc::Bv(dyn_as_bv(len_acc.apply(&[&za])))
        }
        Exp::ArrayAccess(a, i) => {
            let za = as_arr(exp_enc(ctx, arr, a));
            let zi = as_bv(exp_enc(ctx, arr, i));
            let zdata = dyn_as_array(data_acc.apply(&[&za]));
            Enc::Bv(dyn_as_bv(zdata.select(&zi)))
        }

        Exp::ArrMake(len, init) => {
            let zlen = as_bv(exp_enc(ctx, arr, len));
            let _zinit = as_bv(exp_enc(ctx, arr, init));
            let sym = format!("_arrmake_{}", e as *const Exp as usize);
            let zdata = Array::new_const(ctx, sym, &bv_sort(ctx), &bv_sort(ctx));
            Enc::Arr(dyn_as_arr(mk.apply(&[&zlen, &zdata])))
        }
        Exp::ArrSet(a, i, v) => {
            let za = as_arr(exp_enc(ctx, arr, a));
            let zi = as_bv(exp_enc(ctx, arr, i));
            let zv = as_bv(exp_enc(ctx, arr, v));
            let zlen = dyn_as_bv(len_acc.apply(&[&za]));
            let zdata = dyn_as_array(data_acc.apply(&[&za]));
            let zdata2 = zdata.store(&zi, &zv);
            Enc::Arr(dyn_as_arr(mk.apply(&[&zlen, &zdata2])))
        }

        Exp::ForAll(vars, body) => {
            let bvs: Vec<BV> = vars.iter().map(|v| BV::new_const(ctx, v.as_str(), BIT_WIDTH)).collect();
            let refs: Vec<&dyn Ast<'ctx>> = bvs.iter().map(|x| x as &dyn Ast).collect();
            let bodyb = as_bool(exp_enc(ctx, arr, body));
            Enc::Bool(forall_const(ctx, &refs, &[], &bodyb))
        }

        Exp::ResultVar => panic!("\\result should not appear in solver input"),
    }
}

pub fn check_validity(f: &Exp) -> bool {
    let cfg = Config::new();
    let ctx = Context::new(&cfg);
    let arr = mk_arr_sort(&ctx);
    let solver = Solver::new(&ctx);

    let zf = as_bool(exp_enc(&ctx, &arr, f));
    let vc = zf.not().simplify();
    solver.assert(&vc);

    matches!(solver.check(), SatResult::Unsat)
}
