use crate::ast::Program;

pub fn check_safety(
    _prog: &Program,
    _verbose: bool,
    _print_vc: bool,
    _small_cex: bool,
    _small_cex_max: usize,
) -> bool {
    panic!("wlp::check_safety is not implemented in the starter code");
}

