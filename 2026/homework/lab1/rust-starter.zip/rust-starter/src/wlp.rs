use crate::ast::Program;

pub fn check_safety(
    _prog: &Program,
) -> bool {
    panic!("wlp::check_safety is not implemented in the starter code");
}
