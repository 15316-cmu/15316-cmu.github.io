# Lab 1 (C0-Arrays) — Rust Starter

This starter code provides:
- A parser for the Lab 1 C0-Arrays subset (`src/parse.rs`, `src/c0.lalrpop`, `src/ast.rs`)
  - Rejects array-aliasing programs (e.g. `A = B;` for `int[] A, B`)
  - Normalizes expressions by hoisting potentially-unsafe subexpressions (division/modulo and array reads)
- A Z3 interface for validity checking (`src/solver.rs`)

You implement the analyzer (WLP/VC generation) in `src/wlp.rs`.

## Build

```bash
make
```

This produces `c0_vc`.

## Run

```bash
./c0_vc example.c0
```

Exit codes: `0` valid, `2` unsafe, `1` error.
