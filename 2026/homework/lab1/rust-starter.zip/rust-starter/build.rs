fn main() {
    lalrpop::process_src().unwrap();

    // Homebrew on Apple Silicon installs libraries under /opt/homebrew/lib, which is not always
    // in the default linker search path.
    if std::path::Path::new("/opt/homebrew/lib/libz3.dylib").exists() {
        println!("cargo:rustc-link-search=native=/opt/homebrew/lib");
    }
    if std::path::Path::new("/usr/local/lib/libz3.dylib").exists() {
        println!("cargo:rustc-link-search=native=/usr/local/lib");
    }
}
