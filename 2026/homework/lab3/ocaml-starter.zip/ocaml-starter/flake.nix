{
  description = "A very basic flake";

  inputs = {
    nixpkgs.url = "github:nixos/nixpkgs?ref=nixos-unstable";
    nixpkgs-ocaml.url = "github:nixos/nixpkgs?ref=a63a64b593dcf2fe05f7c5d666eb395950f36bc9";
  };

  outputs = { self, nixpkgs, nixpkgs-ocaml }:
    let
      systems = [ "x86_64-linux" "aarch64-linux" "x86_64-darwin" "aarch64-darwin" ];
      shellForSystem = system:
        let
          pkgs = nixpkgs.legacyPackages.${system};
          clangVersion = builtins.elemAt
            (nixpkgs.lib.strings.splitString "." (nixpkgs.lib.strings.getVersion pkgs.libclang)) 0;
          ocamlPackages = nixpkgs-ocaml.legacyPackages.${system}.ocaml-ng.ocamlPackages_5_0;
        in
        {
          formatter.${system} = nixpkgs.legacyPackages.${system}.nixpkgs-fmt;
          devShells.${system}.default = pkgs.mkShell {
            buildInputs = [
              ocamlPackages.core
              ocamlPackages.menhir
              ocamlPackages.merlin
              ocamlPackages.ocaml
              ocamlPackages.ocamlformat
              ocamlPackages.ocaml-lsp
              ocamlPackages.odoc
              ocamlPackages.ppx_deriving
              ocamlPackages.ppx_import
              ocamlPackages.ppx_jane
              ocamlPackages.utop
              ocamlPackages.z3
              ocamlPackages.zarith
              pkgs.dune_3
              pkgs.z3
              pkgs.zip
            ];
          };
        };
    in
    builtins.foldl' (acc: sys: (shellForSystem sys) // acc) { } systems;
}
