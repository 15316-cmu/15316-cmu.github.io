(** Substitution Helpers *)

(** [fresh_var x] generates a fresh variable not found in the rest of the program *)
val fresh_var : Ast.var -> Ast.var

(** [eq_term s t] compares s and t for equality *)
val eq_term : Ast.term -> Ast.term -> bool

(** [eq_form P Q] compares P and Q for equality *)
val eq_form : Ast.form -> Ast.form -> bool

(** [subst_form x t P] substitutes variable [x] for arbitrary expression [e] in [P] *)
val subst_form : Ast.var -> Ast.term -> Ast.form -> Ast.form
