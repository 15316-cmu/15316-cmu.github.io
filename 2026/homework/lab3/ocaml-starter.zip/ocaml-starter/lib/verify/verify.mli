(** Proof verification *)

exception Verify of string

(** [check_policy Gamma] raises Verify(msg) if Gamma is not a well-formed policy *)
val check_policy : Ast.policy -> unit

(** [verify Gamma M P] raises Verify(msg) if Gamma |- M <= P fails *)
val verify : Ast.policy -> Ast.proof -> Ast.form -> unit
