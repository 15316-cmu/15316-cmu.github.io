{
(** PCA Lexer *)

open Core

module P = Pca_parser

(* COPIED FROM 15-411 STARTER CODE *)
(* A record of all errors that happened. *)
let errors = Error_msg.create ()

let text = Lexing.lexeme

let from_lexbuf : Lexing.lexbuf -> Mark.src_span option =
  fun lexbuf ->
    Mark.of_positions
      (Lexing.lexeme_start_p lexbuf)
      (Lexing.lexeme_end_p lexbuf)
    |> Option.some

let error lexbuf ~msg : unit =
  let src_span = from_lexbuf lexbuf in
  Error_msg.error errors src_span ~msg

}

let idchar = ['a'-'z' 'A'-'Z' '_' '0'-'9']
let lower = ['a'-'z'] idchar*
let upper = ['A'-'Z'] idchar*

let ws = [' ' '\t' '\r' '\011' '\012']

rule initial = parse
  | ws+  { initial lexbuf }
  | '\n' { Lexing.new_line lexbuf;
           initial lexbuf
         }

  | '[' { P.LBRACKET }
  | ']' { P.RBRACKET }
  | '(' { P.LPAREN }
  | ')' { P.RPAREN }
  | '{' { P.LBRACE }
  | '}' { P.RBRACE }
  | '_' { P.UNDERSCORE }

  | '.' { P.DOT }
  | ',' { P.COMMA }
  | ';' { P.SEMICOLON }
  | ':' { P.COLON }
  | '=' { P.EQUAL }

  | "->"  { P.ARROW }
  | "!"  { P.BANG }

  | "says"  { P.SAYS }
  | "let"   { P.LET }
  | "in"    { P.IN }

  | lower as name { P.CONST name }
  | upper as name { P.VAR name }

  | eof { P.EOF }

  | _  { error lexbuf
           ~msg:(sprintf "Illegal character '%s'" (text lexbuf));
         initial lexbuf
       }

{}
