%{
(** PCA Parser *)
%}

(* terms *)
%token <string> CONST
%token <string> VAR

(* forms *)
%token BANG
%token ARROW
%token SAYS

(* proofs *)
%token LET
%token EQUAL
%token IN

(* special characters *)
%token EOF
%token DOT COMMA SEMICOLON COLON
%token UNDERSCORE
%token LBRACKET RBRACKET
%token LPAREN RPAREN
%token LBRACE RBRACE

(* precedence & associativity *)
%right DOT
%right ARROW
%right SAYS

%start policy proof typing

(* types *)
%type <Ast.policy> policy
%type <Ast.ante> ante
%type <Ast.term> term
%type <Ast.term list> terms
%type <Ast.form> form
%type <Ast.proof -> Ast.proof> arg_seq
%type <Ast.proof> proof
%type <Ast.proof * Ast.form> typing

%%

policy :
  | a = ante;
    SEMICOLON;
    gamma = policy;
      { a::gamma }
  | EOF;
      { [] }

ante :
  | c = CONST;
    COLON;
    p = form;
       { Ast.Decl(c, p) }

term :
  | x = VAR;
      { Ast.Var x}
  | c = CONST;
      { Ast.Const c }

terms :
  | t = term;
      { [t] }
  | t = term;
    COMMA;
    ts = terms;
      { t :: ts }

form :
  | f = CONST;
    LPAREN;
    RPAREN;
      { Ast.Atom (f, []) }
  | f = CONST;
    LPAREN;
    ts = terms
    RPAREN;
      { Ast.Atom (f, ts) }
  | p1 = form;
    ARROW;
    p2 = form;
      { Ast.Implies (p1, p2) }
  | BANG;
    x = VAR;
    DOT;
    p = form;
      { Ast.Forall(x, p) }
  | a = term;
    SAYS;
    p = form;
      { Ast.Says(a, p) }
  | LPAREN;
    p = form;
    RPAREN;
      { p }
  ;

arg_seq :
  | LPAREN;
    m = proof;
    RPAREN;
    args = arg_seq
      { fun h -> args (Ast.App(h, m)) }
  | v = CONST;
    args = arg_seq
      { fun h -> args (Ast.App(h, Ast.Pvar(v))) }
  | LBRACKET;
    t = term;
    RBRACKET;
    args = arg_seq
      { fun h -> args (Ast.Inst(h, t)) }
  | LBRACE;
    m = proof;
    RBRACE;
    UNDERSCORE;
    a = term;
    args = arg_seq
      { fun h -> args (Ast.App(h, Ast.Wrap (m, a))) }
  | { fun h -> h }

proof :
  | v = CONST;
    args = arg_seq
      { args (Ast.Pvar(v)) }
  | LBRACE;
    m = proof;
    RBRACE;
    UNDERSCORE;
    a = term;
      { Ast.Wrap (m, a) }
  | LET;
    LBRACE;
    v = CONST;
    RBRACE;
    UNDERSCORE;
    a = term;
    EQUAL;
    m = proof;
    IN;
    n = proof;
      { Ast.LetWrap (v, a, m, n) }
  | LET;
    v = CONST;
    EQUAL;
    m = proof;
    IN;
    n = proof;
      { Ast.Let (v, m, n) }
  | LPAREN;
    m = proof;
    RPAREN;
      { m }

typing :
  | m = proof;
    COLON;
    p = form;
    EOF;
     { (m, p) }

%%
