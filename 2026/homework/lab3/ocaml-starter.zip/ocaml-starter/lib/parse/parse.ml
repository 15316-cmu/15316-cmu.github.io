(** Parsing

    Gluing together the pieces produced by ocamllex and menhir. *)

open Core

(** In order for the lexbuf to correctly track source locations
    we have to initialize the filename in the positions tracked by
    the lexbuf. *)
let initialize_lexbuf (filename : string) : Lexing.lexbuf -> unit =
  let open Lexing in
  let pos = { pos_fname = filename; pos_lnum = 1; pos_bol = 0; pos_cnum = 0 } in
  fun lexbuf ->
    lexbuf.lex_start_p <- pos;
    lexbuf.lex_curr_p <- pos
;;

let parse_policy (filename : string) : Ast.policy =
  try
    let ast =
      In_channel.with_file filename ~f:(fun chan ->
        let lexbuf = Lexing.from_channel chan in
        initialize_lexbuf filename lexbuf;
        try Pca_parser.policy Pca_lexer.initial lexbuf with
        | _ ->
          (* Parse error; attempt to print a helpful error message. *)
          let src_span =
            Mark.of_positions Lexing.(lexbuf.lex_start_p) Lexing.(lexbuf.lex_curr_p)
          in
          Error_msg.error Pca_lexer.errors (Some src_span) ~msg:"Parse error.";
          raise Error_msg.Error)
    in
    if Error_msg.has_any_errors Pca_lexer.errors
    then (
      Out_channel.prerr_endline "Lex error.";
      raise Error_msg.Error)
    else ast
  with
  | Sys_error s ->
    (* Probably file not found or permissions errors. *)
    Out_channel.prerr_endline ("System error: " ^ s);
    raise Error_msg.Error
;;

let parse_typing (filename : string) : Ast.proof * Ast.form =
  try    
    let ast =
      In_channel.with_file filename ~f:(fun chan ->
        let lexbuf = Lexing.from_channel chan in
        initialize_lexbuf filename lexbuf;
        try Pca_parser.typing Pca_lexer.initial lexbuf with
        | _ ->
          (* Parse error; attempt to print a helpful error message. *)
          let src_span =
            Mark.of_positions Lexing.(lexbuf.lex_start_p) Lexing.(lexbuf.lex_curr_p)
          in
          Error_msg.error Pca_lexer.errors (Some src_span) ~msg:"Parse error.";
          raise Error_msg.Error)
    in
    if Error_msg.has_any_errors Pca_lexer.errors
    then (
      Out_channel.prerr_endline "Lex error.";
      raise Error_msg.Error)
    else ast
  with
  | Sys_error s ->
    (* Probably file not found or permissions errors. *)
    Out_channel.prerr_endline ("System error: " ^ s);
    raise Error_msg.Error

(*
let parse_string (input : string) : Ast.policy =
  try
    Error_msg.reset Pca_lexer.errors;
    let lexbuf = Lexing.from_string input in
    let ast = Pca_parser.policy Pca_lexer.initial lexbuf in
    if Error_msg.has_any_errors Pca_lexer.errors
    then (
      print_endline "Lex error.";
      raise Error_msg.Error)
    else ast
  with
  | Error_msg.Error -> raise Error_msg.Error
  | _ ->
    print_endline "Parse error.";
    raise Error_msg.Error
;;
*)


(*
let parse_form (input : string) : Ast.form =
  let file = parse_string (sprintf "requires %s; assert true" input) in
  file.precondition
;;
*)
