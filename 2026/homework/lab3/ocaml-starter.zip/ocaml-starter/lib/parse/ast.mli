(** Abstract Syntax Tree for TinyScript *)

open Core

(* TYPES *)

(** the type of variables *)
type var = string               (* upper case *)
type const = string             (* lower case *)

(** the type of terms *)
type term =
  | Var of var                  (** x, y, z *)
  | Const of const              (** c, d *)

(** the type of atoms *)
type atom = const * term list   (** f(t1,...,tn) *)

(** the type of formulas *)
type form =
  | Atom of atom           (** f(t1,...,tn) *)
  | Says of term * form    (** A says P *)
  | Implies of form * form (** P -> Q *)
  | Forall of var * form   (** !x . P *)

type ante =
  | Decl of const * form   (** v : P *)

type policy = ante list    (** v1 : P1; ...; vn : Pn *)

type pvar = string              (* lower case *)

type proof =
   | Pvar of pvar               (* v *)
   | App of proof * proof       (* M1 M2 *)
   | Inst of proof * term       (* M [t] *)
   | Wrap of proof * term       (* {M}_A *)
   | LetWrap of pvar * term * proof * proof
                                (* let {v}_A = M in N *)
   | Let of pvar * proof * proof (* let v = M in N *)

(** Print as source, with redundant parentheses *)
module Print : sig
  val pp_term : term -> string
  val pp_form : form -> string
  val pp_policy : policy -> string
  val pp_proof : proof -> string
  val pp_typing : proof * form -> string
end
