#include <stdlib.h>

#include "common/ubarray.h"

inline void ubarray_check(const ubarray *array) {
}

ubarray *ubarray_new(size_t size) {
  return NULL;
}

elem_t *ubarray_elem(ubarray *array, size_t index) {
  return NULL;
}

size_t ubarray_size(const ubarray *array) {
  return 0;
}

ubarray *ubarray_push_back(ubarray *array, elem_t elem) {
  return NULL;
}

elem_t ubarray_remove(ubarray *array, int index) {
  return 0;
}

void ubarray_free(ubarray *array, destructor_t destructor) {
}


