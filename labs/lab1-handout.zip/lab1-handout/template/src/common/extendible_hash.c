#include <string.h>

#include "common/extendible_hash.h"

entry_t *entry_new(const char *key, int value) {
  return NULL;
}

void entry_free(entry_t *entry) {
}

bucket_t *bucket_new(int local_depth, int common_hash) {
  return NULL;
}

void bucket_free(bucket_t *bucket) {
}

inline void hash_table_check(hash_table_t *table) {
}

hash_table_t *hash_table_new() {
  return NULL;
}

void hash_table_free(hash_table_t *table) {
}

int hash(const char *key) {
  return 0;
}

int effective_hash(size_t hash, size_t depth) {
  return 0;
}

bucket_t *find_bucket(hash_table_t *table, const char *key) {
  return NULL;
}

bool hash_table_find(hash_table_t *table,
                     const char *key,
                     int *value) {
  return false;
}

bool hash_table_remove(hash_table_t *table, const char *key) {
  return false;
}

void grow_table(hash_table_t *table) {
}

void split(hash_table_t *table, bucket_t *old, const char *key) {
}

void hash_table_insert(hash_table_t *table,
                      const char *key,
                      int value) {
}

hash_table_iterator *hash_table_iterate(hash_table_t *table) {
  return NULL;
}

void iterator_check(hash_table_iterator *it) {
}

entry_t *iterator_elem(hash_table_iterator *it) {
  return NULL;
}

void iterator_next(hash_table_iterator *it) {
}

void iterator_free(hash_table_iterator *it) {
}

void hash_table_serialize(hash_table_t *table, int out) {
}

hash_table_t *hash_table_deserialize(int in) {
  return NULL;
}
