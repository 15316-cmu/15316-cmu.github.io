To run Server:
   Run "tiny <port> <db file>" on the server machine, 
	 e.g., "tiny 8000 foo.db".
   Point your browser at Tiny: 
	 http://<host>:8000/cgi-bin/adder?1&2

Files:
  tiny.c    main server
  include/  header files
  cgi-bin/  cgi programs
