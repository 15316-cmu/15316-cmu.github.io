#include "extendible_hash.h"


int main(int argc, char **argv) {
  // TODO: implement
  // Specification:
  // host:<port>/cgi-bin/get?foo should print
  // the value of foo, or null if no such key exists, in the
  // response to client. See adder.c or divide.c for example.
}
