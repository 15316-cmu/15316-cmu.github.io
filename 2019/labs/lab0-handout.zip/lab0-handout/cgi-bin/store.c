#include "extendible_hash.h"


int main(int argc, char **argv) {
  // TODO: implement
  // Specification:
  // host:<port>/cgi-bin/store?foo&42 should map
  // foo to 42 in the underlying db file and print
  // a message informing the client of success.
  // See adder.c and divide.c for example.
}
