(** Static analysis pass for variables used before being defined *)

open Core
module A = Ast
module Set = String.Set

let def_use (file : A.file) : bool =
  (* Write your solution here! *)
  ignore (file : A.file);
  failwith "unimplemented"
;;
