open Core

let test_file input =
  try
    let file = Parse.parse_string input in
    print_endline (Ast.Print.pp_file file)
  with
  | _ -> ()
;;

let test_prog input =
  try
    let prog = Parse.parse_prog input in
    print_endline (Ast.Print.pp_prog prog)
  with
  | _ -> ()
;;

let test_form input =
  try
    let form = Parse.parse_form input in
    print_endline (Ast.Print.pp_form form)
  with
  | _ -> ()
;;

let test_exp input =
  try
    let exp = Parse.parse_exp input in
    print_endline (Ast.Print.pp_exp exp)
  with
  | _ -> ()
;;

let%expect_test "Test expressions" =
  test_exp "22 * 44 + 66";
  [%expect {| ((22 * 44) + 66) |}];
  test_exp "1 * 4 + 2 - 3 * 7";
  [%expect {| (((1 * 4) + 2) - (3 * 7)) |}];
  test_exp "7 * 4 * 2";
  [%expect {| ((7 * 4) * 2) |}];
  test_exp "(i + 1) * i";
  [%expect {| ((i + 1) * i) |}];
  test_exp "3 * 4 + 5 * 1 - 2";
  [%expect {| (((3 * 4) + (5 * 1)) - 2) |}];
  test_exp "7 / (1 + 1)";
  [%expect {|
    Parse error.
    :1.23-1.24:error:Illegal character '/' |}]
;;

let%expect_test "Test formulas" =
  test_form "~ 1 < 2";
  [%expect {| (~(1 < 2)) |}];
  test_form "true -> false -> true";
  [%expect {| (true -> (false -> true)) |}];
  test_form "true -> false -> true -> (x < 2)";
  [%expect {| (true -> (false -> (true -> (x < 2)))) |}];
  test_form "~ (1 < 2)";
  [%expect {| (~(1 < 2)) |}];
  test_form "~ x < 5 \\/ x <= 5 /\\ ~ y < 2";
  [%expect {| ((~(x < 5)) \/ ((x <= 5) /\ (~(y < 2)))) |}]
;;

let%expect_test "Test programs" =
  test_prog "#input := 1";
  [%expect {| #input := 1 |}];
  test_prog "#output := 1";
  [%expect {| #output := 1 |}];
  test_prog "#output := 1; x := 0";
  [%expect {|
    (#output := 1; x := 0) |}];
  test_prog "x := 1";
  [%expect {| x := 1 |}];
  test_prog "x := 1; y := 2";
  [%expect {|
    (x := 1; y := 2) |}];
  test_prog "x := 1; y := 2; z := 1";
  [%expect {|
    (x := 1; (y := 2; z := 1)) |}];
  test_prog "M [ 45 ] := 4; assert ~ false";
  [%expect {|
    (M[45] := 4; assert (~false)) |}];
  test_prog "x := M [ 45 ]; #input := 1";
  [%expect {|
    (x := M[45]; #input := 1) |}];
  test_prog "x := 4; if true then x := 1 else x := 2 endif";
  [%expect {|
    (x := 4; if true then x := 1 else x := 2 endif) |}];
  test_prog "n := 0";
  [%expect {| n := 0 |}];
  test_prog
    {|
  n := 101;
  if true then x := 0 else x := 1 endif;
  i := 0;
  while true
    invariant (x < 0)
  do
    x := x + i
  done
  |};
  [%expect
    {|
    (n := 101; (if true then x := 0 else x := 1 endif; (i := 0; while true invariant (x < 0) do x := (x + i) done))) |}];
  test_prog
    {|
  x := 0;
  i := 0;
  while i < 101
      invariant 2 * x == i * (i + 1)
  do
      x := x + i;
      i := i + 1
  done
  |};
  [%expect
    {|
    (x := 0; (i := 0; while (i < 101) invariant ((2 * x) = (i * (i + 1))) do (x := (x + i); i := (i + 1)) done)) |}];
  test_prog
    {|
  assert ~ (x < 0);
  while x < 1
      invariant ~ (x < 0)
  do
      x := x - 2
  done
  |};
  [%expect
    {|
    (assert (~(x < 0)); while (x < 1) invariant (~(x < 0)) do x := (x - 2) done) |}]
;;

let%expect_test "Test parse simple file" =
  test_file {|
  requires true;
  x := 3
  |};
  [%expect {|
    requires true
    program x := 3
  |}]
;;

let%expect_test "Test parse more complex file" =
  test_file {|
  requires ~false \/ true;
  x := 3;
  assert true
  |};
  [%expect {|
    requires ((~false) \/ true)
    program (x := 3; assert true)
  |}]
;;
