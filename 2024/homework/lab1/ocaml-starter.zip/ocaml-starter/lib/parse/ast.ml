(** Abstract Syntax Tree for TinyScript *)

open Core
module State = String.Map
module Heap = Zarith.Map

type var = [%import: Ast.var]
type num = [%import: Ast.num]
type exp = [%import: Ast.exp]
type form = [%import: Ast.form]
type prog = [%import: Ast.prog]
type file = [%import: Ast.file]

let heap_size = Zarith.of_int 1024
let input_var = "#input"
let output_var = "#output"
let file_to_prog { precondition; program } = Seq (Test precondition, program)

module Print = struct
  let rec pp_exp = function
    | Const n -> Zarith.to_string n
    | Var v -> v
    | Plus (e1, e2) -> sprintf "(%s + %s)" (pp_exp e1) (pp_exp e2)
    | Minus (e1, e2) -> sprintf "(%s - %s)" (pp_exp e1) (pp_exp e2)
    | Times (e1, e2) -> sprintf "(%s * %s)" (pp_exp e1) (pp_exp e2)
  ;;

  let rec pp_form = function
    | True -> "true"
    | False -> "false"
    | Lt (e1, e2) -> sprintf "(%s < %s)" (pp_exp e1) (pp_exp e2)
    | Leq (e1, e2) -> sprintf "(%s <= %s)" (pp_exp e1) (pp_exp e2)
    | Eq (e1, e2) -> sprintf "(%s = %s)" (pp_exp e1) (pp_exp e2)
    | And (f1, f2) -> sprintf "(%s /\\ %s)" (pp_form f1) (pp_form f2)
    | Or (f1, f2) -> sprintf "(%s \\/ %s)" (pp_form f1) (pp_form f2)
    | Implies (f1, f2) -> sprintf "(%s -> %s)" (pp_form f1) (pp_form f2)
    | Not f -> sprintf "(~%s)" (pp_form f)
  ;;

  let rec pp_prog = function
    | Assign (v, e) -> sprintf "%s := %s" v (pp_exp e)
    | Read (v, e) -> sprintf "%s := M[%s]" v (pp_exp e)
    | Write { addr; value } -> sprintf "M[%s] := %s" (pp_exp addr) (pp_exp value)
    | Seq (p1, p2) -> sprintf "(%s; %s)" (pp_prog p1) (pp_prog p2)
    | Assert f -> sprintf "assert %s" (pp_form f)
    | Test f -> sprintf "test %s" (pp_form f)
    | If { cond; then_branch; else_branch } ->
      sprintf
        "if %s then %s else %s endif"
        (pp_form cond)
        (pp_prog then_branch)
        (pp_prog else_branch)
    | While { guard; invariant; body } ->
      sprintf
        "while %s invariant %s do %s done"
        (pp_form guard)
        (pp_form invariant)
        (pp_prog body)
  ;;

  let pp_file { precondition; program } =
    sprintf "requires %s\nprogram %s" (pp_form precondition) (pp_prog program)
  ;;
end
