(** Interpreter for TinyScript *)

open Core
module Z = Zarith
module A = Ast
module State = Ast.State
module Heap = Ast.Heap

type exec_result = [%import: Exec.exec_result]

let exec (file : A.file) ~(input : Z.t) ~(expected_output : Z.t) : exec_result =
  (* Write your solution here! *)
  ignore (file : A.file);
  ignore (input : Z.t);
  ignore (expected_output : Z.t);
  failwith "unimplemented"
;;
