(** Weakest Liberal Precondition *)

open Core
module A = Ast
module Z = Zarith

let check_safety (file : A.file) : bool =
  (* Write your solution here! *)
  ignore (file : A.file);
  failwith "unimplemented"
;;
