(** Wrapper around Zarith to support Jane Street Core comparators

    @see <https://antoinemine.github.io/Zarith/doc/latest/Z.html> for the interface *)

open Core

module T = struct
  include Z

  let sexp_of_t t : Sexp.t = Atom (to_string t)
  let t_of_sexp s : t = of_string (Sexp.to_string s)
end

include T
include Comparable.Make (T)
