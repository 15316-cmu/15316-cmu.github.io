(** Z3 Theorem Prover Wrapper *)

open Core

type solve_result = [%import: Solver.solve_result]

let rec exp_to_expr ~ctx exp =
  let open Z3.Arithmetic in
  match exp with
  | Ast.Const n -> Integer.mk_numeral_s ctx (Zarith.to_string n)
  | Ast.Var x -> Integer.mk_const_s ctx x
  | Ast.Plus (e1, e2) -> mk_add ctx [ exp_to_expr ~ctx e1; exp_to_expr ~ctx e2 ]
  | Ast.Minus (e1, e2) -> mk_sub ctx [ exp_to_expr ~ctx e1; exp_to_expr ~ctx e2 ]
  | Ast.Times (e1, e2) -> mk_mul ctx [ exp_to_expr ~ctx e1; exp_to_expr ~ctx e2 ]
;;

let rec form_to_expr ~ctx form =
  let open Z3.Boolean in
  let open Z3.Arithmetic in
  match form with
  | Ast.True -> mk_true ctx
  | Ast.False -> mk_false ctx
  | Ast.Lt (e1, e2) -> mk_lt ctx (exp_to_expr ~ctx e1) (exp_to_expr ~ctx e2)
  | Ast.Leq (e1, e2) -> mk_le ctx (exp_to_expr ~ctx e1) (exp_to_expr ~ctx e2)
  | Ast.Eq (e1, e2) -> mk_eq ctx (exp_to_expr ~ctx e1) (exp_to_expr ~ctx e2)
  | Ast.And (f1, f2) -> mk_and ctx [ form_to_expr ~ctx f1; form_to_expr ~ctx f2 ]
  | Ast.Or (f1, f2) -> mk_or ctx [ form_to_expr ~ctx f1; form_to_expr ~ctx f2 ]
  | Ast.Implies (f1, f2) -> mk_implies ctx (form_to_expr ~ctx f1) (form_to_expr ~ctx f2)
  | Ast.Not f -> mk_not ctx (form_to_expr ~ctx f)
;;

let solve f =
  let cfg = [ "model", "true"; "proof", "false" ] in
  let ctx = Z3.mk_context cfg in
  let solver = Z3.Solver.mk_simple_solver ctx in
  let status = Z3.Solver.check solver [ form_to_expr ~ctx (Ast.Not f) ] in
  match status with
  | Z3.Solver.UNSATISFIABLE -> Valid
  | Z3.Solver.SATISFIABLE ->
    Z3.Solver.get_model solver |> Option.value_exn |> Countermodel
  | Z3.Solver.UNKNOWN -> Z3.Solver.get_reason_unknown solver |> Unknown
;;

let solve_result_to_string = function
  | Valid -> "valid"
  | Countermodel m -> sprintf "countermodel:\n%s" (Z3.Model.to_string m)
  | Unknown r -> sprintf "unknown: %s" r
;;
