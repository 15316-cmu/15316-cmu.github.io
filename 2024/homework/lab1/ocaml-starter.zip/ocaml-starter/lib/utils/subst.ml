(** Substitution Helpers *)
open Core

module A = Ast

(** counter to generate fresh variables *)
let count = ref 0

let fresh_var (x : A.var) : A.var =
  let x' = x ^ "'" ^ Int.to_string !count in
  incr count;
  x'
;;

let rec subst_exp ~(x : A.var) ~(e : A.exp) : A.exp -> A.exp = function
  | A.Const c -> A.Const c
  | A.Var y -> if String.equal x y then e else A.Var y
  | A.Plus (e1, e2) -> A.Plus (subst_exp ~x ~e e1, subst_exp ~x ~e e2)
  | A.Minus (e1, e2) -> A.Minus (subst_exp ~x ~e e1, subst_exp ~x ~e e2)
  | A.Times (e1, e2) -> A.Times (subst_exp ~x ~e e1, subst_exp ~x ~e e2)
;;

let subst_form ~(x : A.var) ~(e : A.exp) (form : A.form) : A.form =
  (* Write your solution here! *)
  ignore (x : A.var);
  ignore (e : A.exp);
  ignore (form : A.form);
  failwith "unimplemented"
;;
