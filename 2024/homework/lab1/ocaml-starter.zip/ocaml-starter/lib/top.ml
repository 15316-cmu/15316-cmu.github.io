(** Top Level Environment *)

open Core

type mode =
  | Run
  | Analyze

type run_exit_status =
  | Run_success
  | Run_error
  | Run_failure
  | Run_abort
  | Run_unsafe
  | Run_undefined

let run_exit_code = function
  | Run_success -> 0
  | Run_error -> 1
  | Run_failure -> 2
  | Run_abort -> 3
  | Run_unsafe -> 4
  | Run_undefined -> 5
;;

type analyze_exit_status =
  | Analyze_valid
  | Analyze_unsafe

let analyze_exit_code = function
  | Analyze_valid -> 0
  | Analyze_unsafe -> 2
;;

type cmd_line_args =
  { filename : string
  ; input : Zarith.t
  ; expected_output : Zarith.t
  }

let parse_cmd_line_args (mode : mode) : cmd_line_args =
  let argv = Sys.get_argv () in
  match mode with
  | Run ->
    if Array.length argv < 4
    then (
      print_endline "expected 3 arguments";
      raise Error_msg.Error)
    else
      { filename = argv.(1)
      ; input = Zarith.of_string argv.(2)
      ; expected_output = Zarith.of_string argv.(3)
      }
  | Analyze ->
    if Array.length argv < 2
    then (
      print_endline "expected 1 argument";
      raise Error_msg.Error)
    else { filename = argv.(1); input = Zarith.zero; expected_output = Zarith.zero }
;;

(** [run mode cmd] runs [tiny_run] or [tiny_vc] depending on [mode] with [cmd] arguments *)
let run (mode : mode) ~(cmd : cmd_line_args) : unit =
  try
    (* Parse *)
    let ast = Parse.parse ~filename:cmd.filename in
    match mode with
    | Run ->
      (* Def-Use *)
      if not (Def_use.def_use ast)
      then (
        print_endline "undefined";
        run_exit_code Run_undefined |> Stdlib.exit);
      (* Exec *)
      (match Exec.exec ast ~input:cmd.input ~expected_output:cmd.expected_output with
       | Exec.Success o ->
         printf "success %s\n" (Zarith.to_string o);
         run_exit_code Run_success |> Stdlib.exit
       | Exec.Failure o ->
         printf "failure %s\n" (Zarith.to_string o);
         run_exit_code Run_failure |> Stdlib.exit
       | Exec.Abort ->
         print_endline "abort";
         run_exit_code Run_abort |> Stdlib.exit
       | Exec.Unsafe ->
         print_endline "unsafe";
         run_exit_code Run_unsafe |> Stdlib.exit)
    | Analyze ->
      (* Wlp *)
      if Wlp.check_safety ast
      then (
        print_endline "valid";
        analyze_exit_code Analyze_valid |> Stdlib.exit)
      else (
        print_endline "unsafe";
        analyze_exit_code Analyze_unsafe |> Stdlib.exit)
  with
  | Error_msg.Error ->
    print_endline "error";
    run_exit_code Run_error |> Stdlib.exit
;;

let main (mode : mode) =
  try
    let cmd = parse_cmd_line_args mode in
    run mode ~cmd
  with
  | Error_msg.Error ->
    print_endline "error";
    run_exit_code Run_error |> Stdlib.exit
  | Invalid_argument e ->
    print_endline e;
    print_endline "error";
    run_exit_code Run_error |> Stdlib.exit
;;
