fn main() {
    lalrpop::process_src().unwrap();
}
