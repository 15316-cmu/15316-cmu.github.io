# 15-316 Lab 1 - Rust

## Environment Setup

### Option 1 (Recommended): Docker with VSCode Dev Containers

Docker is the fastest and easiest way to get started with this project. If you don't have Docker installed, you can download it [here](https://docs.docker.com/get-started/get-docker/).

1. Pull the OCaml Docker image:
   ```bash
   docker pull --platform linux/amd64 hgouni/rust-ubuntu:latest
   ```
2. Install the [Dev Containers](https://marketplace.visualstudio.com/items?itemName=ms-vscode-remote.remote-containers) extension in VSCode.
3. Use the keyboard shortcut `Ctrl+Shift+P` (or `Shift+Cmd+P` on macOS) and type `Dev Containers: Open Folder in Container...`.
4. Select the directory of this project (make sure the `.devcontainer` directory is at the top level).

You should now be in a VSCode window running inside the Docker container with all the necessary dependencies installed!

### Option 2: `nix` package manager

Install the `nix` package manager as specified
[here](https://nixos.org/download/).

```bash
$ nix develop --extra-experimental-features nix-command --extra-experimental-features flakes
```

Run the above command in this directory. `nix` saves you from having to build
`z3` from source, in addition to taking care of a few other tricky build issues
and installing the Rust toolchain locally for this directory (like a Python
virtualenv).

You may wish to install
[this VSCode extension](https://marketplace.visualstudio.com/items?itemName=arrterian.nix-env-selector),
which allows it to access the Rust toolchain installed by Nix.

## Building

To build the project, run the following command:
```bash
make
```

This will build the project and create `tiny_run` and `tiny_vc` binaries in
your current directory.

To clean the project directory, run the following command:
```bash
make clean
```

## Handin

To create a `lab1.zip` file for handin, run the following command:
```bash
make handin
```

## Getting started

You will not need to worry about handling the CLI arguments, parsing, printing
out the correct messages, or exiting with the correct error codes. This is all
done for you already, and you will only need to implement the core logic for
each part of the project.

### Starter Code

These are the interfaces you will be working with:
- [`src/ast.rs`](src/ast.rs): The parser and abstract syntax tree (AST) for the
  TinyScript language.
  - This contains the types that represent the TinyScript language, some
    constants, and some utility functions for printing the AST.
  - Also contains some helper functions to generate fresh variables and apply
    substitutions to formulas and expressions. The expression substitution
    function is already implemented for you, but you will need to implement the
    formula substitution function.
- [`src/z3.rs`](src/z3.rs): The Z3 theorem prover interface.
  - This contains a wrapper for the Z3 theorem prover to check the validity of
    formulas.
  - Note that you do not need to do anything with the countermodel, but you may
    find it useful for debugging.

These are the files that you will need to modify, in the recommended order:
- [`src/ast.rs`](src/ast.rs): You will need to implement the `Sub` trait for
  `Form` types
- [`src/defuse.rs`](src/defuse.rs): This is where your code for checking that
  variables are defined before they are used will go.
- [`src/eval.rs`](src/eval.rs): This is where your TinyScript interpreter will
  go.
- [`src/wlp.rs`](src/wlp.rs): This is where your verifier code will go by
  computing the weakest liberal precondition.

Useful examples:
- [`src/ast.rs`](src/ast.rs): You should take a look at the pretty-printing
  functions in this file to understand how to traverse the AST.
  - The existing substitution function on expressions also serves as a good
    reference

## Testing

While you can test by running the `tiny_run` and `tiny_vc` binaries, it is
useful to write some smaller tests using a testing framework. Any function
annotated with `#[test]` will be run when `cargo test` is invoked. Search
for `#[test]` in [`src/ast.rs`](src/ast.rs) for examples.

# Resources

[Rust by Example](https://doc.rust-lang.org/rust-by-example/) acts as a quick
reference guide for getting around in Rust.
