use crate::ast::{Expr, Form};

use z3::ast::{Ast, Bool, Int};
use z3::{Config, Context, SatResult, Solver};

fn etoi(expr: Expr, ctx: &Context) -> Int {
    use Expr::*;
    match expr {
        Num(crate::ast::Num(i)) => Int::from_str(ctx, &i.to_string()).unwrap(),
        Var(crate::ast::Var::Variable(s)) => Int::new_const(ctx, s),
        Var(crate::ast::Var::Input) => Int::new_const(ctx, "'input".to_string()),
        Var(crate::ast::Var::Output) => Int::new_const(ctx, "'output".to_string()),
        Add(e1, e2) => &etoi(*e1, ctx) + &etoi(*e2, ctx),
        Sub(e1, e2) => &etoi(*e1, ctx) - &etoi(*e2, ctx),
        Mul(e1, e2) => &etoi(*e1, ctx) * &etoi(*e2, ctx),
    }
}

fn ftob(form: Form, ctx: &Context) -> Bool {
    use Form::*;
    match form {
        True => Bool::from_bool(ctx, true),
        False => Bool::from_bool(ctx, false),
        LessThan(e1, e2) => etoi(e1, ctx).lt(&etoi(e2, ctx)),
        LessThanEqual(e1, e2) => etoi(e1, ctx).le(&etoi(e2, ctx)),
        Equal(e1, e2) => etoi(e1, ctx)._eq(&etoi(e2, ctx)),
        And(f1, f2) => Bool::and(ctx, vec![&ftob(*f1, ctx), &ftob(*f2, ctx)].as_slice()),
        Or(f1, f2) => Bool::or(ctx, vec![&ftob(*f1, ctx), &ftob(*f2, ctx)].as_slice()),
        Not(f) => ftob(*f, ctx).not(),
        Implies(f1, f2) => ftob(*f1, ctx).implies(&ftob(*f2, ctx)),
    }
}

pub fn solve(form: Form) -> SatResult {
    let config = Config::new();
    let ctx = Context::new(&config);
    let solver = Solver::new(&ctx);

    solver.assert(&ftob(form, &ctx));

    let r = solver.check();

    // for debugging
    match r {
        // unwrap is safe here, since we've called .check() and confirmed that the result is Sat
        SatResult::Sat => println!("MODEL:\n{:?}", solver.get_model().unwrap()),
        _ => (),
    };

    r
}
