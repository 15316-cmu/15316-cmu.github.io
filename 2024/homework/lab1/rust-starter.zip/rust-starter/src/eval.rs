use crate::ast::{num, Expr, File, Form, Prog, Var, U};

use num_bigint::BigInt;
use std::collections::HashMap;

pub enum EvalError {
    Abort,
    Unsafe,
}

pub trait Eval<B, Map> {
    fn eval(&self, store: Map) -> B;
}

impl Eval<BigInt, &HashMap<Var, BigInt>> for Expr {
    fn eval(self: &Expr, store: &HashMap<Var, BigInt>) -> BigInt {
        use Expr::*;
        todo!();
    }
}

impl Eval<bool, &HashMap<Var, BigInt>> for Form {
    fn eval(self: &Form, store: &HashMap<Var, BigInt>) -> bool {
        use Form::*;
        todo!();
    }
}

impl Eval<Result<(), EvalError>, &mut (HashMap<Var, BigInt>, HashMap<BigInt, BigInt>)> for Prog {
    fn eval(
        self: &Prog,
        store: &mut (HashMap<Var, BigInt>, HashMap<BigInt, BigInt>),
    ) -> Result<(), EvalError> {
        use EvalError::*;
        use Prog::*;
        todo!();
    }
}

impl Eval<Result<(), EvalError>, &mut (HashMap<Var, BigInt>, HashMap<BigInt, BigInt>)> for File {
    fn eval(
        &self,
        store: &mut (HashMap<Var, BigInt>, HashMap<BigInt, BigInt>),
    ) -> Result<(), EvalError> {
        use EvalError::*;
        todo!();
    }
}
