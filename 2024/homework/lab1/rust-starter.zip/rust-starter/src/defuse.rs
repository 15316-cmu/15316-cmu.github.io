use std::collections::hash_set::HashSet;

use crate::ast::{Expr, File, Form, Prog, Var};

pub trait DefUse<Set> {
    fn defuse(&self, store: Set) -> Result<(), Var>;
}

impl DefUse<&HashSet<Var>> for Expr {
    fn defuse(&self, live: &HashSet<Var>) -> Result<(), Var> {
        use Expr::*;
        todo!();
    }
}

impl DefUse<&HashSet<Var>> for Form {
    fn defuse(&self, live: &HashSet<Var>) -> Result<(), Var> {
        use Form::*;
        todo!();
    }
}

impl DefUse<&mut HashSet<Var>> for Prog {
    fn defuse(&self, live: &mut HashSet<Var>) -> Result<(), Var> {
        use Prog::*;
        todo!();
    }
}

impl DefUse<&mut HashSet<Var>> for File {
    fn defuse(&self, live: &mut HashSet<Var>) -> Result<(), Var> {
        todo!();
    }
}
