use std::collections::HashMap;
use std::fmt::{Debug, Error, Formatter};
use std::sync::atomic::{AtomicUsize, Ordering};

use num_bigint::BigInt;
use num_traits::cast::FromPrimitive;

static COUNTER: AtomicUsize = AtomicUsize::new(1);

pub fn num(arg: i64) -> BigInt {
    BigInt::from_i64(arg).unwrap()
}

pub fn U() -> BigInt {
    num(1024)
}

#[derive(Clone, Eq, PartialEq)]
pub struct Num(pub BigInt);

#[derive(Clone, Eq, PartialEq, Hash)]
pub enum Var {
    Variable(String),
    Input,
    Output,
}

#[derive(Clone, Eq, PartialEq)]
pub enum Expr {
    Num(Num),
    Var(Var),
    Add(Box<Expr>, Box<Expr>),
    Sub(Box<Expr>, Box<Expr>),
    Mul(Box<Expr>, Box<Expr>),
}

#[derive(Clone, Eq, PartialEq)]
pub enum Form {
    True,
    False,
    LessThan(Expr, Expr),
    LessThanEqual(Expr, Expr),
    Equal(Expr, Expr),
    And(Box<Form>, Box<Form>),
    Or(Box<Form>, Box<Form>),
    Not(Box<Form>),
    Implies(Box<Form>, Box<Form>),
}

#[derive(Clone, Eq, PartialEq)]
pub enum Prog {
    Assign(Var, Expr),
    DerefRead(Var, Expr),
    DerefWrite(Expr, Expr),
    Seq(Box<Prog>, Box<Prog>),
    Assert(Form),
    Test(Form),
    If(Form, Box<Prog>, Box<Prog>),
    While(Form, Form, Box<Prog>),
}

#[derive(Clone, Eq, PartialEq)]
pub enum File {
    Prog(Prog),
    PreProg(Form, Prog),
}

impl Debug for Num {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result<(), Error> {
        write!(fmt, "{}", self.0)
    }
}

impl Debug for Var {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result<(), Error> {
        use self::Var::*;
        match self {
            Variable(v) => write!(fmt, "{}", v),
            Input => write!(fmt, "#input"),
            Output => write!(fmt, "#output"),
        }
    }
}

impl Debug for Expr {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result<(), Error> {
        use self::Expr::*;
        match self {
            Num(n) => write!(fmt, "{:?}", n),
            Var(v) => write!(fmt, "{:?}", v),
            Add(l, r) => write!(fmt, "({:?} + {:?})", l, r),
            Sub(l, r) => write!(fmt, "({:?} - {:?})", l, r),
            Mul(l, r) => write!(fmt, "({:?} * {:?})", l, r),
        }
    }
}

impl Debug for Form {
    fn fmt(&self, fmt: &mut Formatter) -> Result<(), Error> {
        use self::Form::*;
        match self {
            True => write!(fmt, "true"),
            False => write!(fmt, "false"),
            LessThan(l, r) => write!(fmt, "({:?} < {:?})", l, r),
            LessThanEqual(l, r) => write!(fmt, "({:?} <= {:?})", l, r),
            Equal(l, r) => write!(fmt, "({:?} == {:?})", l, r),
            And(l, r) => write!(fmt, "({:?} /\\ {:?})", l, r),
            Or(l, r) => write!(fmt, "({:?} \\/ {:?})", l, r),
            Not(f) => write!(fmt, "(~ {:?})", f),
            Implies(l, r) => write!(fmt, "({:?} -> {:?})", l, r),
        }
    }
}

impl Debug for Prog {
    fn fmt(&self, fmt: &mut Formatter) -> Result<(), Error> {
        use self::Prog::*;
        match self {
            Assign(v, e) => write!(fmt, "{:?} := {:?}", v, e),
            DerefRead(v, e) => write!(fmt, "{:?} := M [ {:?} ]", v, e),
            DerefWrite(e1, e2) => write!(fmt, "M [ {:?} ] := {:?}", e1, e2),
            Seq(p1, p2) => write!(fmt, "({:?} ; {:?})", p1, p2),
            Assert(f) => write!(fmt, "(assert {:?})", f),
            Test(f) => write!(fmt, "(test {:?})", f),
            If(f, p1, p2) => write!(fmt, "if {:?} then {:?} else {:?} endif", f, p1, p2),
            While(g, inv, b) => write!(fmt, "while {:?} invariant {:?} do {:?} done", g, inv, b),
        }
    }
}

impl Debug for File {
    fn fmt(&self, fmt: &mut Formatter) -> Result<(), Error> {
        match self {
            File::Prog(p) => write!(fmt, "{:?}", p),
            File::PreProg(f, p) => {
                write!(fmt, "requires {:?}; {:?}", f, p)
            }
        }
    }
}

#[test]
fn tiny_expr_test() {
    use crate::tiny::ExprParser;

    fn eparse_assert(input: &str, output: &str) {
        let parser = ExprParser::new();

        assert_eq!(&format!("{:?}", parser.parse(input).unwrap()), output);
    }

    eparse_assert("22 * 44 + 66", "((22 * 44) + 66)");
    eparse_assert("1 * 4 + 2 - 3 * 7", "(((1 * 4) + 2) - (3 * 7))");
    eparse_assert("7 * 4 * 2", "((7 * 4) * 2)");
    eparse_assert("(i + 1) * i", "((i + 1) * i)");

    assert!(ExprParser::new().parse("7 / (1 + 1)").is_err());
}

#[test]
fn tiny_form_test() {
    fn fparse_assert(input: &str, output: &str) {
        let parser = crate::tiny::FormParser::new();

        assert_eq!(&format!("{:?}", parser.parse(input).unwrap()), output);
    }

    fparse_assert("true", "true");
    fparse_assert("~ 1 < 2", "(~ (1 < 2))");
    fparse_assert("true -> false -> true", "(true -> (false -> true))");
    fparse_assert(
        "true -> false -> true -> (x < 2)",
        "(true -> (false -> (true -> (x < 2))))",
    );
    fparse_assert("1 + 2 == 2 + 3", "((1 + 2) == (2 + 3))");
    fparse_assert("~ (1 < 2)", "(~ (1 < 2))");
}

#[test]
fn tiny_prog_test() {
    fn pparse_assert(input: &str, output: &str) {
        let parser = crate::tiny::ProgParser::new();

        assert_eq!(&format!("{:?}", parser.parse(input).unwrap()), output);
    }

    pparse_assert("#input := 1", "#input := 1");
    pparse_assert("#output := 1", "#output := 1");
    pparse_assert("#output := 1; x := 0", "(#output := 1 ; x := 0)");
    pparse_assert("x := 1", "x := 1");
    pparse_assert("x := 1; y := 2", "(x := 1 ; y := 2)");
    pparse_assert("x := 1; y := 2; z := 1", "(x := 1 ; (y := 2 ; z := 1))");
    pparse_assert(
        "M [ 45 ] := 4; assert ~ false",
        "(M [ 45 ] := 4 ; (assert (~ false)))",
    );
    pparse_assert(
        "x := M [ 45 ]; #input := 1",
        "(x := M [ 45 ] ; #input := 1)",
    );
    pparse_assert(
        "x := 4; if true then x := 1 else x := 2 endif",
        "(x := 4 ; if true then x := 1 else x := 2 endif)",
    );
    pparse_assert("n := 0", "n := 0");
    pparse_assert(
        "n := 101;
         if true then x := 0 else x := 1 endif;
         i := 0;
         while true
            invariant (x < 0)
         do
            x := x + i
         done",
        "(n := 101 ; (if true then x := 0 else x := 1 endif ; (i := 0 ; while true invariant (x < 0) do x := (x + i) done)))",
    );
    pparse_assert(
        "
        x := 0;
        i := 0;
        while i < 101
            invariant 2 * x == i * (i + 1)
        do
            x := x + i;
            i := i + 1
        done
        ",
         "(x := 0 ; (i := 0 ; while (i < 101) invariant ((2 * x) == (i * (i + 1))) do (x := (x + i) ; i := (i + 1)) done))",
    );
    pparse_assert(
        "
        assert ~ (x < 0);
        while x < 1
            invariant ~ (x < 0)
        do
            x := x - 2
        done
        ",
        "((assert (~ (x < 0))) ; while (x < 1) invariant (~ (x < 0)) do x := (x - 2) done)",
    );
}

#[test]
fn tiny_file_test() {
    fn fparse_assert(input: &str, output: &str) {
        let parser = crate::tiny::FileParser::new();

        assert_eq!(&format!("{:?}", parser.parse(input).unwrap()), output);
    }

    fparse_assert("test true /\\ false", "(test (true /\\ false))");
    fparse_assert("n := 0; n := 1", "(n := 0 ; n := 1)");
    fparse_assert(
        "
        requires ~ x <= 0;
        y := x - 1
        ",
        "requires (~ (x <= 0)); y := (x - 1)",
    );
}

pub fn fresh() -> Var {
    Var::Variable("x".to_owned() + &COUNTER.fetch_add(1, Ordering::Relaxed).to_string())
}

pub fn reset() {
    COUNTER.store(1, Ordering::Relaxed)
}

pub trait Sub {
    fn sub(self, v: &Var, e: &Expr) -> Self;
    fn rename(self, v: &Var, r: &Var) -> Self;
}

impl Sub for Expr {
    fn sub(self, target_var: &Var, e: &Expr) -> Self {
        use Expr::*;
        match self {
            Num(n) => Num(n),
            Var(v) if v == *target_var => e.clone(),
            Var(v) => Var(v),
            Add(e1, e2) => Add(
                Box::new(e1.sub(target_var, e)),
                Box::new(e2.sub(target_var, e)),
            ),
            Sub(e1, e2) => Sub(
                Box::new(e1.sub(target_var, e)),
                Box::new(e2.sub(target_var, e)),
            ),
            Mul(e1, e2) => Mul(
                Box::new(e1.sub(target_var, e)),
                Box::new(e2.sub(target_var, e)),
            ),
        }
    }

    fn rename(self, target: &Var, replacement: &Var) -> Self {
        use Expr::*;
        match self {
            Num(n) => Num(n),
            Var(v) if v == *target => Var(replacement.clone()),
            Var(v) => Var(v),
            Add(e1, e2) => Add(
                Box::new(e1.rename(target, replacement)),
                Box::new(e2.rename(target, replacement)),
            ),
            Sub(e1, e2) => Sub(
                Box::new(e1.rename(target, replacement)),
                Box::new(e2.rename(target, replacement)),
            ),
            Mul(e1, e2) => Mul(
                Box::new(e1.rename(target, replacement)),
                Box::new(e2.rename(target, replacement)),
            ),
        }
    }
}

impl Sub for Form {
    fn sub(self, target_var: &Var, e: &Expr) -> Self {
        use Form::*;
        todo!();
    }

    fn rename(self, target: &Var, replacement: &Var) -> Self {
        use Form::*;
        todo!();
    }
}

impl Prog {
    pub fn rename(self, target: &Var, replacement: &Var) -> Self {
        use Prog::*;
        todo!();
    }
}
