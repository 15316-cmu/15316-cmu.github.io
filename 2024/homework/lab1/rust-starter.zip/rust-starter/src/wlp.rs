use crate::ast::{fresh, num, reset, Expr, File, Form, Num, Prog, Sub, Var, U};
use crate::z3::solve;
use z3::SatResult;

use std::collections::HashMap;

pub enum CheckResult {
    Safe,
    Unsafe,
}

fn solve_inline(form: Form) -> Form {
    use Form::*;

    let soln = solve(Form::Not(Box::new(form)));

    match soln {
        SatResult::Sat => False,
        SatResult::Unsat => True,
        SatResult::Unknown => panic!("This shouldn't happen."),
    }
}

fn wlp(prog: &Prog, post: &Form) -> Form {
    use Form::*;
    use Prog::*;
    todo!();
}

pub fn check(file: &File) -> CheckResult {
    todo!();
}
