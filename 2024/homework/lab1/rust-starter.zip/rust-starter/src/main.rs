#![allow(unused)]

mod ast;
mod defuse;
mod eval;
mod wlp;
mod z3;

use crate::ast::Var;
use crate::defuse::DefUse;
use crate::eval::{Eval, EvalError};
use crate::tiny::FileParser;
use crate::wlp::check;
use core::str::FromStr;
use num_bigint::BigInt;
use std::collections::{HashMap, HashSet};
use std::process::exit;
use std::{fs::File, io::Read};

use lalrpop_util::lalrpop_mod;

lalrpop_mod!(pub tiny);

#[derive(Clone, PartialEq, Debug)]
enum Output {
    Abort,
    Unsafe,
    Result(BigInt),
}

fn parse_file(filename: &str) -> crate::ast::File {
    let mut file_str = String::new();
    std::fs::File::open(filename)
        .unwrap_or_else(|err| {
            println!("{}", err);
            exit(1)
        })
        .read_to_string(&mut file_str);
    FileParser::new().parse(&file_str).unwrap_or_else(|err| {
        println!("{}", err);
        exit(1)
    })
}

fn main() -> std::io::Result<()> {
    let mut buffer = String::new();
    let args: Vec<String> = std::env::args().collect();

    let name = &args[0];

    if name.contains("tiny_run") {
        if args.len() != 4 {
            println!("error");
            exit(1)
        }

        let filename = &args[1];
        let input: BigInt = BigInt::from_str(&args[2]).unwrap_or_else(|_| {
            println!("error");
            exit(1)
        });
        let output: BigInt = BigInt::from_str(&args[3]).unwrap_or_else(|_| {
            println!("error");
            exit(1)
        });

        let file = parse_file(filename);

        let mut defuse_set: HashSet<Var> = HashSet::from([Var::Input]);
        match file.defuse(&mut defuse_set) {
            Ok(()) if defuse_set.contains(&Var::Output) => (),
            Ok(()) | Err(_) => {
                println!("undefined");
                exit(5)
            }
        }

        let store = HashMap::from([(Var::Input, input)]);
        let mut result = (store, HashMap::new());
        match file.eval(&mut result) {
            Ok(()) => {
                if output == *result.0.get(&Var::Output).unwrap() {
                    println!("success {:?}", output);
                } else {
                    println!("failure {:?}", *result.0.get(&Var::Output).unwrap());
                    exit(2)
                }
            }
            Err(e) => match e {
                EvalError::Abort => {
                    println!("abort");
                    exit(3)
                }
                EvalError::Unsafe => {
                    println!("abort");
                    exit(4)
                }
            },
        }
    } else if name.contains("tiny_vc") {
        if args.len() != 2 {
            println!("error");
            exit(1)
        }

        let filename = &args[1];

        let file = parse_file(filename);

        match check(&file) {
            wlp::CheckResult::Safe => {
                println!("valid")
            }
            wlp::CheckResult::Unsafe => {
                println!("unsafe");
                exit(2)
            }
        }
    }

    Ok(())
}
