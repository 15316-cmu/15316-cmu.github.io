from dataclasses import dataclass

@dataclass
class State:
    variables: dict[str, int]

@dataclass
class Heap:
    memory: dict[int, int]

heap_size = 1024

class Token:
    @classmethod
    def parseaction(cls, toks: list):
        new = cls(*toks)
        toks.clear()
        toks.append(new)


class Exp(Token):
    pass


@dataclass
class Const(Exp):
    value: int

    def __init__(self, value: str) -> 'Const':
        self.value = int(value)


@dataclass
class Var(Exp):
    name: str


@dataclass
class Sum(Exp):
    left: Exp
    right: Exp


@dataclass
class Difference(Exp):
    left: Exp
    right: Exp


@dataclass
class Product(Exp):
    left: Exp
    right: Exp


class Formula(Token):
    pass


@dataclass
class TrueC(Formula):
    pass


@dataclass
class FalseC(Formula):
    pass


@dataclass
class NotF(Formula):
    q: Formula


@dataclass
class AndF(Formula):
    p: Formula
    q: Formula


@dataclass
class OrF(Formula):
    p: Formula
    q: Formula


@dataclass
class ImpliesF(Formula):
    p: Formula
    q: Formula


@dataclass
class EqF(Formula):
    left: Exp
    right: Exp


@dataclass
class LtF(Formula):
    left: Exp
    right: Exp

@dataclass
class LtEqF(Formula):
    left: Exp
    right: Exp


class Prog(Token):
    pass


@dataclass
class Asgn(Prog):
    name: str
    exp: Exp

@dataclass
class WriteMem(Prog):
    location: Exp
    exp: Exp

@dataclass
class ReadMem(Prog):
    name: str
    exp: Exp

@dataclass
class Seq(Prog):
    alpha: Prog
    beta: Prog

@dataclass
class If(Prog):
    q: Formula
    alpha: Prog
    beta: Prog

@dataclass
class While(Prog):
    q: Formula
    p : Formula
    alpha: Prog

@dataclass
class Assert(Prog):
    q: Formula

@dataclass
class Test(Prog):
    q: Formula


@dataclass
class File():
    precondition: Formula
    program: Prog