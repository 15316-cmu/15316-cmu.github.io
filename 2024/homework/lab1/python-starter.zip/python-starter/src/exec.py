from dataclasses import dataclass
import tinyscript as tn

@dataclass
class ExecResult():
    pass

@dataclass
class Success(ExecResult):
    output: int

@dataclass
class Failure(ExecResult):
    output: int

@dataclass
class Abort(ExecResult):
    pass

@dataclass
class Unsafe(ExecResult):
    pass


def exec(file : tn.File, input: int, expected_output: int) -> ExecResult:
    """
    Executes the program `file` with the program variable `#input` set to `input`.

    Args:
        file: The program file to be executed.
        input: The value to set for the program variable `#input`.
    """
    raise NotImplementedError("Unimplemented")