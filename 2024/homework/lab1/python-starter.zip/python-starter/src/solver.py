import tinyscript as tn
from typing import Optional
import z3
from tinyscript_util import vars_prog

def simplify(func):
    """
    Decorator to simplify functions returning z3 values
    """
    def simplifyInner(*args, **kwargs):
        return z3.simplify(func(*args, **kwargs))
    return simplifyInner

@simplify
def exp_enc(e: tn.Exp) -> z3.IntNumRef:
    """
    Encode a tinyscript.Exp as a z3.IntNumRef
    
    Args:
        e (tn.Exp): Exp to encode
    
    Returns:
        z3.IntNumRef: Encoded exp
    
    Raises:
        TypeError: If the argument isn't a valid 
        	tinyscript exp.
    """
    match e:
        case tn.Const(val):
            return z3.IntVal(val)
        case tn.Var(id):
            return z3.Int(id)
        case tn.Sum(left, right):
            return exp_enc(left) + exp_enc(right)
        case tn.Difference(left, right):
            return exp_enc(left) - exp_enc(right)
        case tn.Product(left, right):
            return exp_enc(left) * exp_enc(right)
        case _:
            raise TypeError(
                f"exp_enc got {type(e)} ({e}), not Exp"
            )

@simplify
def fmla_enc(p: tn.Formula) -> z3.BoolRef:
    """
    Encode a tinyscript.Formula as a z3.BoolRef
    
    Args:
        p (tn.Formula): Formula to encode
    
    Returns:
        z3.BoolRef: Encoded formula
    
    Raises:
        TypeError: If the argument isn't a valid 
        	tinyscript formula.
    """
    match p:
        case tn.TrueC():
            return z3.BoolVal(True)
        case tn.FalseC():
            return z3.BoolVal(False)
        case tn.NotF(q):
            return z3.Not(fmla_enc(q))
        case tn.AndF(p, q):
            return z3.And(fmla_enc(p), fmla_enc(q))
        case tn.OrF(p, q):
            return z3.Or(fmla_enc(p), fmla_enc(q))
        case tn.ImpliesF(p, q):
            return z3.Implies(fmla_enc(p), fmla_enc(q))
        case tn.EqF(left, right):
            return exp_enc(left) == exp_enc(right)
        case tn.LtF(left, right):
            return exp_enc(left) < exp_enc(right)
        case tn.LtEqF(left, right):
            return exp_enc(left) <= exp_enc(right)
        case _:
            raise TypeError(
                f"fmla_enc got {type(p)} ({p}), not Formula"
            )

def check_sat(
    formulas: list[tn.Formula],
    timeout: int=None
) -> tuple[z3.CheckSatResult, Optional[z3.ModelRef]]:
    """
    Checks a list of formulas for satisfiability, with
    an optional timeout.

    Args:
        formulas (list[tn.Formula]): Formulas to check
        timeout (int, optional): Timeout in seconds, or `None`
            for no timeout. Defaults to `None`.

    Returns:
        tuple[z3.CheckSatResult, Optional[z3.ModelRef]]: If
            the conjunction of `ps` is satisfiable, then a tuple
            with a corresponding model in the second position.
            Otherwise, the second position is `None`.
    """
    s = z3.Solver()
    if timeout is not None:
        s.set(timeout=int(timeout*1000))
    for p in formulas:
        s.add(fmla_enc(p))
    res = s.check()
    return (res, s.model() if res == z3.sat else None)

def state_from_z3_model(
	alpha: tn.Prog, 
	model: z3.ModelRef,
	complete: bool=True
) -> tn.State:
	"""
	Construct a tinyscript interpreter state from a z3 satisfying
	assignment (model).
	
	Args:
	    alpha (tn.Prog): The program which will run on the returned state
	    model (z3.ModelRef): Model produced by z3.Solver.model() after calling
	    	z3.Solver.check() on satisfiable constraints
	    model_completion (bool, optional): Whether to populate the state with
	    	values for each variable appearing in `alpha`. If set to `False`,
	    	then the state will contain values only for the set of variables
	    	given numeric values in `model`; this may result in runtime
	    	errors if `alpha` is run on the state. Defaults to `True`.
	
	Returns:
	    tn.State: A tinyscript interpreter state which represents the values
	    	deexpined by `model`.
	"""
	vs = vars_prog(alpha)
	m = lambda x: model.evaluate(z3.Int(x), model_completion=complete)
	state = {
		v.name: m(v.name).as_long() 
		for v in vs
		if isinstance(m(v.name), z3.IntNumRef)
	}
	return tn.State(state)