from enum import Enum
from parse import (
    file_parse
)
from defuse import defuse
from exec import exec, Success, Failure, Abort, Unsafe
from wlp import check_safety
import sys

class RunExitStatus(Enum):
    Run_success = 0
    Run_error = 1
    Run_failure = 2
    Run_abort = 3
    Run_unsafe = 4
    Run_undefined = 5

class AnalyzeExitStatus(Enum):
    Analyze_valid = 0
    Analyze_unsafe = 2


class CmdLineArgs():
    def __init__(self, filename: str, input: int, expected_output: int):
        self.filename = filename
        self.input = input
        self.expected_output = expected_output


def print_and_exit(output: str, exit_code: int):
    print(output)
    exit(exit_code)

def parse_cmd_line_args(mode: str, argv: list) -> CmdLineArgs:
    match mode:
        case "Run":
            if len(argv) < 4:
                print_and_exit("expected 3 arguments", RunExitStatus.Run_error.value)
            else:
                return CmdLineArgs(argv[1], int(argv[2]), int(argv[3]))
        case "Analyze":
            if len(argv) < 2:
                print_and_exit("expected 1 argument", RunExitStatus.Run_error.value)
            else:
                return CmdLineArgs(argv[1], 0, 0)


class Mode:
    Run = 'Run'
    Analyze = 'Analyze'

def run(mode: Mode, cmd: CmdLineArgs) -> None:
    try:
        with open(cmd.filename, "r") as f:
            file = f.read()
        ast = file_parse(file)
        if mode == Mode.Run:
            # Defuse
            if not defuse(ast):
                print_and_exit("undefined", RunExitStatus.Run_undefined.value)
            # Exec
            result = exec(ast, input=cmd.input, expected_output=cmd.expected_output)
            match result:
                case Success(output):
                    print_and_exit(f"success {str(output)}", RunExitStatus.Run_success.value)
                case Failure(output):
                    print_and_exit(f"failure {str(output)}", RunExitStatus.Run_failure.value)
                case Abort():
                    print_and_exit("abort", RunExitStatus.Run_abort.value)
                case Unsafe():
                    print_and_exit("unsafe", RunExitStatus.Run_unsafe.value)
                case _:
                    raise TypeError(
                        f"run got {type(result)} ({result}), not ExecResult"
                    )
        elif mode == Mode.Analyze:
            # Wlp
            if check_safety(ast):
                print_and_exit("valid", AnalyzeExitStatus.Analyze_valid.value)
            else:
                print_and_exit("unsafe", AnalyzeExitStatus.Analyze_unsafe.value)
    except Exception as e:
        print_and_exit("error", RunExitStatus.Run_error.value)

if __name__ == "__main__":
    sys.setrecursionlimit(100000)
    try:
        if len(sys.argv) < 2:
            print("Mode is required: 'Run' or 'Analyze'")
            sys.exit(RunExitStatus.Run_error.value)
        
        mode = sys.argv[1]
        parsed_args = parse_cmd_line_args(mode, sys.argv[1:])
        
        run(mode, parsed_args)
    except Exception as e:
        print("error", e)
        exit(RunExitStatus.Run_error.value)