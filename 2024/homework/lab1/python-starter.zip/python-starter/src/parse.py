#!/usr/bin/env python3

from functools import lru_cache
from pyparsing import (
    Combine,
    Regex,
    Word,
    Forward,
    Suppress,
    oneOf,
    ZeroOrMore,
    infixNotation,
    opAssoc
)
import tinyscript as tn
import string

def IdentParser():
    idstart = Word(string.ascii_lowercase+"_", exact=1)
    idchar = Word(string.ascii_lowercase+string.digits+"_")
    
    special_vars = oneOf("#input #output")
    
    return special_vars | Combine(idstart + ZeroOrMore(idchar))


@lru_cache
def ExpParser():
    exp = Forward()

    const = Regex(r"-?\d+").set_parse_action(tn.Const.parseaction)
    ident = IdentParser().set_parse_action(tn.Var.parseaction)
    lpar, rpar = map(Suppress, "()")
    paren = lpar + exp + rpar

    plus, minus, times = map(Suppress, "+-*")

    atom = const | ident | paren
    times_exp = Forward()
    times_exp <<= atom \
        ^ (times_exp + times + atom).set_parse_action(tn.Product.parseaction)
    exp <<= times_exp \
        ^ (exp + plus + times_exp).set_parse_action(tn.Sum.parseaction) \
        ^ (exp + minus + times_exp).set_parse_action(tn.Difference.parseaction)

    exp.enable_left_recursion()
    return exp

@lru_cache
def FormulaParser():
    exp = ExpParser()
    fmla = Forward()
    
    true_const = Suppress("true").set_parse_action(tn.TrueC.parseaction)
    false_const = Suppress("false").set_parse_action(tn.FalseC.parseaction)
    lpar, rpar = map(Suppress, "()")
    paren = lpar + fmla + rpar

    eq = (exp + Suppress("==") + exp).set_parse_action(tn.EqF.parseaction)
    lt = (exp + Suppress("<") + exp).set_parse_action(tn.LtF.parseaction)
    lteq = (exp + Suppress("<=") + exp).set_parse_action(tn.LtEqF.parseaction)
    atom = true_const | false_const | eq | lt | lteq | paren  

    formula = infixNotation(atom, [
        ("~", 1, opAssoc.RIGHT, lambda tokens: tn.NotF(tokens[0][1])), 
        ("/\\", 2, opAssoc.RIGHT, lambda tokens: tn.AndF(tokens[0][0], tokens[0][2])),
        ("\\/", 2, opAssoc.RIGHT, lambda tokens: tn.OrF(tokens[0][0], tokens[0][2])),   
        ("->", 2, opAssoc.RIGHT, lambda tokens: tn.ImpliesF(tokens[0][0], tokens[0][2])) 
    ])

    return formula

@lru_cache
def ProgramParser():
    exp = ExpParser()
    fmla = FormulaParser()
    prog = Forward()

    assign_prog = (IdentParser() + Suppress(":=") + exp).set_parse_action(
        tn.Asgn.parseaction)

    if_prog = (Suppress("if") + fmla + Suppress("then") + prog +
               Suppress("else") + prog + Suppress("endif")).set_parse_action(
                   tn.If.parseaction)

    while_prog = (Suppress("while") + fmla + Suppress("invariant") + fmla + Suppress("do") + prog +
                  Suppress("done")).set_parse_action(tn.While.parseaction)

    assert_prog = (Suppress("assert") + fmla).set_parse_action(tn.Assert.parseaction)

    test_prog = (Suppress("test") + fmla).set_parse_action(tn.Test.parseaction)

    read_mem_prog = (IdentParser() + Suppress(":=") + Suppress("M") + Suppress("[") + exp + Suppress("]")).set_parse_action(tn.ReadMem.parseaction)
    write_mem_prog = (Suppress("M") + Suppress("[") + exp + Suppress("]") + Suppress(":=") + exp).set_parse_action(tn.WriteMem.parseaction)

    statement = assign_prog | if_prog | while_prog | assert_prog | test_prog | read_mem_prog | write_mem_prog
    prog <<= statement \
        ^ (
            prog + Suppress(";") + statement
        ).set_parse_action(tn.Seq.parseaction)

    prog.enable_left_recursion()
    return prog

@lru_cache
def FileParser():
    form = FormulaParser()
    prog = ProgramParser()
    
    requires_keyword = Suppress("requires")
    semicolon = Suppress(";")
    
    file_structure = requires_keyword + form + semicolon + prog
    
    return file_structure

def exp_parse(s: str):
    return ExpParser().parse_string(s, parse_all=True)[0]


def fmla_parse(s: str):
    return FormulaParser().parse_string(s, parse_all=True)[0]


def prog_parse(s: str):
    return ProgramParser().parse_string(s, parse_all=True)[0]

def file_parse(s: str):
    parsed_result = FileParser().parse_string(s, parse_all=True)
    
    precondition = parsed_result[0]
    program = parsed_result[1]

    return tn.File(precondition=precondition, program=program)

if __name__ == "__main__":
    global a
    a = exp_parse
    global b
    b = fmla_parse
    global p
    p = prog_parse
    global f
    f = file_parse

