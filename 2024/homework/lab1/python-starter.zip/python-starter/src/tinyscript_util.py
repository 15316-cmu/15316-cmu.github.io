from functools import reduce
import tinyscript as tn

def unique(func):
    """
    Decorator to make items in a list unique
    """
    def simplifyInner(*args, **kwargs):
        return reduce(
    		lambda l, x: l.append(x) or l if x not in l else l, 
    		func(*args, **kwargs), 
    		[])
    return simplifyInner

def exp_stringify(e: tn.Exp) -> str:
    """
    Pretty-print a tinyscript exp
    
    Args:
        e (tn.Exp): Exp to print
    
    Returns:
        str: Pretty-printed exp
    
    Raises:
        TypeError: Argument is not a valid tinyscript exp
    """
    match e:
        case tn.Const(val):
            return str(val)
        case tn.Var(id):
            return id
        case tn.Sum(left, right):
            return f"({exp_stringify(left)})+({exp_stringify(right)})"
        case tn.Difference(left, right):
            return f"({exp_stringify(left)})-({exp_stringify(right)})"
        case tn.Product(left, right):
            return f"({exp_stringify(left)})*({exp_stringify(right)})"
        case _:
            raise TypeError(
                f"exp_stringify got {type(e)} ({e}), not Exp"
            )


def fmla_stringify(p: tn.Formula) -> str:
    """
    Pretty-print a tinyscript formula
    
    Args:
        p (tn.Formula): Formula to print
    
    Returns:
        str: Pretty-printed formula
    
    Raises:
        TypeError: If the argument isn't a valid tinyscript formula
    """
    match p:
        case tn.TrueC():
            return "true"
        case tn.FalseC():
            return "false"
        case tn.NotF(q):
            return f"~({fmla_stringify(q)})"
        case tn.AndF(p, q):
            return f"({fmla_stringify(p)})/\({fmla_stringify(q)})"
        case tn.OrF(p, q):
            return f"({fmla_stringify(p)})\/({fmla_stringify(q)})"
        case tn.ImpliesF(p, q):
            return f"({fmla_stringify(p)})->({fmla_stringify(q)})"
        case tn.EqF(left, right):
            return f"({exp_stringify(left)})==({exp_stringify(right)})"
        case tn.LtF(left, right):
            return f"({exp_stringify(left)})<({exp_stringify(right)})"
        case tn.LtEqF(left, right):
            return f"({exp_stringify(left)})<=({exp_stringify(right)})"
        case _:
            raise TypeError(
                f"fmla_stringify got {type(p)} ({p}), not Formula"
            )


def stringify(alpha: tn.Prog, indent=0) -> str:
    """
    Pretty-print a tinyscript program
    
    Args:
        alpha (tn.Prog): Program to print
        indent (int, optional): Starting indentation, defaults to `0`
    
    Returns:
        str: Pretty-printed program
    
    Raises:
        TypeError: If the argument is not a valid tinyscript program
    """
    match alpha:
        case tn.Asgn(name, aexp):
            return f"{' '*indent}{name} := {exp_stringify(aexp)}"
        case tn.Seq(alpha_p, beta_p):
            return f"{stringify(alpha_p, indent)};\n{stringify(beta_p, indent)}"
        case tn.If(p, alpha_p, beta_p):
            return (
                f"{' '*indent}if ({fmla_stringify(p)}) then\n"
                f"{stringify(alpha_p, indent+4)}\n"
                f"{' '*indent}else\n"
                f"{stringify(beta_p, indent+4)}\n"
                f"{' '*indent}endif"
            )
        case tn.While(q, p, alpha_p):
            return (
                f"{' '*indent}while ({fmla_stringify(q)}) invariant ({fmla_stringify(p)}) do\n"
                f"{stringify(alpha_p, indent+4)}\n"
                f"{' '*indent}done")
        case tn.Assert(q):
            return f"{' '*indent}assert {fmla_stringify(q)}"
        case tn.Test(q):
            return f"{' '*indent}test {fmla_stringify(q)}"
        case tn.ReadMem(name, e):
            return f"{' '*indent}{name} := M [ {exp_stringify(e)} ]"
        case tn.WriteMem(e1, e2):
            return f"{' '*indent}M [ {exp_stringify(e1)} ] := {exp_stringify(e2)}"
        case _:
            raise TypeError(
                f"stringify got {type(alpha)} ({alpha}), not Prog"
            )

@unique
def vars_exp(e: tn.Exp) -> list[tn.Var]:
	"""
	Collect the variables appearing in a exp
	
	Args:
	    e (tn.Exp): Exp to collect from
	
	Returns:
	    list[tn.Var]: List of variables in argument
	
	Raises:
	    TypeError: If the argument is not a valid tinyscript exp
	"""
	match e:
		case tn.Const(val):
			return []
		case tn.Var(id):
			return [e]
		case tn.Sum(left, right):
			return vars_exp(left) + vars_exp(right)
		case tn.Difference(left, right):
			return vars_exp(left) + vars_exp(right)
		case tn.Product(left, right):
			return vars_exp(left) + vars_exp(right)
		case _:
			raise TypeError(
				f"vars_exp got {type(e)} ({e}), not Exp"
			)

@unique
def vars_formula(p: tn.Formula) -> list[tn.Var]:
	"""
	Collect the variables appearing in a formula
	
	Args:
	    p (tn.Formula): Formula to collect from
	
	Returns:
	    list[tn.Var]: List of variables in argument
	
	Raises:
	    TypeError: If the argument is not a valid tinyscript formula
	"""
	match p:
		case tn.TrueC():
			return []
		case tn.FalseC():
			return []
		case tn.NotF(q):
			return vars_formula(q)
		case tn.AndF(p, q):
			return vars_formula(p) + vars_formula(q)
		case tn.OrF(p, q):
			return vars_formula(p) + vars_formula(q)
		case tn.ImpliesF(p, q):
			return vars_formula(p) + vars_formula(q)
		case tn.EqF(left, right):
			return vars_exp(left) + vars_exp(right)
		case tn.LtF(left, right):
			return vars_exp(left) + vars_exp(right)
		case tn.LtEqF(left, right):
			return vars_exp(left) + vars_exp(right)
		case _:
			raise TypeError(
				f"vars_formula got {type(p)} ({p}), not Formula"
			)

@unique
def vars_prog(alpha: tn.Prog) -> list[tn.Var]:
    """
    Collect the variables appearing in a program

    Args:
        alpha (tn.Prog): Program to collect from

    Returns:
        list[tn.Var]: List of variables in argument

    Raises:
        TypeError: If the argument is not a valid tinyscript program
    """
    match alpha:
        case tn.Asgn(name, aexp):
            return [tn.Var(name)] + vars_exp(aexp)
        case tn.Seq(alpha_p, beta_p):
            return vars_prog(alpha_p) + vars_prog(beta_p)
        case tn.If(p, alpha_p, beta_p):
            return vars_formula(p) + vars_prog(alpha_p) + vars_prog(beta_p)
        case tn.While(q, alpha_p):
            return vars_formula(q) + vars_prog(alpha_p)
        case tn.Assert(q):
            return vars_formula(q)
        case tn.Test(q):
            return vars_formula(q)
        case tn.ReadMem(name, e):
            return [tn.Var(name)] + vars_exp(e)
        case tn.WriteMem(e1, e2):
            return vars_exp(e1) + vars_exp(e2)
        case _:
            raise TypeError(
                f"vars_prog got {type(alpha)} ({alpha}), not Prog"
            )

counter = 0  
def fresh_var(x : tn.Var) -> tn.Var:
    global counter
    x2 = tn.Var(x.name + '\'' + str(counter))
    counter += 1
    return x2


def subst_exp(exp1 : tn.Exp, x : tn.Var, exp2 : tn.Exp) -> tn.Exp:
    """
    Substitute an expression for a variable in an expression.
    
    This function replaces all occurrences of a given variable in an expression
    with another expression. It recursively traverses the expression to ensure
    that the substitution is applied wherever the variable appears.

    Args:
        exp1 (tn.Exp): The expression in which to perform the substitution.
        x (tn.Var): The variable to be substituted.
        exp2 (tn.Exp): The expression that will replace occurrences of the variable.

    Returns:
        tn.Exp: A new expression with the variable substituted by the given expression.
    """
    match exp2:
        case tn.Const(val):
            return tn.Const(val)
        case tn.Var(id):
            return exp1 if x == id else tn.Var(id) 
        case tn.Sum(left, right):
            return tn.Sum(subst_exp(exp1, x, left), subst_exp(exp1, x, right))
        case tn.Difference(left, right):
            return tn.Difference(subst_exp(exp1, x, left), subst_exp(exp1, x, right))
        case tn.Product(left, right):
            return tn.Product(subst_exp(exp1, x, left), subst_exp(exp1, x, right))
        case _:
            raise TypeError(
                f"vars_exp got {type(exp2)} ({exp2}), not Exp"
            )
         
def subst_exp(exp1 : tn.Exp, x : tn.Var, form : tn.Formula) -> tn.Formula:
    raise NotImplementedError("Unimplemented")
         
