#!/usr/bin/env bash

python3 ./src/main.py Run $@
