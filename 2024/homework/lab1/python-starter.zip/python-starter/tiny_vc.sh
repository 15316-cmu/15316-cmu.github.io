#!/usr/bin/env bash

python3 -O -OO ./src/main.py Analyze $@
