# Lab 1 - Python

## Environment Setup

Clone this repository onto your local machine or your Andrew home directory.

You will need to use Python 3.10 to complete this lab. We encourage you to set up a fresh virtual environment before continuing.

* Create a new conda environment.
```
$ conda create -n py310 python=3.10
```
This may not work if you are using a version of `conda` prior to 4.11. If you do not have `conda`, or need to upgrade, you can [download the latest installer](https://docs.conda.io/en/latest/miniconda.html). If you already have a recent version on your system, but not Python 3.10, then you can run:
```
$ conda install -c conda-forge python=3.10
```
After installing Python 3.10 (or if you already have it), create a new environment as described above. You can use the environment by running:
```
$ conda activate py310
```
In the new environment, install the necessary packages.
```
(py310)$ pip install -r requirements.txt
```

## Building

To build the project, run the following command:
```bash
make
```

This will build the project and create `tiny_run` and `tiny_vc` binaries in your current directory.

To clean the project directory, run the following command:
```bash
make clean
```

## Handin

To create a `lab1.zip` file for handin, run the following command:
```bash
make handin
```

## Getting Started

You will not need to worry about handling the CLI arguments, parsing, printing out the correct messages, or exiting with the correct error codes. This is all handled for you, and you will only need to implement the core logic for each part of the project.

### Starter Code

These are the interfaces you will be working with:
- [src/tinyscript.py](src/tinyscript.py): The abstract syntax tree (AST) for the TinyScript language.
  - This contains the types that represent the TinyScript language, some constants, and some utility functions for printing the AST.
- [src/parse.py](src/parse.py): The parser for the TinyScript language.
  - This contains the parser that converts a string into an AST. While parsing the input file is handled for you, you may want create some small test cases, and using the parser is the easiest way to create an AST value.
- [src/solver.py](src/solver.py): The Z3 theorem prover interface.
  - This contains a wrapper for the Z3 theorem prover to check the validity of formulas
- [src/tinyscript_util.py](src/tinyscript_util.py): Substitution helper functions.
  - This contains some helper functions to generate fresh variables and apply substitutions to formulas and expressions. The expression substitution function is already implemented for you, but you will need to implement the formula substitution function.

These are the files that you will need to modify:
- [src/tinyscript_util.py](src/tinyscript_util.py#L353): You will need to implement the `subst_form` function.
- [src/defuse.py](src/defuse.py): This is where your code for checking that variables are defined before they are used will go.
- [src/exec.py](src/exec.py): This is where your TinyScript interpreter will go.
  - Note that the modules `State` and `Heap` are defined in this file. These are modules for `Map`s keyed by `Ast.var` and `Ast.num`, respectively.
- [src/wlp.py](src/wlp.py): This is where your verifier code will go by computing the weakest liberal precondition.

Useful examples:
- [src/tinyscript_util.py](src/tinyscript_util.py): You should take a look at the stringify functions in this file to understand how to traverse the AST.
- [src/tinyscript_util.py](src/tinyscript_util.py#L321): `subst_exp` is a smaller example and should help you write `subst_form`.
