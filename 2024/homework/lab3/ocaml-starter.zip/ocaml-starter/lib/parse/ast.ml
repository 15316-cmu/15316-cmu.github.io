(** Abstract Syntax Tree for PCA *)

open Core

type var = [%import: Ast.var]
type const = [%import: Ast.const]
type term = [%import: Ast.term]
type atom = [%import: Ast.atom]
type form = [%import: Ast.form]
type ante = [%import: Ast.ante]
type policy = [%import: Ast.policy]
type pvar = [%import: Ast.pvar]
type proof = [%import: Ast.proof]

(* printing with redundant parentheses *)
module Print =
struct
let pp_term (t : term) = match t with
  | Var x -> x
  | Const c -> c

let rec pp_terms ts = match ts with
  | [] -> ""
  | t::[] -> pp_term t
  | t::ts -> sprintf "%s, %s" (pp_term t) (pp_terms ts)

let rec pp_form (p : form) : string = match p with
  | Atom (f, ts) -> sprintf "%s(%s)" f (pp_terms ts)
  | Says (a, p) -> sprintf "(%s says %s)" (pp_term a) (pp_form p)
  | Implies (p, q) -> sprintf "(%s -> %s)" (pp_form p) (pp_form q)
  | Forall (x, p) -> sprintf "(!%s. %s)" x (pp_form p)

let rec pp_policy (policy : policy) : string = match policy with
  | [] -> ""
  | Decl(c, p)::policy' -> sprintf "%s : %s ;\n%s" c (pp_form p) (pp_policy policy')

let rec pp_proof (m : proof) : string = match m with
  | Pvar v -> v
  | App (m1, m2) -> sprintf "(%s %s)" (pp_proof m1) (pp_proof m2)
  | Inst (m, t) -> sprintf "(%s [%s])" (pp_proof m) (pp_term t)
  | Wrap (m, a) -> sprintf "{ %s }_%s" (pp_proof m) (pp_term a)
  | LetWrap (v, a, m, n) -> sprintf "let {%s}_%s = %s in (%s)" v (pp_term a) (pp_proof m) (pp_proof n)
  | Let (v, m, n) -> sprintf "let %s = %s in (%s)" v (pp_proof m) (pp_proof n)

let pp_typing (mp : proof * form) : string = match mp with
  | (m, p) -> sprintf "%s\n : \n%s" (pp_proof m) (pp_form p)

end
