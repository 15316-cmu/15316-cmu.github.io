(** Substitution Helpers *)

open Core

module A = Ast

(** counter to generate fresh variables *)
let count = ref 0

let fresh_var (x : A.var) : A.var =
  let x' = x ^ "'" ^ Int.to_string !count in
  incr count;
  x'

let eq_term (s : A.term) (t : A.term) : bool =
  ignore s ; ignore t ;
  failwith "unimplemented"

let eq_form (p : A.form) (q : A.form) : bool =
  ignore p ; ignore q ;
  failwith "unimplemented"

let subst_form (x : A.var) (t : A.term) (p : A.form) : A.form =
  ignore x ; ignore t ; ignore p ;
  failwith "unimplemented"
