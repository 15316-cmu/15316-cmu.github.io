open Core
module A = Ast
module P = Ast.Print

exception Verify of string

let verify (gamma : A.policy) (m : A.proof) (p : A.form) =
  ignore gamma ; ignore m ; ignore p ;
  failwith "unimplemented"

let check_policy (gamma : A.policy) =
  ignore gamma ;
  failwith "unimplemented"

