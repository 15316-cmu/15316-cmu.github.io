(** Top Level Environment *)

module A = Ast
module P = Ast.Print

open Core

type serve_exit_state =
  | Serve_success
  | Serve_error
  | Serve_failure

let serve_exit_code = function
  | Serve_success -> 0
  | Serve_error -> 1
  | Serve_failure -> 2

type cmd_line_args =
  { policy_file : string ;
    proof_file : string }

let parse_cmd_line_args () : cmd_line_args =
  let argv = Sys.get_argv () in
  if Array.length argv < 3
  then (
    print_endline "expected 2 arguments";
    raise Error_msg.Error)
  else { policy_file = argv.(1) ; proof_file = argv.(2) }

let run (cmd : cmd_line_args) : unit =
  try
    let user_policy = Parse.parse_policy cmd.policy_file in
    let () = print_string (A.Print.pp_policy user_policy) in
    let () = Verify.check_policy user_policy in

    let (m, p) = Parse.parse_typing cmd.proof_file in
    let () = print_string ("|-\n" ^ A.Print.pp_typing (m, p) ^ "\n") in

    let () = Verify.verify user_policy m p in

    let () = printf "success %s\n" "<proof>" in
    serve_exit_code Serve_success |> Stdlib.exit
  with
  | Error_msg.Error ->
    print_endline "error";
    serve_exit_code Serve_error |> Stdlib.exit
  | Verify.Verify msg ->
    print_endline msg;
    print_endline "failure";
    serve_exit_code Serve_failure |> Stdlib.exit

let main () =
  try
    run (parse_cmd_line_args ())
  with
  | Error_msg.Error ->
    print_endline "error";
    serve_exit_code Serve_error |> Stdlib.exit
  | Invalid_argument e ->
    print_endline e;
    print_endline "error";
    serve_exit_code Serve_error |> Stdlib.exit
