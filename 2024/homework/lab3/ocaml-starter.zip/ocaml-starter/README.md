# 15-316 Lab 3 - OCaml

If you have any questions, please post on Piazza, come to office hours, or email me at [jlyao@andrew.cmu.edu](mailto:jlyao@andrew.cmu.edu)

## Environment Setup

### Option 1 (Recommended): Docker with VSCode Dev Containers

Docker is the fastest and easiest way to get started with this project. If you don't have Docker installed, you can download it [here](https://docs.docker.com/get-started/get-docker/).

1. Pull the OCaml Docker image:
   ```bash
   docker pull --platform linux/amd64 jyao6429/ocaml-ubuntu:latest
   ```
2. Install the [Dev Containers](https://marketplace.visualstudio.com/items?itemName=ms-vscode-remote.remote-containers) extension in VSCode.
3. Use the keyboard shortcut `Ctrl+Shift+P` (or `Shift+Cmd+P` on macOS) and type `Dev Containers: Open Folder in Container...`.
4. Select the directory of this project (make sure the `.devcontainer` directory is at the top level).

You should now be in a VSCode window running inside the Docker container with all the necessary dependencies installed!

### Option 2: Local Installation

This has been tested on Ubuntu 22.04 natively and under WSL2. If you use Windows, you must use [WSL](https://learn.microsoft.com/en-us/windows/wsl/install). If you use macOS, it should work as well.

1. If you don't have OCaml installed, follow the instructions [here](https://ocaml.org/docs/installing-ocaml).
2. Create a new `opam` switch with the following command:
   ```bash
   opam switch create 5.0.0-15316 5.0.0
   ```
3. Switch to the new switch if you weren't automatically switched:
    ```bash
    opam switch 5.0.0-15316
    eval $(opam env)
    ```
4. Install the necessary packages:
   ```bash
   opam install core.v0.15.1 dune ocamlformat menhir merlin ppx_jane ppx_deriving ppx_import utop ocaml-lsp-server odoc zarith z3
   ```
   This will take a while!
5. Install the [OCaml Platform VSCode extension](https://marketplace.visualstudio.com/items?itemName=ocamllabs.ocaml-platform) if you are using VSCode.

### Option 3: `nix` package manager (Linux/WSL)

Install the `nix` package manager as specified [here](https://nixos.org/download/).

```bash
nix develop --extra-experimental-features nix-command --extra-experimental-features flakes
```

Run the above command in this directory. `nix` takes care of a few tricky build
issues and installs the OCaml toolchain locally for this directory (like a
Python virtualenv). If you're having build issues with the above options, this option will likely work better.

## Building

To build the project, run the following command:
```bash
make
```

This will build the project and create `tiny_run` and `tiny_vc` binaries in your current directory.

To clean the project directory, run the following command:
```bash
make clean
```

## Handin

To create a `lab3.zip` file for handin, run the following command:
```bash
make handin
```

## Getting Started

You will not need to worry about handling the CLI arguments, parsing, printing out the correct messages, or exiting with the correct error codes. This is all done for you already, and you will only need to implement the core logic for each part of the project.

Note that the starter code makes limited use of named parameters, which is a feature not present in SML. If you have a variable that has the same name as a parameter, you can directly use the parameter name to refer to the argument. For example, if you have a function `f : x:int -> int`, and a value `x : int`, you can call `f` with `f ~x`. Otherwise, you need to specify the argument name with a `:` after the named parameter. For example, if you instead have a variable `y : int`, you would call `f ~x:y`.

### Starter Code

These are the interfaces you will be working with:
- [`lib/parse/ast.mli`](lib/parse/ast.mli): The abstract syntax trees (AST) for PCA policies and proofs.
  - This contains the types that represent formulas and proofs, and some utility functions for printing the AST.
These are the files that you will need to modify:
- [`lib/utils/subst.ml`](lib/utils/subst.ml): Substitution and equality helper functions that you need to implement.
- [`lib/verify/verify.ml`](lib/verify/verify.ml): Code to check whether signatures are well-formed and proofs are correct.

**You should take a look at the corresponding interface (`.mli`) files to understand the spec of each function.**

## Resources

- [Brandon Wu's From SML to OCaml Lecture Slides](https://brandonspark.github.io/ocaml/sml_to_ocaml.pdf)
  - This is a great resource for learning OCaml if you are already familiar with SML.
- [Core Documentation](https://ocaml.org/p/core/v0.15.1/doc/Core/index.html)
  - This is documentation for Jane Street's Core standard library that's used in this project. Note that this replaces the default OCaml standard library. The most useful modules are [Map](https://ocaml.org/p/core/v0.15.1/doc/Core/Map/index.html) and [Set](https://ocaml.org/p/core/v0.15.1/doc/Core/Set/index.html).
- [Real World OCaml](https://dev.realworldocaml.org/index.html)
  - This is a textbook for OCaml that also uses the Core standard library.
- [CS 3110 Course Materials](https://cs3110.github.io/textbook/cover.html)
  - This is the textbook used for Cornell's functional programming course that uses OCaml.

